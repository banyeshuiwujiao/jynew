---@class System.MemberAccessException : System.SystemException
local m = {}

System.MemberAccessException = m
return m
