---@class Mono.Globalization.Unicode.SimpleCollator.Escape : System.ValueType
---@field public Source string
---@field public Index number
---@field public Start number
---@field public End number
---@field public Optional number
local m = {}

Mono.Globalization.Unicode.SimpleCollator.Escape = m
return m
