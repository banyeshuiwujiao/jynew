---@class System.IndexOutOfRangeException : System.SystemException
local m = {}

System.IndexOutOfRangeException = m
return m
