---@class System.Array_ReferenceSources : System.Object
local m = {}

System.Array_ReferenceSources = m
return m
