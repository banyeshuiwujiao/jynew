---@class System.Exception.ExceptionMessageKind : System.Enum
---@field public ThreadAbort System.Exception.ExceptionMessageKind @static
---@field public ThreadInterrupted System.Exception.ExceptionMessageKind @static
---@field public OutOfMemory System.Exception.ExceptionMessageKind @static
---@field public value__ number
local m = {}

System.Exception.ExceptionMessageKind = m
return m
