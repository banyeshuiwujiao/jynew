---@class Microsoft.Win32.UnsafeNativeMethods.ManifestEtw.TRACE_GUID_INFO : System.ValueType
---@field public InstanceCount number
---@field public Reserved number
local m = {}

Microsoft.Win32.UnsafeNativeMethods.ManifestEtw.TRACE_GUID_INFO = m
return m
