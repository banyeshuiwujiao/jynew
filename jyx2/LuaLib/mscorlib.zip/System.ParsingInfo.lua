---@class System.ParsingInfo : System.ValueType
local m = {}

System.ParsingInfo = m
return m
