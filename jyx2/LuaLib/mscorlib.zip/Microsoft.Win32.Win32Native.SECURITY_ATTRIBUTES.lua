---@class Microsoft.Win32.Win32Native.SECURITY_ATTRIBUTES : System.Object
local m = {}

Microsoft.Win32.Win32Native.SECURITY_ATTRIBUTES = m
return m
