---@class Mono.Security.X509.X520.Name : Mono.Security.X509.X520.AttributeTypeAndValue
local m = {}

Mono.Security.X509.X520.Name = m
return m
