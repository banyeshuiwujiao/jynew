---@class System.MissingFieldException : System.MissingMemberException
---@field public Message string
local m = {}

System.MissingFieldException = m
return m
