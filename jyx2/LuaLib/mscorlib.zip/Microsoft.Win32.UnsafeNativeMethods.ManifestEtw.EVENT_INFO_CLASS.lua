---@class Microsoft.Win32.UnsafeNativeMethods.ManifestEtw.EVENT_INFO_CLASS : System.Enum
---@field public BinaryTrackInfo Microsoft.Win32.UnsafeNativeMethods.ManifestEtw.EVENT_INFO_CLASS @static
---@field public SetEnableAllKeywords Microsoft.Win32.UnsafeNativeMethods.ManifestEtw.EVENT_INFO_CLASS @static
---@field public SetTraits Microsoft.Win32.UnsafeNativeMethods.ManifestEtw.EVENT_INFO_CLASS @static
---@field public value__ number
local m = {}

Microsoft.Win32.UnsafeNativeMethods.ManifestEtw.EVENT_INFO_CLASS = m
return m
