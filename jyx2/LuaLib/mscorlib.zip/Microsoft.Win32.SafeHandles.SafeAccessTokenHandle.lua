---@class Microsoft.Win32.SafeHandles.SafeAccessTokenHandle : System.Runtime.InteropServices.SafeHandle
---@field public InvalidHandle Microsoft.Win32.SafeHandles.SafeAccessTokenHandle @static
---@field public IsInvalid boolean
local m = {}

Microsoft.Win32.SafeHandles.SafeAccessTokenHandle = m
return m
