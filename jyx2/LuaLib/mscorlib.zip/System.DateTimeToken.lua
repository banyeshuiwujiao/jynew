---@class System.DateTimeToken : System.ValueType
local m = {}

System.DateTimeToken = m
return m
