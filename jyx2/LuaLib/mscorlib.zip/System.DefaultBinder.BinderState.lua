---@class System.DefaultBinder.BinderState : System.Object
local m = {}

System.DefaultBinder.BinderState = m
return m
