---@class Microsoft.Win32.UnsafeNativeMethods.ManifestEtw.TRACE_ENABLE_INFO : System.ValueType
---@field public IsEnabled number
---@field public Level number
---@field public Reserved1 number
---@field public LoggerId number
---@field public EnableProperty number
---@field public Reserved2 number
---@field public MatchAnyKeyword number
---@field public MatchAllKeyword number
local m = {}

Microsoft.Win32.UnsafeNativeMethods.ManifestEtw.TRACE_ENABLE_INFO = m
return m
