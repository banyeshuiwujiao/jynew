---@class Mono.Security.Authenticode.Authority : System.Enum
---@field public Individual Mono.Security.Authenticode.Authority @static
---@field public Commercial Mono.Security.Authenticode.Authority @static
---@field public Maximum Mono.Security.Authenticode.Authority @static
---@field public value__ number
local m = {}

Mono.Security.Authenticode.Authority = m
return m
