---@class Microsoft.Win32.UnsafeNativeMethods.ManifestEtw.TRACE_PROVIDER_INSTANCE_INFO : System.ValueType
---@field public NextOffset number
---@field public EnableCount number
---@field public Pid number
---@field public Flags number
local m = {}

Microsoft.Win32.UnsafeNativeMethods.ManifestEtw.TRACE_PROVIDER_INSTANCE_INFO = m
return m
