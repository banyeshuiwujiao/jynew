---@class System.NullReferenceException : System.SystemException
local m = {}

System.NullReferenceException = m
return m
