---@class System.LazyHelpers : System.Object
local m = {}

System.LazyHelpers = m
return m
