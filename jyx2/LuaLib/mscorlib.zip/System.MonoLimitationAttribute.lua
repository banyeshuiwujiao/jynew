---@class System.MonoLimitationAttribute : System.MonoTODOAttribute
local m = {}

System.MonoLimitationAttribute = m
return m
