---@class Microsoft.Win32.UnsafeNativeMethods.ManifestEtw.ActivityControl : System.Enum
---@field public EVENT_ACTIVITY_CTRL_GET_ID Microsoft.Win32.UnsafeNativeMethods.ManifestEtw.ActivityControl @static
---@field public EVENT_ACTIVITY_CTRL_SET_ID Microsoft.Win32.UnsafeNativeMethods.ManifestEtw.ActivityControl @static
---@field public EVENT_ACTIVITY_CTRL_CREATE_ID Microsoft.Win32.UnsafeNativeMethods.ManifestEtw.ActivityControl @static
---@field public EVENT_ACTIVITY_CTRL_GET_SET_ID Microsoft.Win32.UnsafeNativeMethods.ManifestEtw.ActivityControl @static
---@field public EVENT_ACTIVITY_CTRL_CREATE_SET_ID Microsoft.Win32.UnsafeNativeMethods.ManifestEtw.ActivityControl @static
---@field public value__ number
local m = {}

Microsoft.Win32.UnsafeNativeMethods.ManifestEtw.ActivityControl = m
return m
