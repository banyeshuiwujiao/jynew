---@class System.Lazy_1.LazyInternalExceptionHolder_T_ : System.Object
local m = {}

System.Lazy_1.LazyInternalExceptionHolder_T_ = m
return m
