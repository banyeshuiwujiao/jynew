---@class Microsoft.Win32.UnsafeNativeMethods.ManifestEtw.TRACE_QUERY_INFO_CLASS : System.Enum
---@field public TraceGuidQueryList Microsoft.Win32.UnsafeNativeMethods.ManifestEtw.TRACE_QUERY_INFO_CLASS @static
---@field public TraceGuidQueryInfo Microsoft.Win32.UnsafeNativeMethods.ManifestEtw.TRACE_QUERY_INFO_CLASS @static
---@field public TraceGuidQueryProcess Microsoft.Win32.UnsafeNativeMethods.ManifestEtw.TRACE_QUERY_INFO_CLASS @static
---@field public TraceStackTracingInfo Microsoft.Win32.UnsafeNativeMethods.ManifestEtw.TRACE_QUERY_INFO_CLASS @static
---@field public MaxTraceSetInfoClass Microsoft.Win32.UnsafeNativeMethods.ManifestEtw.TRACE_QUERY_INFO_CLASS @static
---@field public value__ number
local m = {}

Microsoft.Win32.UnsafeNativeMethods.ManifestEtw.TRACE_QUERY_INFO_CLASS = m
return m
