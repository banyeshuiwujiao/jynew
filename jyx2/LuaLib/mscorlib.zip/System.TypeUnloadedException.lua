---@class System.TypeUnloadedException : System.SystemException
local m = {}

System.TypeUnloadedException = m
return m
