---@class System.AttributeTargets : System.Enum
---@field public Assembly System.AttributeTargets @static
---@field public Module System.AttributeTargets @static
---@field public Class System.AttributeTargets @static
---@field public Struct System.AttributeTargets @static
---@field public Enum System.AttributeTargets @static
---@field public Constructor System.AttributeTargets @static
---@field public Method System.AttributeTargets @static
---@field public Property System.AttributeTargets @static
---@field public Field System.AttributeTargets @static
---@field public Event System.AttributeTargets @static
---@field public Interface System.AttributeTargets @static
---@field public Parameter System.AttributeTargets @static
---@field public Delegate System.AttributeTargets @static
---@field public ReturnValue System.AttributeTargets @static
---@field public GenericParameter System.AttributeTargets @static
---@field public All System.AttributeTargets @static
---@field public value__ number
local m = {}

System.AttributeTargets = m
return m
