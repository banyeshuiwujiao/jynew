---@class Microsoft.Win32.UnsafeNativeMethods.ManifestEtw : System.Object
local m = {}

Microsoft.Win32.UnsafeNativeMethods.ManifestEtw = m
return m
