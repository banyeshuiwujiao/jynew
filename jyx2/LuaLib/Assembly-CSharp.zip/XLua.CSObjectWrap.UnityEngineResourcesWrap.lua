---@class XLua.CSObjectWrap.UnityEngineResourcesWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.UnityEngineResourcesWrap = m
return m
