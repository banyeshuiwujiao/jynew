---@class Jyx2.SkillCastInstance : System.Object
---@field public MAX_MAGIC_LEVEL_INDEX number @static
---@field public TimeTickCoolDown number @static
---@field public Anqi Jyx2.LItemConfig
---@field public Key string
---@field public level number
---@field public CurrentCooldown number
---@field public Data Jyx2.SkillInstance
local m = {}

function m:CastCD() end

---@param role Jyx2.RoleInstance
function m:CastMP(role) end

---@param role Jyx2.RoleInstance
function m:CastCost(role) end

---@param level_index number
---@return number
function m:calNeedMP(level_index) end

function m:TimeRun() end

---@return Jyx2.SkillCastInstance.SkillCastStatus
function m:GetStatus() end

---@virtual
---@return boolean
function m:IsCastToEnemy() end

---@param mp number
---@param max_level number
---@return number
function m:calMaxLevelIndexByMP(mp, max_level) end

---@return number
function m:getMpCost() end

---@virtual
---@return boolean
function m:IsAttack() end

---@virtual
---@return number
function m:GetCastSize() end

---@virtual
---@return Jyx2.SkillCoverType
function m:GetCoverType() end

---@virtual
---@return number
function m:GetCoverTypeInt() end

---@virtual
---@return number
function m:GetCoverSize() end

---@virtual
---@return number
function m:GetDamageType() end

Jyx2.SkillCastInstance = m
return m
