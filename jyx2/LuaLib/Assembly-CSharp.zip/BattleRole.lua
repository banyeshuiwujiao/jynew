---@class BattleRole : Jyx2.Jyx2AnimationBattleRole
---@field public m_IsKeyRole boolean
---@field public m_IsWaitingForActive boolean
---@field public IsInBattle boolean
---@field public DataInstance Jyx2.RoleInstance
---@field public m_RoleKey number
---@field public HPBarIsDirty boolean
local m = {}

function m:LazyInitAnimator() end

---@virtual
---@return UnityEngine.Animator
function m:GetAnimator() end

---@param damage number
function m:SetDamage(damage) end

---@virtual
function m:ShowDamage() end

---@virtual
function m:MarkHpBarIsDirty() end

---@virtual
function m:UnmarkHpBarIsDirty() end

---@param mainText string
---@param textColor UnityEngine.Color
function m:ShowBattleText(mainText, textColor) end

---@param content string
function m:ShowAttackInfo(content) end

---@param skill Jyx2.SkillInstance
function m:SwitchSkillTo(skill) end

---@param pos Jyx2.BattleBlockData
function m:LookAtBattleBlock(pos) end

---@param position UnityEngine.Vector3
function m:LookAtWorldPosInBattle(position) end

---@param pos UnityEngine.Vector3
function m:SetPosition(pos) end

---@overload fun()
---@param deathCode number
function m:ShowDeath(deathCode) end

function m:ShowStun() end

---@param isInBattle boolean
function m:StopStun(isInBattle) end

---@virtual
function m:DeadOrIdle() end

---@return Cysharp.Threading.Tasks.UniTask
function m:RefreshModel() end

---@extension
---@param roleKey number
function m.CreateRoleInstance(roleKey) end

---@extension
---@param role Jyx2.RoleInstance
---@return Cysharp.Threading.Tasks.UniTask
function m.BindRoleInstance(role) end

BattleRole = m
return m
