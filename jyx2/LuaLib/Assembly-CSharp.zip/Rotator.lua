---@class Rotator : UnityEngine.MonoBehaviour
---@field public RotationSpeed number
local m = {}

Rotator = m
return m
