---@class ETCDPad : ETCBase
---@field public onMoveStart ETCDPad.OnMoveStartHandler
---@field public onMove ETCDPad.OnMoveHandler
---@field public onMoveSpeed ETCDPad.OnMoveSpeedHandler
---@field public onMoveEnd ETCDPad.OnMoveEndHandler
---@field public onTouchStart ETCDPad.OnTouchStartHandler
---@field public onTouchUp ETCDPad.OnTouchUPHandler
---@field public OnDownUp ETCDPad.OnDownUpHandler
---@field public OnDownDown ETCDPad.OnDownDownHandler
---@field public OnDownLeft ETCDPad.OnDownLeftHandler
---@field public OnDownRight ETCDPad.OnDownRightHandler
---@field public OnPressUp ETCDPad.OnDownUpHandler
---@field public OnPressDown ETCDPad.OnDownDownHandler
---@field public OnPressLeft ETCDPad.OnDownLeftHandler
---@field public OnPressRight ETCDPad.OnDownRightHandler
---@field public axisX ETCAxis
---@field public axisY ETCAxis
---@field public normalSprite UnityEngine.Sprite
---@field public normalColor UnityEngine.Color
---@field public pressedSprite UnityEngine.Sprite
---@field public pressedColor UnityEngine.Color
---@field public buttonSizeCoef number
local m = {}

---@virtual
function m:Start() end

---@virtual
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnPointerDown(eventData) end

---@virtual
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnDrag(eventData) end

---@virtual
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnPointerUp(eventData) end

ETCDPad = m
return m
