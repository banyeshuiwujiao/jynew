---@class XLuaTest.LuaBehaviour : UnityEngine.MonoBehaviour
---@field public luaScript UnityEngine.TextAsset
---@field public injections XLuaTest.Injection[]
local m = {}

XLuaTest.LuaBehaviour = m
return m
