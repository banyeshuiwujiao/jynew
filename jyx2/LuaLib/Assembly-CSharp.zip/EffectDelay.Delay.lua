---@class EffectDelay.Delay : UnityEngine.MonoBehaviour
---@field public delayTime number
local m = {}

EffectDelay.Delay = m
return m
