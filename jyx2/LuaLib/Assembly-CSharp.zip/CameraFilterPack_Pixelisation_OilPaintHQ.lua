---@class CameraFilterPack_Pixelisation_OilPaintHQ : UnityEngine.MonoBehaviour
---@field public SCShader UnityEngine.Shader
---@field public Value number
local m = {}

CameraFilterPack_Pixelisation_OilPaintHQ = m
return m
