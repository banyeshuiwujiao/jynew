---@class GameStart : UnityEngine.MonoBehaviour
---@field public introPanel UnityEngine.CanvasGroup
local m = {}

GameStart = m
return m
