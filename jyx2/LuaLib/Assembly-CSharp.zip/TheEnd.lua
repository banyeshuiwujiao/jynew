---@class TheEnd : Jyx2_UIBase
local m = {}

---@virtual
function m:Update() end

TheEnd = m
return m
