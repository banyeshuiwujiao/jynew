---@class XLua.CSObjectWrap.XLuaTestMyStructWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.XLuaTestMyStructWrap = m
return m
