---@class Jyx2.Jyx2_PlayerPrefs : System.Object
local m = {}

---@static
function m.CheckInit() end

---@static
function m.ReLoad() end

---@static
function m.DeleteAll() end

---@static
---@param key string
function m.DeleteKey(key) end

---@static
---@param key string
---@return boolean
function m.HasKey(key) end

---@static
function m.Save() end

---@overload fun(key:string): @static
---@static
---@param key string
---@param defaultValue number
---@return number
function m.GetFloat(key, defaultValue) end

---@overload fun(key:string): @static
---@static
---@param key string
---@param defaultValue number
---@return number
function m.GetInt(key, defaultValue) end

---@overload fun(key:string): @static
---@static
---@param key string
---@param defaultValue string
---@return string
function m.GetString(key, defaultValue) end

---@overload fun(key:string): @static
---@static
---@param key string
---@param defaultValue boolean
---@return boolean
function m.GetBool(key, defaultValue) end

---@static
---@param key string
---@param value number
function m.SetFloat(key, value) end

---@static
---@param key string
---@param value number
function m.SetInt(key, value) end

---@static
---@param key string
---@param value string
function m.SetString(key, value) end

---@static
---@param key string
---@param value boolean
function m.SetBool(key, value) end

Jyx2.Jyx2_PlayerPrefs = m
return m
