---@class XLua.CSObjectWrap.UnityEngineMonoBehaviourWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.UnityEngineMonoBehaviourWrap = m
return m
