---@class ShaderLodLevelEnum : System.Enum
---@field public Low ShaderLodLevelEnum @static
---@field public Mid ShaderLodLevelEnum @static
---@field public High ShaderLodLevelEnum @static
---@field public value__ number
local m = {}

ShaderLodLevelEnum = m
return m
