---@class Jyx2.Jyx2_PlayerPrefs_QuitSave : UnityEngine.MonoBehaviour
local m = {}

Jyx2.Jyx2_PlayerPrefs_QuitSave = m
return m
