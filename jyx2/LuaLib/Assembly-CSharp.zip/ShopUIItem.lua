---@class ShopUIItem : UnityEngine.UI.Selectable
---@field public ItemId number
---@field public ShopItemData Jyx2.CsShopItem
local m = {}

---@param value fun(obj:ShopUIItem)
function m:add_OnShopItemSelect(value) end

---@param value fun(obj:ShopUIItem)
function m:remove_OnShopItemSelect(value) end

---@param shopItem Jyx2.CsShopItem
---@param index number
---@param hasBuyNum number
---@return Cysharp.Threading.Tasks.UniTaskVoid
function m:Refresh(shopItem, index, hasBuyNum) end

---@param active boolean
function m:SetSelect(active) end

function m:OnAddBtnClick() end

function m:OnReduceBtnClick() end

---@return number
function m:GetIndex() end

---@return number
function m:GetBuyCount() end

---@overload fun(up:Jyx2.UINavigation.INavigable, down:Jyx2.UINavigation.INavigable, left:Jyx2.UINavigation.INavigable) @virtual
---@overload fun(up:Jyx2.UINavigation.INavigable, down:Jyx2.UINavigation.INavigable) @virtual
---@overload fun(up:Jyx2.UINavigation.INavigable) @virtual
---@overload fun() @virtual
---@virtual
---@param up Jyx2.UINavigation.INavigable
---@param down Jyx2.UINavigation.INavigable
---@param left Jyx2.UINavigation.INavigable
---@param right Jyx2.UINavigation.INavigable
function m:Connect(up, down, left, right) end

---@virtual
---@return UnityEngine.UI.Selectable
function m:GetSelectable() end

---@virtual
---@param eventData UnityEngine.EventSystems.BaseEventData
function m:OnSelect(eventData) end

---@overload fun() @virtual
---@virtual
---@param notifyEvent boolean
function m:Select(notifyEvent) end

ShopUIItem = m
return m
