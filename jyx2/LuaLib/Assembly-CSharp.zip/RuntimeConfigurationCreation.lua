---@class RuntimeConfigurationCreation : UnityEngine.MonoBehaviour
---@field public creator TileWorld.TileWorldCreator
---@field public objectScatter TileWorld.TileWorldObjectScatter
---@field public themes RuntimeConfigurationCreation.Themes[]
local m = {}

RuntimeConfigurationCreation = m
return m
