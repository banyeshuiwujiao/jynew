---@class XLuaTest.CoroutineTest : UnityEngine.MonoBehaviour
local m = {}

XLuaTest.CoroutineTest = m
return m
