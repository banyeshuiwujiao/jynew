---@class PlayerMovement : UnityEngine.MonoBehaviour
---@field public creator TileWorld.TileWorldCreator
---@field public speed number
---@field public randomMovement boolean
local m = {}

PlayerMovement = m
return m
