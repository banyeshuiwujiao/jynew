---@class XLua.ObjectTranslator : System.Object
---@field public cacheRef number
local m = {}

---@param L System.IntPtr
---@param val UnityEngine.Vector2
function m:PushUnityEngineVector2(L, val) end

---@overload fun(L:System.IntPtr, index:number):
---@overload fun(L:System.IntPtr, index:number):
---@overload fun(L:System.IntPtr, index:number):
---@overload fun(L:System.IntPtr, index:number):
---@overload fun(L:System.IntPtr, index:number):
---@overload fun(L:System.IntPtr, index:number):
---@overload fun(L:System.IntPtr, index:number):
---@overload fun(L:System.IntPtr, index:number):
---@overload fun(L:System.IntPtr, index:number):
---@overload fun(L:System.IntPtr, index:number):
---@overload fun(L:System.IntPtr, index:number):
---@overload fun(L:System.IntPtr, index:number):
---@overload fun(L:System.IntPtr, index:number):
---@overload fun(L:System.IntPtr, index:number):
---@overload fun(L:System.IntPtr, index:number):
---@param L System.IntPtr
---@param index number
---@return UnityEngine.Vector2
function m:Get(L, index) end

---@param L System.IntPtr
---@param index number
---@param val UnityEngine.Vector2
function m:UpdateUnityEngineVector2(L, index, val) end

---@param L System.IntPtr
---@param val UnityEngine.Vector3
function m:PushUnityEngineVector3(L, val) end

---@param L System.IntPtr
---@param index number
---@param val UnityEngine.Vector3
function m:UpdateUnityEngineVector3(L, index, val) end

---@param L System.IntPtr
---@param val UnityEngine.Vector4
function m:PushUnityEngineVector4(L, val) end

---@param L System.IntPtr
---@param index number
---@param val UnityEngine.Vector4
function m:UpdateUnityEngineVector4(L, index, val) end

---@param L System.IntPtr
---@param val UnityEngine.Color
function m:PushUnityEngineColor(L, val) end

---@param L System.IntPtr
---@param index number
---@param val UnityEngine.Color
function m:UpdateUnityEngineColor(L, index, val) end

---@param L System.IntPtr
---@param val UnityEngine.Quaternion
function m:PushUnityEngineQuaternion(L, val) end

---@param L System.IntPtr
---@param index number
---@param val UnityEngine.Quaternion
function m:UpdateUnityEngineQuaternion(L, index, val) end

---@param L System.IntPtr
---@param val UnityEngine.Ray
function m:PushUnityEngineRay(L, val) end

---@param L System.IntPtr
---@param index number
---@param val UnityEngine.Ray
function m:UpdateUnityEngineRay(L, index, val) end

---@param L System.IntPtr
---@param val UnityEngine.Bounds
function m:PushUnityEngineBounds(L, val) end

---@param L System.IntPtr
---@param index number
---@param val UnityEngine.Bounds
function m:UpdateUnityEngineBounds(L, index, val) end

---@param L System.IntPtr
---@param val UnityEngine.Ray2D
function m:PushUnityEngineRay2D(L, val) end

---@param L System.IntPtr
---@param index number
---@param val UnityEngine.Ray2D
function m:UpdateUnityEngineRay2D(L, index, val) end

---@param L System.IntPtr
---@param val XLuaTest.Pedding
function m:PushXLuaTestPedding(L, val) end

---@param L System.IntPtr
---@param index number
---@param val XLuaTest.Pedding
function m:UpdateXLuaTestPedding(L, index, val) end

---@param L System.IntPtr
---@param val XLuaTest.MyStruct
function m:PushXLuaTestMyStruct(L, val) end

---@param L System.IntPtr
---@param index number
---@param val XLuaTest.MyStruct
function m:UpdateXLuaTestMyStruct(L, index, val) end

---@param L System.IntPtr
---@param val XLuaTest.PushAsTableStruct
function m:PushXLuaTestPushAsTableStruct(L, val) end

---@param L System.IntPtr
---@param index number
---@param val XLuaTest.PushAsTableStruct
function m:UpdateXLuaTestPushAsTableStruct(L, index, val) end

---@param L System.IntPtr
---@param val Tutorial.TestEnum
function m:PushTutorialTestEnum(L, val) end

---@param L System.IntPtr
---@param index number
---@param val Tutorial.TestEnum
function m:UpdateTutorialTestEnum(L, index, val) end

---@param L System.IntPtr
---@param val XLuaTest.MyEnum
function m:PushXLuaTestMyEnum(L, val) end

---@param L System.IntPtr
---@param index number
---@param val XLuaTest.MyEnum
function m:UpdateXLuaTestMyEnum(L, index, val) end

---@param L System.IntPtr
---@param val Tutorial.DerivedClass.TestEnumInner
function m:PushTutorialDerivedClassTestEnumInner(L, val) end

---@param L System.IntPtr
---@param index number
---@param val Tutorial.DerivedClass.TestEnumInner
function m:UpdateTutorialDerivedClassTestEnumInner(L, index, val) end

---@param type System.Type
---@param loader fun(obj:System.IntPtr)
function m:DelayWrapLoader(type, loader) end

---@param type System.Type
---@param creator fun(arg1:number, arg2:XLua.LuaEnv):
function m:AddInterfaceBridgeCreator(type, creator) end

---@param L System.IntPtr
---@param type System.Type
---@return boolean
function m:TryDelayWrapLoader(L, type) end

---@param type System.Type
---@param alias string
function m:Alias(type, alias) end

---@param L System.IntPtr
---@param delegateType System.Type
---@param idx number
---@return any
function m:CreateDelegateBridge(L, delegateType, idx) end

---@return boolean
function m:AllDelegateBridgeReleased() end

---@param L System.IntPtr
---@param reference number
---@param is_delegate boolean
function m:ReleaseLuaBase(L, reference, is_delegate) end

---@param L System.IntPtr
---@param interfaceType System.Type
---@param idx number
---@return any
function m:CreateInterfaceBridge(L, interfaceType, idx) end

---@param L System.IntPtr
function m:CreateArrayMetatable(L) end

---@param L System.IntPtr
function m:CreateDelegateMetatable(L) end

---@param L System.IntPtr
function m:OpenLib(L) end

---@param L System.IntPtr
---@param idx number
---@return System.Type
function m:GetTypeOf(L, idx) end

---@overload fun(L:System.IntPtr, index:number, type:System.Type):
---@param L System.IntPtr
---@param index number
---@return boolean
function m:Assignable(L, index) end

---@param L System.IntPtr
---@param index number
---@param type System.Type
---@return any
function m:GetObject(L, index, type) end

---@param L System.IntPtr
---@param v any
function m:PushByType(L, v) end

---@overload fun(L:System.IntPtr, index:number, type:System.Type):
---@param L System.IntPtr
---@param index number
---@return any[]
function m:GetParams(L, index) end

---@param L System.IntPtr
---@param ary System.Array
function m:PushParams(L, ary) end

---@param L System.IntPtr
---@param index number
---@return any
function m:GetDelegate(L, index) end

---@param L System.IntPtr
---@param type System.Type
---@return number
function m:GetTypeId(L, type) end

---@param L System.IntPtr
---@param type System.Type
function m:PrivateAccessible(L, type) end

---@param L System.IntPtr
---@param o any
function m:PushAny(L, o) end

---@param L System.IntPtr
---@param type System.Type
---@param idx number
---@return number
function m:TranslateToEnumToTop(L, type, idx) end

---@overload fun(L:System.IntPtr, o:XLua.LuaBase)
---@overload fun(L:System.IntPtr, o:any)
---@param L System.IntPtr
---@param o fun(L:System.IntPtr):
function m:Push(L, o) end

---@param L System.IntPtr
---@param o any
---@param type_id number
function m:PushObject(L, o, type_id) end

---@param L System.IntPtr
---@param index number
---@param obj any
function m:Update(L, index, obj) end

---@param type System.Type
---@return boolean
function m:HasCustomOp(type) end

---@param push fun(arg1:System.IntPtr, arg2:any)
---@param get fun(L:System.IntPtr, idx:number):
---@param update fun(arg1:System.IntPtr, arg2:number, arg3:any)
function m:RegisterPushAndGetAndUpdate(push, get, update) end

---@param get fun(L:System.IntPtr, idx:number):
function m:RegisterCaster(get) end

---@param L System.IntPtr
---@param val System.Decimal
function m:PushDecimal(L, val) end

---@param L System.IntPtr
---@param index number
---@return boolean
function m:IsDecimal(L, index) end

---@param L System.IntPtr
---@param index number
---@return System.Decimal
function m:GetDecimal(L, index) end

XLua.ObjectTranslator = m
return m
