---@class CameraDepth : UnityEngine.MonoBehaviour
local m = {}

CameraDepth = m
return m
