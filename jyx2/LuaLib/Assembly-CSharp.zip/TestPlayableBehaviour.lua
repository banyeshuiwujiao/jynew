---@class TestPlayableBehaviour : UnityEngine.Playables.PlayableBehaviour
---@field public ShowNumberText UnityEngine.UI.Text
---@field public StartNum number
local m = {}

---@virtual
---@param playable UnityEngine.Playables.Playable
function m:OnGraphStart(playable) end

---@virtual
---@param playable UnityEngine.Playables.Playable
function m:OnGraphStop(playable) end

---@virtual
---@param playable UnityEngine.Playables.Playable
---@param info UnityEngine.Playables.FrameData
function m:OnBehaviourPlay(playable, info) end

---@virtual
---@param playable UnityEngine.Playables.Playable
---@param info UnityEngine.Playables.FrameData
function m:OnBehaviourPause(playable, info) end

---@virtual
---@param playable UnityEngine.Playables.Playable
---@param info UnityEngine.Playables.FrameData
function m:PrepareFrame(playable, info) end

TestPlayableBehaviour = m
return m
