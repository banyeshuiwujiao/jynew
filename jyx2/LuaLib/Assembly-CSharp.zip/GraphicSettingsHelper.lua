---@class GraphicSettingsHelper : System.Object
---@field public m_MainCamera UnityEngine.Camera
local m = {}

---@param mainCamera UnityEngine.Camera
function m:InitSettings(mainCamera) end

function m:DoSettings() end

GraphicSettingsHelper = m
return m
