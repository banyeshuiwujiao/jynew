---@class XLuaTest.PropertyChangedEventArgs : System.EventArgs
---@field public name string
---@field public value any
local m = {}

XLuaTest.PropertyChangedEventArgs = m
return m
