---@class BattleOKPanel : Jyx2_UIBase
---@field public Layer UILayer
local m = {}

function m:InitTrans() end

BattleOKPanel = m
return m
