---@class PlayerStatusPanelUI : UnityEngine.MonoBehaviour
local m = {}

PlayerStatusPanelUI = m
return m
