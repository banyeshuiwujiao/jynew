---@class JYX2Outline : UnityEngine.MonoBehaviour
local m = {}

---@param color UnityEngine.Color
---@param width number
function m:SetOutlineProperty(color, width) end

JYX2Outline = m
return m
