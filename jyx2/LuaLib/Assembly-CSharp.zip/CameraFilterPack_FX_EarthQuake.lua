---@class CameraFilterPack_FX_EarthQuake : UnityEngine.MonoBehaviour
---@field public SCShader UnityEngine.Shader
---@field public Speed number
---@field public X number
---@field public Y number
local m = {}

CameraFilterPack_FX_EarthQuake = m
return m
