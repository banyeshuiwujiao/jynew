---@class XLuaTest.ReImplementInLua : UnityEngine.MonoBehaviour
local m = {}

XLuaTest.ReImplementInLua = m
return m
