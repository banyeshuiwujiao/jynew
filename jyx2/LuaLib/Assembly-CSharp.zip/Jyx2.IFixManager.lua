---@class Jyx2.IFixManager : System.Object
local m = {}

---@static
---@return Cysharp.Threading.Tasks.UniTask
function m.LoadPatch() end

Jyx2.IFixManager = m
return m
