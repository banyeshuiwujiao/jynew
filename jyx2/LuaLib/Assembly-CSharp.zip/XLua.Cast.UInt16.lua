---@class XLua.Cast.UInt16 : XLua.Cast.Any_1_System_UInt16_
local m = {}

XLua.Cast.UInt16 = m
return m
