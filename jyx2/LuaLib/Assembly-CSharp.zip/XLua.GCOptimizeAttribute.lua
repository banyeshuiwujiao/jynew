---@class XLua.GCOptimizeAttribute : System.Attribute
---@field public Flag XLua.OptimizeFlag
local m = {}

XLua.GCOptimizeAttribute = m
return m
