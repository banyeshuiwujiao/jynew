---@class CameraFilterPack_Distortion_BlackHole : UnityEngine.MonoBehaviour
---@field public SCShader UnityEngine.Shader
---@field public PositionX number
---@field public PositionY number
---@field public Size number
---@field public Distortion number
local m = {}

CameraFilterPack_Distortion_BlackHole = m
return m
