---@class MOD.UI.ModDownloadResult : System.ValueType
---@field public isSuccess boolean
---@field public ModDownloadPath string
local m = {}

MOD.UI.ModDownloadResult = m
return m
