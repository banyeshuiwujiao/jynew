---@class XLuaTest.Foo1Parent : System.Object
local m = {}

---@extension
function m.PlainExtension() end

XLuaTest.Foo1Parent = m
return m
