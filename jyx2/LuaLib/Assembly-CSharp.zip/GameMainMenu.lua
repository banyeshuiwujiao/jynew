---@class GameMainMenu : Jyx2_UIBase
---@field public Layer UILayer
---@field public IsNameInputFocused boolean
local m = {}

function m:OnNewGameClicked() end

function m:OnLoadGameClicked() end

function m:OnQuitGameClicked() end

function m:OnCreateBtnClicked() end

function m:OnCreateRoleYesClick() end

function m:OnCreateRoleNoClick() end

---@overload fun()
---@param cheating boolean
function m:DoGeneratePlayerRole(cheating) end

function m:OnBackBtnClicked() end

function m:OnReleaseNoteBtnClick() end

---@param url string
function m:OnOpenURL(url) end

function m:OpenSettingsPanel() end

function m:OpenModPanel() end

function m:InitTrans() end

GameMainMenu = m
return m
