---@class XLua.CSObjectWrap.UnityEngineTransformWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.UnityEngineTransformWrap = m
return m
