---@class XLua.Cast.Any_1_System_UInt32_ : System.Object
---@field public Target any
local m = {}

XLua.Cast.Any_1_System_UInt32_ = m
return m
