---@class LocalPositionEditorMono : UnityEngine.MonoBehaviour
---@field public position UnityEngine.Vector3
---@field public rotaion UnityEngine.Vector3
---@field public scale UnityEngine.Vector3
local m = {}

LocalPositionEditorMono = m
return m
