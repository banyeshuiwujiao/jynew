---@class Tutorial.TestEnum : System.Enum
---@field public E1 Tutorial.TestEnum @static
---@field public E2 Tutorial.TestEnum @static
---@field public value__ number
local m = {}

Tutorial.TestEnum = m
return m
