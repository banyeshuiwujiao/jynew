---@class BSPDungeonAlgorithm : TileWorld.TileWorldAlgorithms
---@field public tree BSPDungeonAlgorithm.Leaf[]
---@field public parentTree BSPDungeonAlgorithm.Leaf[]
---@field public rooms BSPDungeonAlgorithm.Room[]
---@field public hallways BSPDungeonAlgorithm.Room[]
local m = {}

---@virtual
---@param _config TileWorld.TileWorldConfiguration
---@return boolean[], UnityEngine.Vector3, UnityEngine.Vector3
function m:Generate(_config) end

BSPDungeonAlgorithm = m
return m
