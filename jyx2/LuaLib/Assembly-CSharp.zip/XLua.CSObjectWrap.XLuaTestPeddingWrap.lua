---@class XLua.CSObjectWrap.XLuaTestPeddingWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.XLuaTestPeddingWrap = m
return m
