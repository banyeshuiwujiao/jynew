---@class BlockActionType : System.Enum
---@field public Enter BlockActionType @static
---@field public Exit BlockActionType @static
---@field public Action BlockActionType @static
---@field public LongPress BlockActionType @static
---@field public value__ number
local m = {}

BlockActionType = m
return m
