---@class AnalogAxisMove : System.Object
---@field public X number
---@field public Y number
local m = {}

AnalogAxisMove = m
return m
