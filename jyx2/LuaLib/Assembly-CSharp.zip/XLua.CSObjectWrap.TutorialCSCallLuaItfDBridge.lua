---@class XLua.CSObjectWrap.TutorialCSCallLuaItfDBridge : XLua.LuaBase
local m = {}

---@static
---@param reference number
---@param luaenv XLua.LuaEnv
---@return XLua.LuaBase
function m.__Create(reference, luaenv) end

XLua.CSObjectWrap.TutorialCSCallLuaItfDBridge = m
return m
