---@class XLua.Cast.Char : XLua.Cast.Any_1_System_Char_
local m = {}

XLua.Cast.Char = m
return m
