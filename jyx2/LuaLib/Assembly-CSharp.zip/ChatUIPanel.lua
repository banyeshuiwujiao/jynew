---@class ChatUIPanel : Jyx2_UIBase
---@field public Layer UILayer
---@field public IsOnly boolean
---@field public CurrentShowType ChatType
local m = {}

function m:OnMainBgClick() end

---@param headId number
---@param msg string
---@param type number
---@param callback fun()
function m:Show(headId, msg, type, callback) end

---@overload fun(headId:number)
---@param headId number
---@param ShowName boolean
function m:ChangePosition(headId, ShowName) end

---@param roleId string
---@param msg string
---@param selectionContent string[]
---@param OnChooseSelection fun(obj:number)
function m:ShowSelection(roleId, msg, selectionContent, OnChooseSelection) end

function m:InitTrans() end

ChatUIPanel = m
return m
