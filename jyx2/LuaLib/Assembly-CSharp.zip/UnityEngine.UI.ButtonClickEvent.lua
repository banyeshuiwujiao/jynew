---@class UnityEngine.UI.ButtonClickEvent : UnityEngine.Events.UnityEvent
local m = {}

UnityEngine.UI.ButtonClickEvent = m
return m
