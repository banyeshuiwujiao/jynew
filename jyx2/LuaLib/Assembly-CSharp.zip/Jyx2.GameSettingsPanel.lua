---@class Jyx2.GameSettingsPanel : Jyx2_UIBase
local m = {}

function m:OnCloseBtnClick() end

function m:TabLeft() end

function m:TabRight() end

Jyx2.GameSettingsPanel = m
return m
