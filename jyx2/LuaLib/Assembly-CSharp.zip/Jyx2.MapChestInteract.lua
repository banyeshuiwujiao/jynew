---@class Jyx2.MapChestInteract : UnityEngine.MonoBehaviour
---@field public clip UnityEngine.AnimationClip
local m = {}

function m:SetOpened() end

---@return Cysharp.Threading.Tasks.UniTask
function m:Open() end

---@overload fun()
---@param action fun()
function m:Close(action) end

Jyx2.MapChestInteract = m
return m
