---@class CameraFilterPack_Distortion_Water_Drop : UnityEngine.MonoBehaviour
---@field public SCShader UnityEngine.Shader
---@field public CenterX number
---@field public CenterY number
---@field public WaveIntensity number
---@field public NumberOfWaves number
local m = {}

CameraFilterPack_Distortion_Water_Drop = m
return m
