---@class XLua.CSObjectWrap.XLuaTestFooExtensionWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.XLuaTestFooExtensionWrap = m
return m
