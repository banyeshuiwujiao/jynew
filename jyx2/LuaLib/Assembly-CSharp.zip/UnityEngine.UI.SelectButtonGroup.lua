---@class UnityEngine.UI.SelectButtonGroup : UnityEngine.EventSystems.UIBehaviour
---@field public OnButtonSelect UnityEngine.UI.SelectButtonGroup.OnButtonSelectEvent
---@field public CurButtonIndex number
---@field public Buttons UnityEngine.UI.SelectButton[]
local m = {}

---@overload fun()
---@param destroy boolean
function m:ClearAllButtonns(destroy) end

---@param btn UnityEngine.UI.SelectButton
function m:RegisterButton(btn) end

---@param btn UnityEngine.UI.SelectButton
function m:UnRegisterButton(btn) end

---@param idx number
function m:SelectIndex(idx) end

function m:ClearSelect() end

UnityEngine.UI.SelectButtonGroup = m
return m
