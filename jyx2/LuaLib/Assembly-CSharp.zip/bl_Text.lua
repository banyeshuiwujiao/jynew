---@class bl_Text : UnityEngine.MonoBehaviour
---@field public LayoutRoot UnityEngine.CanvasGroup
---@field public m_Text UnityEngine.UI.Text
---@field public Rect UnityEngine.RectTransform
---@field public VerticalPositionOffset number
---@field public m_Color UnityEngine.Color
---@field public movement bl_Guidance
---@field public Xcountervail number
---@field public Ycountervail number
---@field public m_Size number
---@field public m_Speed number
---@field public m_text string
---@field public m_Transform UnityEngine.Transform
---@field public Yquickness number
---@field public YquicknessScaleFactor number
---@field public FadeSpeed number
---@field public FloatSpeed number
---@field public Delay number
---@field public isUtil boolean
---@field public Uses number
---@field public fadeCurveTime number
---@field public sizeCurveTime number
local m = {}

---@param id number
---@param speed number
function m:PlayAnimation(id, speed) end

bl_Text = m
return m
