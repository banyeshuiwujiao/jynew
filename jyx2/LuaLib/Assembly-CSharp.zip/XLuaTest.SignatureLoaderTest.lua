---@class XLuaTest.SignatureLoaderTest : UnityEngine.MonoBehaviour
---@field public PUBLIC_KEY string @static
local m = {}

XLuaTest.SignatureLoaderTest = m
return m
