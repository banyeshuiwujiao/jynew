---@class LuaAsset : UnityEngine.ScriptableObject
---@field public LuaDecodeKey string @static
---@field public LuaSearchingPaths string[] @static
---@field public encode boolean
---@field public data string
local m = {}

---@return string
function m:GetDecodeBytes() end

---@overload fun(luapath:string, search:string, retry:number): @static
---@overload fun(luapath:string, search:string): @static
---@overload fun(luapath:string): @static
---@static
---@param luapath System.String
---@return string, System.String
function m.Require(luapath) end

LuaAsset = m
return m
