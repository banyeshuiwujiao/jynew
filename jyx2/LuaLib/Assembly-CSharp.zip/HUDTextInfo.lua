---@class HUDTextInfo : System.Object
---@field public CacheTransform UnityEngine.Transform
---@field public Text string
---@field public Side bl_Guidance
---@field public Size number
---@field public Color UnityEngine.Color
---@field public Speed number
---@field public VerticalAceleration number
---@field public VerticalFactorScale number
---@field public AnimationType bl_HUDText.TextAnimationType
---@field public VerticalPositionOffset number
---@field public AnimationSpeed number
---@field public ExtraDelayTime number
---@field public ExtraFloatSpeed number
---@field public TextPrefab UnityEngine.GameObject
---@field public FadeSpeed number
local m = {}

HUDTextInfo = m
return m
