---@class InitScene : UnityEngine.MonoBehaviour
---@field public TapLogin_Button UnityEngine.UI.Button
local m = {}

InitScene = m
return m
