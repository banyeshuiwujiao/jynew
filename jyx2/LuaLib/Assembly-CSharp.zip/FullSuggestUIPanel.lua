---@class FullSuggestUIPanel : Jyx2_UIBase
---@field public Layer UILayer
local m = {}

function m:OnBgClick() end

function m:InitTrans() end

FullSuggestUIPanel = m
return m
