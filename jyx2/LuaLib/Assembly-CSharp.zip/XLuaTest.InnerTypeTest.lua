---@class XLuaTest.InnerTypeTest : System.Object
local m = {}

function m:Foo() end

XLuaTest.InnerTypeTest = m
return m
