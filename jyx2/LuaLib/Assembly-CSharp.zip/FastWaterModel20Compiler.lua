---@class FastWaterModel20Compiler : UnityEngine.ScriptableObject
---@field public CgincPath string @static
---@field public Support128Shader UnityEngine.Material
---@field public DepthRenderShader_SP UnityEngine.Shader
---@field public DepthRenderShader UnityEngine.Shader
---@field public RefractionRenderShader UnityEngine.Shader
---@field public __cID System.Nullable_1_System_Int32_
---@field public onShaderUpdate fun(obj:FastWaterModel20Compiler)
---@field public BakedRefractionCameraOffset number
---@field public PlanarReflectionClipPlaneOffset number
---@field public PlanarReflectionSkipEveryFrame number
---@field public _keywords string[]
---@field public NowCompile boolean
---@field public Optimized number
---@field public __NeedOptimize boolean
---@field public cID number
---@field public material UnityEngine.Material
---@field public shader UnityEngine.Shader
---@field public WaterType FastWaterModel20Compiler.WaterShaderType
---@field public GetTypeMarker string
---@field public NeedOptimize boolean
---@field public IS_OPAQUE boolean
---@field public IS_GRABPASS boolean
local m = {}

---@static
---@return boolean
function m.EnableAutoREcompileValidate() end

---@static
---@return boolean
function m.EnableAutoREcompileprefs_EnableAutoREcompileEMFastWaterModel20CompilerValidate() end

---@overload fun(actionName:string, action:fun(obj:FastWaterModel20Compiler)) @static
---@static
---@param actionName string
---@param action fun(obj:FastWaterModel20Compiler)
---@param param number
function m.ApplyToAll(actionName, action, param) end

---@return string
function m:GetShaderUniformText() end

---@return FastWaterModel20Compiler.shaderCache
function m:GetShaderUniform() end

---@overload fun()
---@param newShaderName string
function m:UpdateShaderAsset(newShaderName) end

---@param keyword string
---@return boolean
function m:IsKeywordEnabled(keyword) end

---@param keyword string
function m:EnableKeyword(keyword) end

---@param keyword string
function m:EnableKeywordAndNotUpdate(keyword) end

---@param keyword string
function m:DisableKeyword(keyword) end

---@param keyword string
function m:DisableKeywordAndNotUpdate(keyword) end

function m:UpdateCompiler() end

---@overload fun():
---@param newName string
---@return string
function m:CreateShaderString(newName) end

---@param fileName string
---@return string
function m:GetShaderText(fileName) end

---@param __file string
---@param raw_uniform FastWaterModel20Compiler.shaderCache
---@return string, FastWaterModel20Compiler.shaderCache
function m:GetShaderBody(__file, raw_uniform) end

---@overload fun(key:string):
---@param key number
---@return UnityEngine.Color
function m:GetColor(key) end

---@overload fun(key:number, c:UnityEngine.Color)
---@param key string
---@param c UnityEngine.Color
function m:SetColor(key, c) end

---@overload fun(key:string):
---@param key number
---@return UnityEngine.Vector4
function m:GetVector(key) end

---@overload fun(key:string, v:UnityEngine.Vector4)
---@param key number
---@param v UnityEngine.Vector4
function m:SetVector(key, v) end

---@overload fun(key:string):
---@param key number
---@return boolean
function m:HasProperty(key) end

---@overload fun(key:number, t:UnityEngine.Texture)
---@param key string
---@param t UnityEngine.Texture
function m:SetTexture(key, t) end

---@overload fun(key:number):
---@param key string
---@return UnityEngine.Texture
function m:GetTexture(key) end

---@overload fun(key:number, t:number)
---@param key string
---@param t number
function m:SetFloat(key, t) end

---@overload fun(key:number):
---@param key string
---@return number
function m:GetFloat(key) end

FastWaterModel20Compiler = m
return m
