---@class ComponentExtensions : System.Object
local m = {}

---@static
---@param cp UnityEngine.Component
---@return UnityEngine.RectTransform
function m.rectTransform(cp) end

---@static
---@param value number
---@param from1 number
---@param to1 number
---@param from2 number
---@param to2 number
---@return number
function m.Remap(value, from1, to1, from2, to2) end

ComponentExtensions = m
return m
