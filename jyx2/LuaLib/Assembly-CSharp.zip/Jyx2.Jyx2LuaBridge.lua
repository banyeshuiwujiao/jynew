---@class Jyx2.Jyx2LuaBridge : System.Object
---@field public isQuickBattle boolean @static
local m = {}

---@overload fun(roleId:number, content:string, talkName:string, type:number, callback:fun()) @static
---@static
---@param roleId number
---@param content string
---@param callback fun()
function m.Talk(roleId, content, callback) end

---@static
---@param callback fun(obj:boolean)
function m.AskBattle(callback) end

---@static
---@param callback fun(obj:boolean)
function m.AskJoin(callback) end

---@static
---@param callback fun(obj:boolean)
function m.AskRest(callback) end

---@static
---@param callback fun()
function m.WeiShop(callback) end

---@static
---@param message string
---@param callback fun()
function m.ShowMessage(message, callback) end

---@static
---@param callback fun()
function m.ShowEthics(callback) end

---@static
---@param callback fun()
function m.ShowRepute(callback) end

---@static
---@param selectMessage string
---@param callback fun(obj:boolean)
function m.ShowYesOrNoSelectPanel(selectMessage, callback) end

---@static
---@param roleId number
---@param selectMessage string
---@param content XLua.LuaTable
---@param callback fun(obj:number)
function m.ShowSelectPanel(roleId, selectMessage, content, callback) end

---@static
---@param msg string
function m.ShowToast(msg) end

---@static
---@param selectMessage string
---@param YesMessage string
---@param NoMessage string
---@param callback fun(obj:number)
function m.ShowMessageSelectPanel(selectMessage, YesMessage, NoMessage, callback) end

---@static
---@param musicId number
function m.ChangeMMapMusic(musicId) end

---@static
---@param id number
function m.PlayMusic(id) end

---@static
---@param waveIndex number
function m.PlayWave(waveIndex) end

---@static
---@param battleId number
---@param callback fun(obj:boolean)
function m.TryBattle(battleId, callback) end

---@static
function m.jyx2_ShowEndScene() end

---@static
function m.BackToMainMenu() end

---@static
---@param sceneId number
function m.OpenScene(sceneId) end

---@static
---@param callback fun()
function m.DarkScence(callback) end

---@static
---@param callback fun()
function m.LightScence(callback) end

---@static
---@param isOn boolean
function m.ScreenVignette(isOn) end

---@static
---@return number
function m.GetCurrentGameMapid() end

---@static
---@param scene string
---@param path string
---@param replace string
function m.jyx2_ReplaceSceneObject(scene, path, replace) end

---@overload fun(path:string, parent:string) @static
---@overload fun(path:string) @static
---@static
---@param path string
---@param parent string
---@param target string
function m.jyx2_MovePlayer(path, parent, target) end

---@static
---@param path string
function m.jyx2_CameraFollow(path) end

---@static
function m.jyx2_CameraFollowPlayer() end

---@static
---@param fromName number
---@param toName number
---@param callback fun()
function m.jyx2_WalkFromTo(fromName, toName, callback) end

---@overload fun(rolePath:string, animationControllerPath:string) @static
---@static
---@param rolePath string
---@param animationControllerPath string
---@param scene string
function m.jyx2_SwitchRoleAnimation(rolePath, animationControllerPath, scene) end

---@static
---@param duration number
---@param callback fun()
function m.jyx2_Wait(duration, callback) end

---@static
---@param timelineName string
function m.jyx2_StopTimeline(timelineName) end

---@static
---@param speed number
function m.jyx2_SetTimelineSpeed(speed) end

---@overload fun(timelineName:string, hidePlayer:boolean, hideGameObject:string) @static
---@overload fun(timelineName:string, hidePlayer:boolean) @static
---@overload fun(timelineName:string) @static
---@static
---@param timelineName string
---@param hidePlayer boolean
---@param hideGameObject string
---@param hideUI boolean
function m.jyx2_PlayTimelineSimple(timelineName, hidePlayer, hideGameObject, hideUI) end

---@static
---@param timelineName string
---@param playMode number
---@param isMovePlayer boolean
---@param tagRole string
function m.jyx2_PlayTimeline(timelineName, playMode, isMovePlayer, tagRole) end

---@static
---@param flagKey string
---@param value string
function m.jyx2_SetFlag(flagKey, value) end

---@static
---@param flagKey string
---@return string
function m.jyx2_GetFlag(flagKey) end

---@static
---@param flagKey string
---@param value number
function m.jyx2_SetFlagInt(flagKey, value) end

---@static
---@param flagKey string
---@return number
function m.jyx2_GetFlagInt(flagKey) end

---@static
---@param roleId number
---@param magicId number
---@param noDisplay number
function m.LearnMagic2(roleId, magicId, noDisplay) end

---@static
---@param roleId number
---@param v number
function m.SetOneUsePoi(roleId, v) end

---@static
---@param roleId number
---@return number
function m.GetRoleLevel(roleId) end

---@static
---@param roleId number
---@param itemId number
function m.RoleUseItem(roleId, itemId) end

---@static
---@param roleId number
---@param itemId number
function m.RoleUnequipItem(roleId, itemId) end

---@static
---@param roleId number
---@param magicIndexRole number
---@param magicId number
---@param level number
function m.SetOneMagic(roleId, magicIndexRole, magicId, level) end

---@static
---@param roleId number
---@param value number
function m.SetPersonMPPro(roleId, value) end

---@static
---@param roleId number
---@param sexual number
function m.SetSexual(roleId, sexual) end

---@static
---@param roleId number
---@param itemId number
---@param count number
function m.NPCGetItem(roleId, itemId, count) end

---@static
---@param roleId number
---@param low number
---@param high number
---@return boolean
function m.JudgeEthics(roleId, low, high) end

---@static
---@param roleId number
---@param low number
---@param high number
---@return boolean
function m.JudgeAttack(roleId, low, high) end

---@static
---@param roleId number
---@param low number
---@param high number
---@return boolean
function m.JudgeWCH(roleId, low, high) end

---@static
---@param roleId number
---@param low number
---@param high number
---@return boolean
function m.JudgeHeal(roleId, low, high) end

---@static
---@param roleId number
---@param low number
---@param high number
---@return boolean
function m.JudgeQuanzhang(roleId, low, high) end

---@static
---@param roleId number
---@param low number
---@param high number
---@return boolean
function m.JudgeYujian(roleId, low, high) end

---@static
---@param roleId number
---@param low number
---@param high number
---@return boolean
function m.JudgeAttackPoison(roleId, low, high) end

---@static
---@param roleId number
---@param low number
---@param high number
---@return boolean
function m.JudgeQimen(roleId, low, high) end

---@static
---@param roleId number
---@param low number
---@param high number
---@return boolean
function m.JudgeDefence(roleId, low, high) end

---@static
---@param roleId number
---@param low number
---@param high number
---@return boolean
function m.JudgeIQ(roleId, low, high) end

---@static
---@param roleId number
---@param attrName string
---@param v number
---@param dispName string
function m.AddAttr(roleId, attrName, v, dispName) end

---@static
---@param roleId number
---@param v number
function m.AddAptitude(roleId, v) end

---@static
---@param roleId number
---@param value number
function m.AddHeal(roleId, value) end

---@static
---@param roleId number
---@param value number
function m.AddDefence(roleId, value) end

---@static
---@param roleId number
---@param value number
function m.AddQuanzhang(roleId, value) end

---@static
---@param roleId number
---@param value number
function m.AddShuadao(roleId, value) end

---@static
---@param roleId number
---@param value number
function m.AddYujian(roleId, value) end

---@static
---@param roleId number
---@param value number
function m.AddAnqi(roleId, value) end

---@static
---@param roleId number
---@param value number
function m.AddQimen(roleId, value) end

---@static
---@param roleId number
---@param value number
function m.AddWuchang(roleId, value) end

---@static
---@param roleId number
---@param value number
function m.AddAttackPoison(roleId, value) end

---@static
---@param roleId number
---@param value number
function m.AddAntiPoison(roleId, value) end

---@static
---@param roleId number
---@param value number
function m.AddExp(roleId, value) end

---@static
---@param roleId number
---@param value number
function m.AddExpWithoutHint(roleId, value) end

---@static
---@param roleId number
---@param value number
---@return number
function m.AddLevelreturnUper(roleId, value) end

---@static
---@param roleId number
---@param value number
function m.AddSpeed(roleId, value) end

---@static
---@param roleId number
---@param value number
function m.AddMp(roleId, value) end

---@static
---@param roleId number
---@param value number
function m.AddMpWithoutHint(roleId, value) end

---@static
---@param roleId number
---@param value number
function m.AddAttack(roleId, value) end

---@static
---@param roleId number
---@param value number
function m.AddHp(roleId, value) end

---@static
---@param roleId number
---@param value number
function m.AddHpWithoutHint(roleId, value) end

---@static
---@param itemId number
---@param count number
function m.AddItem(itemId, count) end

---@static
---@param itemId number
---@param count number
function m.AddItemWithoutHint(itemId, count) end

---@static
---@param itemId number
---@return boolean
function m.HaveItem(itemId) end

---@static
---@param itemId number
---@return boolean
function m.UseItem(itemId) end

---@static
---@param value number
function m.AddEthics(value) end

---@static
---@param value number
function m.AddRepute(value) end

---@static
function m.Dead() end

---@static
---@param money number
---@return boolean
function m.JudgeMoney(money) end

---@static
---@param sexual number
---@return boolean
function m.JudgeSexual(sexual) end

---@static
---@return number
function m.GetMoneyCount() end

---@static
---@param dir number
function m.SetRoleFace(dir) end

---@static
---@param roleId number
function m.Join(roleId) end

---@static
---@param roleId number
function m.JoinWithoutHint(roleId) end

---@static
---@param roleId number
function m.Leave(roleId) end

---@static
---@param roleId number
function m.LeaveWithoutHint(roleId) end

---@static
function m.ZeroAllMP() end

---@static
---@param roleId number
---@return boolean
function m.InTeam(roleId) end

---@static
---@return boolean
function m.TeamIsFull() end

---@static
function m.RestTeam() end

---@static
function m.Rest() end

---@static
function m.RestFight() end

---@static
---@return boolean
function m.JudgeFemaleInTeam() end

---@static
---@return number
function m.GetTeamMembersCount() end

---@static
---@return number
function m.GetTeamTotalHp() end

---@static
---@return number
function m.GetTeamTotalLevel() end

---@static
function m.AllLeave() end

---@static
---@return number
function m.GetTeamMaxLevel() end

---@static
---@return number[]
function m.GetTeamId() end

---@static
---@param ret string
function m.LuaExecFinished(ret) end

---@static
---@param scene number
---@param eventId number
---@param canPass number
---@param changeToEventId number
---@param interactiveEventId number
---@param useItemEventId number
---@param enterEventId number
---@param p7 number
---@param p8 number
---@param p9 number
---@param p10 number
---@param p11 number
---@param p12 number
function m.ModifyEvent(scene, eventId, canPass, changeToEventId, interactiveEventId, useItemEventId, enterEventId, p7, p8, p9, p10, p11, p12) end

---@static
---@param scene number
---@param eventId number
---@param pic number
---@return boolean
function m.JudgeScenePic(scene, eventId, pic) end

---@static
---@return number
function m.GetCurrentEventID() end

---@static
---@param scene number
---@param eventId number
---@param v1 number
---@param v2 number
---@param v3 number
function m.Add3EventNum(scene, eventId, v1, v2, v3) end

---@static
---@param eventIndex number
---@param value number
---@return boolean
function m.JudgeEventNum(eventIndex, value) end

---@static
---@param eventIndex number
---@param EventId number
---@param value number
---@return boolean
function m.JudgePointEventNum(eventIndex, EventId, value) end

---@static
function m.PreloadLua() end

---@static
---@param a number
---@param b number
---@return number
function m.GetImbalancedRandomInt(a, b) end

---@overload fun(Event:string, p1:any, p2:any) @static
---@overload fun(Event:string, p1:any, p2:any, p3:any) @static
---@static
---@param Event string
---@param p1 any
function m.DispatchLuaEvent(Event, p1) end

---@static
---@param roleId number
---@param content string
---@param talkName string
---@param type number
---@return Cysharp.Threading.Tasks.UniTask
function m.TalkAsync(roleId, content, talkName, type) end

---@static
---@param battle Jyx2.LBattleConfig
---@param callback fun(obj:boolean)
function m.TryBattleWithConfig(battle, callback) end

---@static
---@param fromName number
---@param toName number
---@return Cysharp.Threading.Tasks.UniTask
function m.jyx2_WalkFromToAsync(fromName, toName) end

---@static
function m.OpenAllScene() end

---@static
function m.FightForTop() end

---@static
---@return Cysharp.Threading.Tasks.UniTask
function m.FightForTopAsync() end

---@static
function m.EnterPond() end

---@static
function m.LeavePond() end

---@static
---@return boolean
function m.Judge14BooksPlaced() end

---@static
---@param callback fun()
function m.AskSoftStar(callback) end

---@static
---@return boolean
function m.jyx2_CheckBookAndRepute() end

---@static
---@param sceneId number
---@param layer number
---@param x number
---@param y number
---@param v number
function m.SetScenceMap(sceneId, layer, x, y, v) end

---@static
---@param p1 number
---@param p2 number
---@param p3 number
---@param p4 number
function m.ChangeScencePic(p1, p2, p3, p4) end

---@static
---@param p1 number
---@param p2 number
---@param p3 number
function m.PlayAnimation(p1, p2, p3) end

---@static
---@param x1 number
---@param y1 number
---@param x2 number
---@param y2 number
function m.WalkFromTo(x1, y1, x2, y2) end

---@static
---@param x number
---@param y number
---@param x2 number
---@param y2 number
function m.ScenceFromTo(x, y, x2, y2) end

---@static
---@param eventIndex1 number
---@param beginPic1 number
---@param endPic1 number
---@param eventIndex2 number
---@param beginPic2 number
---@param endPic2 number
function m.Play2Amination(eventIndex1, beginPic1, endPic1, eventIndex2, beginPic2, endPic2) end

---@static
---@param p1 number
---@param p2 number
---@param p3 number
---@param p4 number
---@param p5 number
---@param p6 number
---@param p7 number
function m.instruct_50(p1, p2, p3, p4, p5, p6, p7) end

---@static
---@param p1 number
---@param p2 number
---@param p3 number
---@param p4 number
---@param p5 number
---@param p6 number
---@param p7 number
function m.EndAmination(p1, p2, p3, p4, p5, p6, p7) end

---@static
---@param x number
---@param y number
function m.SetScencePosition2(x, y) end

---@static
function m.instruct_57() end

---@static
---@param scene number
---@param eventId number
---@param targetEvent number
---@return number
function m.jyx2_CheckEventCount(scene, eventId, targetEvent) end

---@static
---@param key string
---@param value string
function m.jyx2_FixMapObject(key, value) end

---@overload fun(gameObjectPathInLevel:string, functionName:string): @static
---@static
---@param gameObjectPathInLevel string
---@param functionName string
---@param radius number
---@return boolean
function m.FastBindEventToObj(gameObjectPathInLevel, functionName, radius) end

---@static
---@param gameObjectPathInLevel string
---@return boolean
function m.RegisterDynamicSceneObj(gameObjectPathInLevel) end

---@static
---@param gameObjectPathInLevel string
---@param isActive boolean
---@return boolean
function m.DynamicSceneObjSetActive(gameObjectPathInLevel, isActive) end

---@static
---@param flag string
---@param v number
function m.SetSceneFlagInt(flag, v) end

---@static
---@param flag string
---@return number
function m.GetSceneFlagInt(flag) end

---@static
---@param flag string
---@param v string
function m.SetSceneFlagString(flag, v) end

---@static
---@param flag string
---@return string
function m.GetSceneFlagString(flag) end

---@static
---@param flag string
---@param v boolean
function m.SetSceneFlagBool(flag, v) end

---@static
---@param flag string
---@return boolean
function m.GetSceneFlagBool(flag) end

Jyx2.Jyx2LuaBridge = m
return m
