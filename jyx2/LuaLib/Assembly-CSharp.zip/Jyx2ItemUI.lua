---@class Jyx2ItemUI : UnityEngine.UI.Selectable
---@field public m_Image UnityEngine.UI.Image
---@field public m_NameText UnityEngine.UI.Text
---@field public m_CountText UnityEngine.UI.Text
---@field public ItemId number
---@field public IsSelected boolean
local m = {}

---@param value fun(obj:Jyx2ItemUI)
function m:add_OnItemSelect(value) end

---@param value fun(obj:Jyx2ItemUI)
function m:remove_OnItemSelect(value) end

---@return Jyx2.LItemConfig
function m:GetItemConfigData() end

---@virtual
---@return UnityEngine.UI.Selectable
function m:GetSelectable() end

---@overload fun(up:Jyx2.UINavigation.INavigable, down:Jyx2.UINavigation.INavigable, left:Jyx2.UINavigation.INavigable) @virtual
---@overload fun(up:Jyx2.UINavigation.INavigable, down:Jyx2.UINavigation.INavigable) @virtual
---@overload fun(up:Jyx2.UINavigation.INavigable) @virtual
---@overload fun() @virtual
---@virtual
---@param up Jyx2.UINavigation.INavigable
---@param down Jyx2.UINavigation.INavigable
---@param left Jyx2.UINavigation.INavigable
---@param right Jyx2.UINavigation.INavigable
function m:Connect(up, down, left, right) end

---@virtual
---@param notifyEvent boolean
function m:Select(notifyEvent) end

---@param state boolean
---@param notifyEvent boolean
function m:SetSelectState(state, notifyEvent) end

---@virtual
---@param data System.Collections.Generic.KeyValuePair_2_System_String_System_ValueTuple_2_System_Int32_System_Int32__
function m:SetData(data) end

---@virtual
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnPointerClick(eventData) end

---@virtual
---@param eventData UnityEngine.EventSystems.BaseEventData
function m:OnSelect(eventData) end

Jyx2ItemUI = m
return m
