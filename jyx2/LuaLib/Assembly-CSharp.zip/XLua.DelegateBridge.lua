---@class XLua.DelegateBridge : XLua.DelegateBridgeBase
---@field public Gen_Flag boolean @static
local m = {}

---@param p0 number
function m:__Gen_Delegate_Imp0(p0) end

---@param p0 string
function m:__Gen_Delegate_Imp1(p0) end

---@param p0 number
function m:__Gen_Delegate_Imp2(p0) end

---@param p0 boolean
function m:__Gen_Delegate_Imp3(p0) end

---@param p0 number
function m:__Gen_Delegate_Imp4(p0) end

---@param p0 number
function m:__Gen_Delegate_Imp5(p0) end

---@param p0 number
function m:__Gen_Delegate_Imp6(p0) end

function m:__Gen_Delegate_Imp7() end

---@param p0 number
---@param p1 number
---@return number
function m:__Gen_Delegate_Imp8(p0, p1) end

---@param p0 number
function m:__Gen_Delegate_Imp9(p0) end

---@param p0 number
---@return number
function m:__Gen_Delegate_Imp10(p0) end

---@param p0 UnityEngine.Vector3
---@return UnityEngine.Vector3
function m:__Gen_Delegate_Imp11(p0) end

---@param p0 XLuaTest.MyStruct
---@return XLuaTest.MyStruct
function m:__Gen_Delegate_Imp12(p0) end

---@param p0 XLuaTest.MyEnum
---@return XLuaTest.MyEnum
function m:__Gen_Delegate_Imp13(p0) end

---@param p0 System.Decimal
---@return System.Decimal
function m:__Gen_Delegate_Imp14(p0) end

---@param p0 System.Array
function m:__Gen_Delegate_Imp15(p0) end

---@param p0 number
---@param p1 string
---@return number, Tutorial.CSCallLua.DClass
function m:__Gen_Delegate_Imp16(p0, p1) end

---@return fun()
function m:__Gen_Delegate_Imp17() end

---@param p0 number
---@param p1 string[]
---@return XLuaTest.InvokeLua.ICalc
function m:__Gen_Delegate_Imp18(p0, p1) end

---@param p0 any
function m:__Gen_Delegate_Imp19(p0) end

---@param p0 any
---@return number
function m:__Gen_Delegate_Imp20(p0) end

---@param p0 any
---@return string
function m:__Gen_Delegate_Imp21(p0) end

---@param p0 any
---@return Jyx2.ModelAsset
function m:__Gen_Delegate_Imp22(p0) end

---@param p0 any
---@return boolean
function m:__Gen_Delegate_Imp23(p0) end

---@param p0 any
---@param p1 number
---@return number
function m:__Gen_Delegate_Imp24(p0, p1) end

---@param p0 any
---@param p1 number
---@param p2 number
---@param p3 number
---@param p4 number
---@return number
function m:__Gen_Delegate_Imp25(p0, p1, p2, p3, p4) end

---@param p0 any
---@param p1 number
---@param p2 number
---@param p3 number
---@return number
function m:__Gen_Delegate_Imp26(p0, p1, p2, p3) end

---@param p0 any
---@param p1 any
---@param p2 number
---@return number
function m:__Gen_Delegate_Imp27(p0, p1, p2) end

---@param p0 any
---@return Jyx2.LItemConfig
function m:__Gen_Delegate_Imp28(p0) end

---@param p0 any
---@param p1 boolean
---@return Jyx2.SkillCastInstance[]
function m:__Gen_Delegate_Imp29(p0, p1) end

---@param p0 any
---@param p1 number
---@return boolean
function m:__Gen_Delegate_Imp30(p0, p1) end

---@param p0 any
---@param p1 number
---@param p2 number
function m:__Gen_Delegate_Imp31(p0, p1, p2) end

---@param p0 any
---@param p1 any
---@return boolean
function m:__Gen_Delegate_Imp32(p0, p1) end

---@param p0 any
---@param p1 number
---@param p2 number
---@return boolean
function m:__Gen_Delegate_Imp33(p0, p1, p2) end

---@param p0 any
---@return Jyx2.GameRuntimeData
function m:__Gen_Delegate_Imp34(p0) end

---@param p0 any
---@param p1 any
---@return string
function m:__Gen_Delegate_Imp35(p0, p1) end

---@param p0 any
---@param p1 any
function m:__Gen_Delegate_Imp36(p0, p1) end

---@param p0 any
---@param p1 any
---@return number
function m:__Gen_Delegate_Imp37(p0, p1) end

---@param p0 any
---@return Jyx2.LRoleConfig
function m:__Gen_Delegate_Imp38(p0) end

---@param p0 any
---@return BattleRole
function m:__Gen_Delegate_Imp39(p0) end

---@param p0 any
---@return Jyx2.BattleBlockVector
function m:__Gen_Delegate_Imp40(p0) end

---@param p0 any
---@param p1 number
function m:__Gen_Delegate_Imp41(p0, p1) end

---@param p0 any
---@param p1 any
---@param p2 boolean
function m:__Gen_Delegate_Imp42(p0, p1, p2) end

---@param p0 any
---@param p1 number
function m:__Gen_Delegate_Imp43(p0, p1) end

---@param p0 any
---@return Jyx2.RoleInstance
function m:__Gen_Delegate_Imp44(p0) end

---@return Jyx2.GameRuntimeData
function m:__Gen_Delegate_Imp45() end

---@param p0 number
---@param p1 any
---@param p2 any
function m:__Gen_Delegate_Imp46(p0, p1, p2) end

---@param p0 number
---@param p1 any
---@param p2 any
---@param p3 number
---@param p4 any
function m:__Gen_Delegate_Imp47(p0, p1, p2, p3, p4) end

---@param p0 number
---@param p1 any
---@param p2 any
---@param p3 any
function m:__Gen_Delegate_Imp48(p0, p1, p2, p3) end

---@param p0 any
---@param p1 any
---@param p2 any
---@param p3 any
function m:__Gen_Delegate_Imp49(p0, p1, p2, p3) end

---@param p0 number
---@param p1 any
function m:__Gen_Delegate_Imp50(p0, p1) end

---@return number
function m:__Gen_Delegate_Imp51() end

---@param p0 any
---@param p1 any
---@param p2 any
function m:__Gen_Delegate_Imp52(p0, p1, p2) end

---@param p0 number
---@param p1 number
---@param p2 any
function m:__Gen_Delegate_Imp53(p0, p1, p2) end

---@param p0 number
---@param p1 any
function m:__Gen_Delegate_Imp54(p0, p1) end

---@param p0 any
---@param p1 boolean
---@param p2 any
---@param p3 boolean
function m:__Gen_Delegate_Imp55(p0, p1, p2, p3) end

---@param p0 any
---@param p1 number
---@param p2 boolean
---@param p3 any
function m:__Gen_Delegate_Imp56(p0, p1, p2, p3) end

---@param p0 number
---@param p1 number
---@param p2 number
function m:__Gen_Delegate_Imp57(p0, p1, p2) end

---@param p0 number
---@param p1 number
function m:__Gen_Delegate_Imp58(p0, p1) end

---@param p0 number
---@param p1 number
---@param p2 number
---@param p3 number
function m:__Gen_Delegate_Imp59(p0, p1, p2, p3) end

---@param p0 number
---@param p1 number
---@param p2 number
---@return boolean
function m:__Gen_Delegate_Imp60(p0, p1, p2) end

---@param p0 number
---@param p1 any
---@param p2 number
---@param p3 any
function m:__Gen_Delegate_Imp61(p0, p1, p2, p3) end

---@param p0 number
---@param p1 number
---@return number
function m:__Gen_Delegate_Imp62(p0, p1) end

---@param p0 number
---@return boolean
function m:__Gen_Delegate_Imp63(p0) end

---@return boolean
function m:__Gen_Delegate_Imp64() end

---@return number[]
function m:__Gen_Delegate_Imp65() end

---@param p0 number
---@param p1 number
---@param p2 number
---@param p3 number
---@param p4 number
---@param p5 number
---@param p6 number
---@param p7 number
---@param p8 number
---@param p9 number
---@param p10 number
---@param p11 number
---@param p12 number
function m:__Gen_Delegate_Imp66(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12) end

---@param p0 number
---@param p1 number
---@param p2 number
---@param p3 number
---@param p4 number
function m:__Gen_Delegate_Imp67(p0, p1, p2, p3, p4) end

---@param p0 number
---@param p1 number
---@return boolean
function m:__Gen_Delegate_Imp68(p0, p1) end

---@return XLua.LuaFunction
function m:__Gen_Delegate_Imp69() end

---@param p0 number
---@param p1 any
---@param p2 any
---@param p3 number
---@return Cysharp.Threading.Tasks.UniTask
function m:__Gen_Delegate_Imp70(p0, p1, p2, p3) end

---@param p0 number
---@return Cysharp.Threading.Tasks.UniTask_1_System_Boolean_
function m:__Gen_Delegate_Imp71(p0) end

---@return Cysharp.Threading.Tasks.UniTask
function m:__Gen_Delegate_Imp72() end

---@param p0 number
---@return boolean, Jyx2.RoleInstance
function m:__Gen_Delegate_Imp73(p0) end

---@param p0 number
---@param p1 any
---@return boolean
function m:__Gen_Delegate_Imp74(p0, p1) end

---@param p0 number
---@param p1 number
---@return Cysharp.Threading.Tasks.UniTask
function m:__Gen_Delegate_Imp75(p0, p1) end

---@param p0 number
---@return Cysharp.Threading.Tasks.UniTask
function m:__Gen_Delegate_Imp76(p0) end

---@param p0 number
---@param p1 number
---@param p2 number
---@param p3 number
---@param p4 number
---@param p5 number
function m:__Gen_Delegate_Imp77(p0, p1, p2, p3, p4, p5) end

---@param p0 number
---@param p1 number
---@param p2 number
---@param p3 number
---@param p4 number
---@param p5 number
---@param p6 number
function m:__Gen_Delegate_Imp78(p0, p1, p2, p3, p4, p5, p6) end

---@param p0 number
---@param p1 number
---@param p2 number
---@return number
function m:__Gen_Delegate_Imp79(p0, p1, p2) end

---@param p0 any
---@return boolean, UnityEngine.GameObject
function m:__Gen_Delegate_Imp80(p0) end

---@param p0 any
---@param p1 any
---@param p2 number
---@return boolean
function m:__Gen_Delegate_Imp81(p0, p1, p2) end

---@param p0 any
---@param p1 boolean
---@return boolean
function m:__Gen_Delegate_Imp82(p0, p1) end

---@param p0 any
---@param p1 boolean
function m:__Gen_Delegate_Imp83(p0, p1) end

---@param p0 any
---@param p1 any
---@param p2 any
---@return UnityEngine.Transform
function m:__Gen_Delegate_Imp84(p0, p1, p2) end

---@param p0 any
---@return UnityEngine.Material
function m:__Gen_Delegate_Imp85(p0) end

---@param p0 any
---@param p1 any
---@param p2 any
---@return UnityEngine.Texture3D
function m:__Gen_Delegate_Imp86(p0, p1, p2) end

---@param p0 any
---@return UnityEngine.RectTransform
function m:__Gen_Delegate_Imp87(p0) end

---@param p0 number
---@param p1 number
---@param p2 number
---@param p3 number
---@param p4 number
---@return number
function m:__Gen_Delegate_Imp88(p0, p1, p2, p3, p4) end

---@param p0 any
---@param p1 ETCArea.AreaPreset
function m:__Gen_Delegate_Imp89(p0, p1) end

---@param p0 any
---@return UnityEngine.Transform
function m:__Gen_Delegate_Imp90(p0) end

---@param p0 any
---@param p1 number
---@param p2 boolean
---@param p3 ETCBase.ControlType
---@param p4 boolean
function m:__Gen_Delegate_Imp91(p0, p1, p2, p3, p4) end

---@param p0 any
---@param p1 number
---@param p2 ETCBase.ControlType
---@param p3 boolean
---@param p4 boolean
function m:__Gen_Delegate_Imp92(p0, p1, p2, p3, p4) end

---@param p0 any
---@return UnityEngine.Vector3
function m:__Gen_Delegate_Imp93(p0) end

---@param p0 any
---@return number
function m:__Gen_Delegate_Imp94(p0) end

---@param p0 any
---@return ETCBase.RectAnchor
function m:__Gen_Delegate_Imp95(p0) end

---@param p0 any
---@param p1 ETCBase.RectAnchor
function m:__Gen_Delegate_Imp96(p0, p1) end

---@param p0 any
---@return UnityEngine.Vector2
function m:__Gen_Delegate_Imp97(p0) end

---@param p0 any
---@param p1 UnityEngine.Vector2
function m:__Gen_Delegate_Imp98(p0, p1) end

---@param p0 any
---@param p1 UnityEngine.Vector2
---@return UnityEngine.GameObject
function m:__Gen_Delegate_Imp99(p0, p1) end

---@param p0 any
---@return System.Collections.IEnumerator
function m:__Gen_Delegate_Imp100(p0) end

---@param p0 any
---@param p1 UnityEngine.Vector2
---@param p2 any
function m:__Gen_Delegate_Imp101(p0, p1, p2) end

---@return ETCInput
function m:__Gen_Delegate_Imp102() end

---@param p0 any
---@param p1 ETCBase.DPadAxis
function m:__Gen_Delegate_Imp103(p0, p1) end

---@param p0 any
---@return ETCBase.DPadAxis
function m:__Gen_Delegate_Imp104(p0) end

---@param p0 any
---@return ETCJoystick
function m:__Gen_Delegate_Imp105(p0) end

---@param p0 any
---@return ETCDPad
function m:__Gen_Delegate_Imp106(p0) end

---@param p0 any
---@return ETCTouchPad
function m:__Gen_Delegate_Imp107(p0) end

---@param p0 any
---@return ETCButton
function m:__Gen_Delegate_Imp108(p0) end

---@param p0 any
---@param p1 any
---@param p2 UnityEngine.Color
function m:__Gen_Delegate_Imp109(p0, p1, p2) end

---@param p0 any
---@param p1 any
---@param p2 any
---@param p3 UnityEngine.Color
function m:__Gen_Delegate_Imp110(p0, p1, p2, p3) end

---@param p0 any
---@param p1 number
---@param p2 number
function m:__Gen_Delegate_Imp111(p0, p1, p2) end

---@param p0 any
---@param p1 ETCAxis.DirectAction
function m:__Gen_Delegate_Imp112(p0, p1) end

---@param p0 any
---@return ETCAxis.DirectAction
function m:__Gen_Delegate_Imp113(p0) end

---@param p0 any
---@param p1 ETCAxis.AxisInfluenced
function m:__Gen_Delegate_Imp114(p0, p1) end

---@param p0 any
---@return ETCAxis.AxisInfluenced
function m:__Gen_Delegate_Imp115(p0) end

---@param p0 any
---@param p1 UnityEngine.Vector2
---@param p2 UnityEngine.Vector2
---@return boolean, UnityEngine.Vector2, UnityEngine.Vector2
function m:__Gen_Delegate_Imp116(p0, p1, p2) end

---@param p0 any
---@param p1 UnityEngine.Vector2
---@param p2 UnityEngine.Vector2
---@return boolean, UnityEngine.Vector2
function m:__Gen_Delegate_Imp117(p0, p1, p2) end

---@param p0 any
---@return QuickOutline.Mode
function m:__Gen_Delegate_Imp118(p0) end

---@param p0 any
---@param p1 QuickOutline.Mode
function m:__Gen_Delegate_Imp119(p0, p1) end

---@param p0 any
---@return UnityEngine.Color
function m:__Gen_Delegate_Imp120(p0) end

---@param p0 any
---@param p1 UnityEngine.Color
function m:__Gen_Delegate_Imp121(p0, p1) end

---@param p0 any
---@param p1 any
---@return UnityEngine.Vector3[]
function m:__Gen_Delegate_Imp122(p0, p1) end

---@param p0 any
---@return UnityEngine.Camera
function m:__Gen_Delegate_Imp123(p0) end

---@param p0 any
---@param p1 any
---@param p2 any
---@param p3 bl_Guidance
function m:__Gen_Delegate_Imp124(p0, p1, p2, p3) end

---@param p0 any
---@param p1 any
---@param p2 any
---@param p3 UnityEngine.Color
---@param p4 number
---@param p5 number
---@param p6 number
---@param p7 number
---@param p8 bl_Guidance
function m:__Gen_Delegate_Imp125(p0, p1, p2, p3, p4, p5, p6, p7, p8) end

---@param p0 any
---@param p1 any
---@return bl_Text
function m:__Gen_Delegate_Imp126(p0, p1) end

---@param p0 any
---@return bl_Guidance
function m:__Gen_Delegate_Imp127(p0) end

---@param p0 any
---@param p1 bl_Guidance
function m:__Gen_Delegate_Imp128(p0, p1) end

---@param p0 any
---@param p1 number
---@param p2 number
function m:__Gen_Delegate_Imp129(p0, p1, p2) end

---@return bl_HUDText
function m:__Gen_Delegate_Imp130() end

---@param p0 any
---@param p1 any
---@return boolean[], UnityEngine.Vector3, UnityEngine.Vector3
function m:__Gen_Delegate_Imp131(p0, p1) end

---@param p0 any
---@param p1 any
---@return boolean[]
function m:__Gen_Delegate_Imp132(p0, p1) end

---@param p0 any
---@param p1 any
---@param p2 any
---@return boolean[]
function m:__Gen_Delegate_Imp133(p0, p1, p2) end

---@param p0 any
---@param p1 number
---@param p2 number
---@return boolean[]
function m:__Gen_Delegate_Imp134(p0, p1, p2) end

---@param p0 any
---@param p1 any
---@param p2 number
---@param p3 number
function m:__Gen_Delegate_Imp135(p0, p1, p2, p3) end

---@param p0 any
---@param p1 any
---@return UnityEngine.Vector2
function m:__Gen_Delegate_Imp136(p0, p1) end

---@param p0 any
---@param p1 number
---@param p2 number
---@param p3 number
---@param p4 number
---@param p5 number
function m:__Gen_Delegate_Imp137(p0, p1, p2, p3, p4, p5) end

---@param p0 any
---@param p1 number
---@param p2 number
---@param p3 number
function m:__Gen_Delegate_Imp138(p0, p1, p2, p3) end

---@param p0 any
---@param p1 any
---@param p2 any
---@param p3 any
---@return boolean[]
function m:__Gen_Delegate_Imp139(p0, p1, p2, p3) end

---@param p0 any
---@param p1 number
---@param p2 number
---@param p3 number
---@return number
function m:__Gen_Delegate_Imp140(p0, p1, p2, p3) end

---@param p0 any
---@param p1 BattleBlockStatus
function m:__Gen_Delegate_Imp141(p0, p1) end

---@param p0 any
---@return BattleBlockStatus
function m:__Gen_Delegate_Imp142(p0) end

---@param p0 any
---@return Jyx2.LBattleConfig
function m:__Gen_Delegate_Imp143(p0) end

---@param p0 any
---@param p1 any
---@param p2 any
---@return Cysharp.Threading.Tasks.UniTask
function m:__Gen_Delegate_Imp144(p0, p1, p2) end

---@param p0 any
---@param p1 any
---@param p2 any
---@param p3 any
---@return Cysharp.Threading.Tasks.UniTask
function m:__Gen_Delegate_Imp145(p0, p1, p2, p3) end

---@param p0 any
---@param p1 any
---@param p2 number
function m:__Gen_Delegate_Imp146(p0, p1, p2) end

---@param p0 any
---@param p1 BattleLoader.BattlePosRole
---@return Jyx2.RoleInstance
function m:__Gen_Delegate_Imp147(p0, p1) end

---@param p0 any
---@param p1 any
---@param p2 number
---@return UnityEngine.Transform
function m:__Gen_Delegate_Imp148(p0, p1, p2) end

---@param p0 any
---@param p1 any
---@param p2 number
---@param p3 any
---@return Cysharp.Threading.Tasks.UniTask
function m:__Gen_Delegate_Imp149(p0, p1, p2, p3) end

---@return BattleboxHelper
function m:__Gen_Delegate_Imp150() end

---@param p0 any
---@param p1 UnityEngine.Vector3
---@return boolean
function m:__Gen_Delegate_Imp151(p0, p1) end

---@param p0 any
---@param p1 UnityEngine.Vector3
function m:__Gen_Delegate_Imp152(p0, p1) end

---@param p0 any
---@param p1 number
---@param p2 number
---@return Jyx2.BattleBlockData
function m:__Gen_Delegate_Imp153(p0, p1, p2) end

---@param p0 any
---@return Jyx2.BattleBlockData[]
function m:__Gen_Delegate_Imp154(p0) end

---@param p0 any
---@param p1 UnityEngine.Vector3
---@return Jyx2.BattleBlockData
function m:__Gen_Delegate_Imp155(p0, p1) end

---@param p0 any
---@param p1 any
---@param p2 any
---@param p3 Jyx2.BattleBlockType
---@param p4 boolean
function m:__Gen_Delegate_Imp156(p0, p1, p2, p3, p4) end

---@param p0 any
---@param p1 UnityEngine.Vector3
---@param p2 number
function m:__Gen_Delegate_Imp157(p0, p1, p2) end

---@param p0 any
---@return UnityEngine.Bounds
function m:__Gen_Delegate_Imp158(p0) end

---@param p0 any
---@param p1 number
---@param p2 number
---@return System.Numerics.Vector2
function m:__Gen_Delegate_Imp159(p0, p1, p2) end

---@param p0 any
---@param p1 UnityEngine.Vector3
---@param p2 number
---@return boolean, UnityEngine.Vector3, UnityEngine.Vector3
function m:__Gen_Delegate_Imp160(p0, p1, p2) end

---@param p0 any
---@return UnityEngine.GameObject
function m:__Gen_Delegate_Imp161(p0) end

---@param p0 any
---@param p1 UnityEngine.Vector3
---@param p2 UnityEngine.Color
---@param p3 number
---@param p4 number
---@param p5 UnityEngine.Vector3
---@param p6 any
---@param p7 boolean
function m:__Gen_Delegate_Imp162(p0, p1, p2, p3, p4, p5, p6, p7) end

---@param p0 any
---@param p1 UnityEngine.Vector3
---@param p2 number
---@param p3 boolean
function m:__Gen_Delegate_Imp163(p0, p1, p2, p3) end

---@param p0 any
---@param p1 UnityEngine.Color
---@param p2 boolean
function m:__Gen_Delegate_Imp164(p0, p1, p2) end

---@param p0 any
---@param p1 UnityEngine.Color
---@param p2 any
function m:__Gen_Delegate_Imp165(p0, p1, p2) end

---@param p0 any
---@param p1 number
---@param p2 number
---@return System.Collections.Generic.IEnumerable_1_Jyx2_BattleBlockVector_
function m:__Gen_Delegate_Imp166(p0, p1, p2) end

---@return InputManager
function m:__Gen_Delegate_Imp167() end

---@param p0 any
---@return Jyx2.BattleBlockData
function m:__Gen_Delegate_Imp168(p0) end

---@param p0 any
---@return Jyx2SkillDisplayAsset
function m:__Gen_Delegate_Imp169(p0) end

---@param p0 any
---@return UnityEngine.RuntimeAnimatorController
function m:__Gen_Delegate_Imp170(p0) end

---@param p0 any
---@param p1 Jyx2SkillDisplayAsset.Jyx2RoleAnimationType
---@return UnityEngine.AnimationClip
function m:__Gen_Delegate_Imp171(p0, p1) end

---@param p0 any
---@param p1 any
---@return Cysharp.Threading.Tasks.UniTask
function m:__Gen_Delegate_Imp172(p0, p1) end

---@param p0 any
---@return UnityEngine.Animator
function m:__Gen_Delegate_Imp173(p0) end

---@param p0 PropertyItem
---@param p1 number
---@param p2 any
---@param p3 any
---@param p4 number
---@param p5 number
function m:__Gen_Delegate_Imp174(p0, p1, p2, p3, p4, p5) end

---@return number
function m:__Gen_Delegate_Imp175() end

---@param p0 number
---@return string
function m:__Gen_Delegate_Imp176(p0) end

---@param p0 any
---@return Cysharp.Threading.Tasks.UniTask
function m:__Gen_Delegate_Imp177(p0) end

---@param p0 any
---@param p1 any
---@param p2 any
---@param p3 UnityEngine.LogType
function m:__Gen_Delegate_Imp178(p0, p1, p2, p3) end

---@return GlobalAssetConfig
function m:__Gen_Delegate_Imp179() end

---@param p0 any
---@param p1 Jyx2.ModelAsset.WeaponPartType
function m:__Gen_Delegate_Imp180(p0, p1) end

---@param p0 any
---@return System.Collections.Generic.IEnumerable_1_BattleRole_
function m:__Gen_Delegate_Imp181(p0) end

---@param p0 any
---@param p1 Jyx2_GameDifficulty
function m:__Gen_Delegate_Imp182(p0, p1) end

---@return CameraHelper
function m:__Gen_Delegate_Imp183() end

---@param p0 any
---@param p1 number
---@param p2 number
---@param p3 number
function m:__Gen_Delegate_Imp184(p0, p1, p2, p3) end

---@param p0 any
---@param p1 any
---@param p2 number
---@return System.Collections.IEnumerator
function m:__Gen_Delegate_Imp185(p0, p1, p2) end

---@return GameViewPortManager
function m:__Gen_Delegate_Imp186() end

---@param p0 any
---@return GameViewPortManager.ViewportType
function m:__Gen_Delegate_Imp187(p0) end

---@param p0 any
---@return Cinemachine.CinemachineVirtualCamera
function m:__Gen_Delegate_Imp188(p0) end

---@return GameEvent
function m:__Gen_Delegate_Imp189() end

---@return string
function m:__Gen_Delegate_Imp190() end

---@param p0 any
---@return GameEventManager
function m:__Gen_Delegate_Imp191(p0) end

---@param p0 any
---@return GameEvent
function m:__Gen_Delegate_Imp192(p0) end

---@param p0 any
---@return Jyx2Player
function m:__Gen_Delegate_Imp193(p0) end

---@return Jyx2Player
function m:__Gen_Delegate_Imp194() end

---@param p0 any
---@param p1 any
---@return boolean, GameEvent
function m:__Gen_Delegate_Imp195(p0, p1) end

---@param p0 any
---@param p1 UnityEngine.Vector3
---@param p2 UnityEngine.Quaternion
function m:__Gen_Delegate_Imp196(p0, p1, p2) end

---@return LevelMaster
function m:__Gen_Delegate_Imp197() end

---@return Jyx2.LMapConfig
function m:__Gen_Delegate_Imp198() end

---@param p0 any
---@return UnityEngine.UI.Image
function m:__Gen_Delegate_Imp199(p0) end

---@param p0 any
---@param p1 UnityEngine.Quaternion
function m:__Gen_Delegate_Imp200(p0, p1) end

---@param p0 UnityEngine.Vector3
---@param p1 UnityEngine.Vector3
---@param p2 UnityEngine.Vector3
---@param p3 number
---@return UnityEngine.Vector3
function m:__Gen_Delegate_Imp201(p0, p1, p2, p3) end

---@param p0 any
---@return UnityEngine.Quaternion
function m:__Gen_Delegate_Imp202(p0) end

---@param p0 any
---@param p1 number
---@param p2 any
---@param p3 any
---@return Cysharp.Threading.Tasks.UniTask
function m:__Gen_Delegate_Imp203(p0, p1, p2, p3) end

---@return Loom
function m:__Gen_Delegate_Imp204() end

---@param p0 any
---@param p1 any
---@param p2 number
function m:__Gen_Delegate_Imp205(p0, p1, p2) end

---@param p0 any
---@return System.Threading.Thread
function m:__Gen_Delegate_Imp206(p0) end

---@param p0 any
---@return Jyx2.MOD.ModV2.GameModInfo
function m:__Gen_Delegate_Imp207(p0) end

---@return UnityEngine.AudioSource
function m:__Gen_Delegate_Imp208() end

---@return UnityEngine.AudioClip
function m:__Gen_Delegate_Imp209() end

---@param p0 any
---@param p1 UnityEngine.Vector3
---@return Cysharp.Threading.Tasks.UniTask
function m:__Gen_Delegate_Imp210(p0, p1) end

---@return System.Threading.Tasks.Task
function m:__Gen_Delegate_Imp211() end

---@param p0 any
---@return Cysharp.Threading.Tasks.UniTask_1_Jyx2_EventsGraph_Jyx2NodeGraph_
function m:__Gen_Delegate_Imp212(p0) end

---@param p0 any
---@param p1 any
---@return System.Collections.IEnumerator
function m:__Gen_Delegate_Imp213(p0, p1) end

---@param p0 any
---@return UILayer
function m:__Gen_Delegate_Imp214(p0) end

---@param p0 any
---@param p1 any[]
function m:__Gen_Delegate_Imp215(p0, p1) end

---@param p0 any
---@param p1 System.Collections.Generic.KeyValuePair_2_System_String_System_ValueTuple_2_System_Int32_System_Int32__
---@return boolean
function m:__Gen_Delegate_Imp216(p0, p1) end

---@param p0 any
---@return UnityEngine.UI.Button[]
function m:__Gen_Delegate_Imp217(p0) end

---@param p0 any
---@param p1 any
---@return UnityEngine.UI.Image
function m:__Gen_Delegate_Imp218(p0, p1) end

---@param p0 any
---@return ChatType
function m:__Gen_Delegate_Imp219(p0) end

---@param p0 any
---@param p1 number
---@return Cysharp.Threading.Tasks.UniTask
function m:__Gen_Delegate_Imp220(p0, p1) end

---@param p0 any
---@param p1 number
---@param p2 any
---@param p3 number
---@param p4 any
function m:__Gen_Delegate_Imp221(p0, p1, p2, p3, p4) end

---@param p0 any
---@param p1 number
---@return string
function m:__Gen_Delegate_Imp222(p0, p1) end

---@param p0 any
---@param p1 number
---@param p2 boolean
function m:__Gen_Delegate_Imp223(p0, p1, p2) end

---@param p0 any
---@param p1 any
---@param p2 any
---@param p3 any
---@param p4 any
function m:__Gen_Delegate_Imp224(p0, p1, p2, p3, p4) end

---@param p0 any
---@return UnityEngine.Transform[]
function m:__Gen_Delegate_Imp225(p0) end

---@param p0 any
---@param p1 any
---@param p2 any
---@param p3 any
---@param p4 any
---@param p5 any
---@param p6 any
function m:__Gen_Delegate_Imp226(p0, p1, p2, p3, p4, p5, p6) end

---@param p0 any
---@param p1 any
---@param p2 any
---@param p3 any
---@param p4 any
---@param p5 any
function m:__Gen_Delegate_Imp227(p0, p1, p2, p3, p4, p5) end

---@param p0 any
---@param p1 any
---@param p2 number
---@return Cysharp.Threading.Tasks.UniTaskVoid
function m:__Gen_Delegate_Imp228(p0, p1, p2) end

---@param p0 any
---@param p1 TipsType
function m:__Gen_Delegate_Imp229(p0, p1) end

---@param p0 any
---@param p1 any
---@param p2 any
---@param p3 boolean
function m:__Gen_Delegate_Imp230(p0, p1, p2, p3) end

---@return Jyx2_UIManager
function m:__Gen_Delegate_Imp231() end

---@param p0 any
---@param p1 UILayer
---@return UnityEngine.Transform
function m:__Gen_Delegate_Imp232(p0, p1) end

---@param p0 any
---@param p1 any
---@param p2 any[]
---@return Cysharp.Threading.Tasks.UniTask
function m:__Gen_Delegate_Imp233(p0, p1, p2) end

---@param p0 any
---@param p1 UILayer
function m:__Gen_Delegate_Imp234(p0, p1) end

---@param p0 any
---@param p1 any
---@param p2 number
---@param p3 boolean
function m:__Gen_Delegate_Imp235(p0, p1, p2, p3) end

---@param p0 any
---@return number[]
function m:__Gen_Delegate_Imp236(p0) end

---@param p0 any
---@return table<GameSettingManager.Catalog, any>
function m:__Gen_Delegate_Imp237(p0) end

---@param p0 any
---@param p1 any
---@param p2 number
---@param p3 any
---@return any
function m:__Gen_Delegate_Imp238(p0, p1, p2, p3) end

---@param p0 any
---@return table<number, number>
function m:__Gen_Delegate_Imp239(p0) end

---@param p0 any
---@return UnityEngine.UI.Selectable
function m:__Gen_Delegate_Imp240(p0) end

---@param p0 any
---@param p1 boolean
---@param p2 boolean
function m:__Gen_Delegate_Imp241(p0, p1, p2) end

---@param p0 any
---@param p1 System.Collections.Generic.KeyValuePair_2_System_String_System_ValueTuple_2_System_Int32_System_Int32__
function m:__Gen_Delegate_Imp242(p0, p1) end

---@param p0 any
---@param p1 boolean
---@param p2 any
---@return Jyx2RoleHeadUI
function m:__Gen_Delegate_Imp243(p0, p1, p2) end

---@param p0 any
---@param p1 any
---@param p2 boolean
---@param p3 any
function m:__Gen_Delegate_Imp244(p0, p1, p2, p3) end

---@param p0 any
---@param p1 any
---@param p2 any
---@return Jyx2RoleSelector
function m:__Gen_Delegate_Imp245(p0, p1, p2) end

---@param p0 Cysharp.Threading.Tasks.UniTask
function m:__Gen_Delegate_Imp246(p0) end

---@param p0 UILayer
---@return MessageBox
function m:__Gen_Delegate_Imp247(p0) end

---@param p0 any
---@param p1 any
---@param p2 UILayer
function m:__Gen_Delegate_Imp248(p0, p1, p2) end

---@param p0 any
---@param p1 any
---@param p2 any
---@param p3 UILayer
function m:__Gen_Delegate_Imp249(p0, p1, p2, p3) end

---@param p0 any
---@param p1 System.Boolean
---@param p2 PropertyItem
---@param p3 number
---@return UnityEngine.Color, System.Boolean
function m:__Gen_Delegate_Imp250(p0, p1, p2, p3) end

---@param p0 any
---@return Cysharp.Threading.Tasks.UniTask_1_System_Collections_Generic_List_1_Jyx2_RoleInstance__
function m:__Gen_Delegate_Imp251(p0) end

---@param p0 any
---@return Jyx2.CsShopItem
function m:__Gen_Delegate_Imp252(p0) end

---@param p0 any
---@param p1 any
---@param p2 number
---@param p3 number
---@return Cysharp.Threading.Tasks.UniTaskVoid
function m:__Gen_Delegate_Imp253(p0, p1, p2, p3) end

---@param p0 any
---@return ShopUIItem
function m:__Gen_Delegate_Imp254(p0) end

---@param p0 any
---@return Jyx2.SkillCastInstance
function m:__Gen_Delegate_Imp255(p0) end

---@param p0 any
---@return System.Collections.Generic.Dictionary_2_System_String_System_Boolean_
function m:__Gen_Delegate_Imp256(p0) end

---@param p0 any
---@param p1 any
---@param p2 any
---@param p3 number
---@return Cysharp.Threading.Tasks.UniTask
function m:__Gen_Delegate_Imp257(p0, p1, p2, p3) end

---@param p0 any
---@return any
function m:__Gen_Delegate_Imp258(p0) end

---@param p0 any
---@param p1 any
---@return UnityEngine.Component
function m:__Gen_Delegate_Imp259(p0, p1) end

---@param p0 number
---@param p1 any
---@param p2 any
function m:__Gen_Delegate_Imp260(p0, p1, p2) end

---@return table<GameSettingManager.Catalog, any>
function m:__Gen_Delegate_Imp261() end

---@return UnityEngine.Resolution[]
function m:__Gen_Delegate_Imp262() end

---@param p0 GameSettingManager.Catalog
---@param p1 any
---@param p2 boolean
function m:__Gen_Delegate_Imp263(p0, p1, p2) end

---@param p0 GameSettingManager.Catalog
---@param p1 any
function m:__Gen_Delegate_Imp264(p0, p1) end

---@param p0 any
---@return UnityEngine.Vector2Int
function m:__Gen_Delegate_Imp265(p0) end

---@param p0 any
---@return UnityEngine.ShadowQuality
function m:__Gen_Delegate_Imp266(p0) end

---@param p0 any
---@param p1 UnityEngine.ShadowQuality
function m:__Gen_Delegate_Imp267(p0, p1) end

---@param p0 any
---@return MaxFpsEnum
function m:__Gen_Delegate_Imp268(p0) end

---@param p0 any
---@param p1 MaxFpsEnum
function m:__Gen_Delegate_Imp269(p0, p1) end

---@param p0 any
---@return QualityLevelEnum
function m:__Gen_Delegate_Imp270(p0) end

---@param p0 any
---@param p1 QualityLevelEnum
function m:__Gen_Delegate_Imp271(p0, p1) end

---@param p0 any
---@return ShaderLodLevelEnum
function m:__Gen_Delegate_Imp272(p0) end

---@param p0 any
---@param p1 ShaderLodLevelEnum
function m:__Gen_Delegate_Imp273(p0, p1) end

---@param p0 any
---@return ShadowShowLevelEnum
function m:__Gen_Delegate_Imp274(p0) end

---@param p0 any
---@param p1 ShadowShowLevelEnum
function m:__Gen_Delegate_Imp275(p0, p1) end

---@return GraphicSetting
function m:__Gen_Delegate_Imp276() end

---@param p0 any
---@param p1 any
---@return BattleRole
function m:__Gen_Delegate_Imp277(p0, p1) end

---@param p0 any
---@param p1 any
---@return UnityEngine.Color
function m:__Gen_Delegate_Imp278(p0, p1) end

---@param p0 any
---@param p1 any
---@return number
function m:__Gen_Delegate_Imp279(p0, p1) end

---@param p0 any
---@param p1 UnityEngine.Color
---@param p2 number
function m:__Gen_Delegate_Imp280(p0, p1, p2) end

---@param p0 any
---@param p1 any
---@return UnityEngine.Camera
function m:__Gen_Delegate_Imp281(p0, p1) end

---@param p0 number
---@return number
function m:__Gen_Delegate_Imp282(p0) end

---@param p0 any
---@param p1 any
---@param p2 UnityEngine.Vector3
---@param p3 UnityEngine.Vector3
---@param p4 number
---@return UnityEngine.Vector4
function m:__Gen_Delegate_Imp283(p0, p1, p2, p3, p4) end

---@param p0 UnityEngine.Matrix4x4
---@param p1 UnityEngine.Vector4
---@return UnityEngine.Matrix4x4
function m:__Gen_Delegate_Imp284(p0, p1) end

---@param p0 number
---@param p1 number
---@param p2 number
---@return number
function m:__Gen_Delegate_Imp285(p0, p1, p2) end

---@param p0 any
---@param p1 any
---@param p2 UnityEngine.Vector3
function m:__Gen_Delegate_Imp286(p0, p1, p2) end

---@param p0 any
---@param p1 number
---@param p2 number
---@param p3 number
---@param p4 number
---@return System.Collections.IEnumerator
function m:__Gen_Delegate_Imp287(p0, p1, p2, p3, p4) end

---@param p0 any
---@param p1 number
---@return System.Collections.IEnumerator
function m:__Gen_Delegate_Imp288(p0, p1) end

---@param p0 any
---@param p1 number
---@param p2 number
---@param p3 number
---@param p4 UnityEngine.Vector3
---@param p5 UnityEngine.Quaternion
---@param p6 boolean
---@return System.Collections.IEnumerator
function m:__Gen_Delegate_Imp289(p0, p1, p2, p3, p4, p5, p6) end

---@param p0 any
---@param p1 number
---@param p2 UnityEngine.Vector3
---@return System.Collections.IEnumerator
function m:__Gen_Delegate_Imp290(p0, p1, p2) end

---@param p0 any
---@param p1 boolean
---@return UnityEngine.GameObject
function m:__Gen_Delegate_Imp291(p0, p1) end

---@param p0 any
---@return string
function m:__Gen_Delegate_Imp292(p0) end

---@param p0 System.String
---@return string, System.String
function m:__Gen_Delegate_Imp293(p0) end

---@param p0 any
---@param p1 any
---@param p2 number
---@return string
function m:__Gen_Delegate_Imp294(p0, p1, p2) end

---@param p0 number
---@param p1 number
---@param p2 number
---@param p3 number
---@param p4 number
---@param p5 any
---@return number
function m:__Gen_Delegate_Imp295(p0, p1, p2, p3, p4, p5) end

---@param p0 any
---@param p1 any
---@return string
function m:__Gen_Delegate_Imp296(p0, p1) end

---@param p0 any
---@param p1 any
---@return number[]
function m:__Gen_Delegate_Imp297(p0, p1) end

---@param p0 any
---@param p1 boolean
---@return number[]
function m:__Gen_Delegate_Imp298(p0, p1) end

---@param p0 any
---@param p1 boolean
---@return string
function m:__Gen_Delegate_Imp299(p0, p1) end

---@param p0 any
---@param p1 Tutorial.Param1
---@param p2 System.Int32
---@param p4 any
---@return number, System.Int32, System.String, System.Action
function m:__Gen_Delegate_Imp300(p0, p1, p2, p4) end

---@param p0 any
---@param p1 any
---@return Tutorial.DerivedClass
function m:__Gen_Delegate_Imp301(p0, p1) end

---@param p0 any
---@param p1 number
---@param p2 any
---@param p3 any
function m:__Gen_Delegate_Imp302(p0, p1, p2, p3) end

---@param p0 any
---@param p1 number
---@param p2 string[]
function m:__Gen_Delegate_Imp303(p0, p1, p2) end

---@param p0 any
---@param p1 Tutorial.TestEnum
---@return Tutorial.TestEnum
function m:__Gen_Delegate_Imp304(p0, p1) end

---@param p0 any
---@param p1 number
---@return number
function m:__Gen_Delegate_Imp305(p0, p1) end

---@param p0 any
---@return Tutorial.ICalc
function m:__Gen_Delegate_Imp306(p0) end

---@param p0 XLuaTest.MyStruct
---@param p1 number
---@param p2 number
function m:__Gen_Delegate_Imp307(p0, p1, p2) end

---@param p0 any
---@param p1 number
---@return number
function m:__Gen_Delegate_Imp308(p0, p1) end

---@param p0 any
---@param p1 UnityEngine.Vector3
---@return UnityEngine.Vector3
function m:__Gen_Delegate_Imp309(p0, p1) end

---@param p0 any
---@param p1 XLuaTest.MyStruct
---@return XLuaTest.MyStruct
function m:__Gen_Delegate_Imp310(p0, p1) end

---@param p0 any
---@param p1 XLuaTest.MyEnum
---@return XLuaTest.MyEnum
function m:__Gen_Delegate_Imp311(p0, p1) end

---@param p0 any
---@param p1 System.Decimal
---@return System.Decimal
function m:__Gen_Delegate_Imp312(p0, p1) end

---@return System.Type[]
function m:__Gen_Delegate_Imp313() end

---@param p0 any
---@param p1 number
---@param p2 number
---@return number
function m:__Gen_Delegate_Imp314(p0, p1, p2) end

---@param p0 any
---@param p1 UnityEngine.Vector3
---@param p2 UnityEngine.Vector3
---@return UnityEngine.Vector3
function m:__Gen_Delegate_Imp315(p0, p1, p2) end

---@param p0 any
---@param p1 number
---@param p3 System.String
---@return number, System.Double, System.String
function m:__Gen_Delegate_Imp316(p0, p1, p3) end

---@param p0 any
---@param p1 number
---@param p3 System.String
---@param p4 any
---@return number, System.Double, System.String
function m:__Gen_Delegate_Imp317(p0, p1, p3, p4) end

---@param p0 XLuaTest.StructTest
---@param p1 number
---@param p2 any
---@return UnityEngine.GameObject
function m:__Gen_Delegate_Imp318(p0, p1, p2) end

---@param p0 XLuaTest.StructTest
---@return string
function m:__Gen_Delegate_Imp319(p0) end

---@param p0 XLuaTest.StructTest
---@param p1 any
function m:__Gen_Delegate_Imp320(p0, p1) end

---@param p0 any
---@param p1 any
---@return boolean, System.Uri
function m:__Gen_Delegate_Imp321(p0, p1) end

---@param p0 any
---@param p1 number
---@param p2 number
---@param p3 number
---@return string
function m:__Gen_Delegate_Imp322(p0, p1, p2, p3) end

---@param p0 any
---@param p1 any
---@param p2 any
---@param p3 System.Threading.CancellationToken
---@return Cysharp.Threading.Tasks.UniTask
function m:__Gen_Delegate_Imp323(p0, p1, p2, p3) end

---@param p0 any
---@param p1 number
---@param p2 number
function m:__Gen_Delegate_Imp324(p0, p1, p2) end

---@param p0 any
---@param p1 number
---@param p2 any
function m:__Gen_Delegate_Imp325(p0, p1, p2) end

---@param p0 any
---@return Jyx2.MOD.ModV2.GameModBase
function m:__Gen_Delegate_Imp326(p0) end

---@param p0 any
---@return number
function m:__Gen_Delegate_Imp327(p0) end

---@param p0 any
---@param p1 any
---@param p2 any
---@param p3 any
---@param p4 number
---@param p5 number
function m:__Gen_Delegate_Imp328(p0, p1, p2, p3, p4, p5) end

---@param p0 number
---@param p1 number
---@param p2 number
---@param p3 number
---@return number
function m:__Gen_Delegate_Imp329(p0, p1, p2, p3) end

---@param p0 number
---@return Jyx2.BattleBlockVector
function m:__Gen_Delegate_Imp330(p0) end

---@param p0 any
---@return Jyx2.BattleBlockVector[]
function m:__Gen_Delegate_Imp331(p0) end

---@param p0 any
---@param p1 number
---@param p2 number
---@param p3 boolean
function m:__Gen_Delegate_Imp332(p0, p1, p2, p3) end

---@param p0 any
---@return System.Collections.Generic.IEnumerable_1_UnityEngine_Transform_
function m:__Gen_Delegate_Imp333(p0) end

---@param p0 any
---@return Jyx2.RoleInstance[]
function m:__Gen_Delegate_Imp334(p0) end

---@param p0 any
---@param p1 any
---@param p2 any
---@param p3 number
---@param p4 boolean
function m:__Gen_Delegate_Imp335(p0, p1, p2, p3, p4) end

---@param p0 any
---@param p1 any
---@return Jyx2.RoleInstance
function m:__Gen_Delegate_Imp336(p0, p1) end

---@param p0 any
---@return Jyx2.BattleResult
function m:__Gen_Delegate_Imp337(p0) end

---@return Jyx2.BattleManager
function m:__Gen_Delegate_Imp338() end

---@param p0 any
---@return Jyx2.BattleFieldModel
function m:__Gen_Delegate_Imp339(p0) end

---@param p0 any
---@return Jyx2.RangeLogic
function m:__Gen_Delegate_Imp340(p0) end

---@param p0 any
---@param p1 Jyx2.BattleResult
function m:__Gen_Delegate_Imp341(p0, p1) end

---@param p0 any
---@param p1 UnityEngine.Vector3
---@param p2 boolean
---@return Jyx2.BattleBlockData
function m:__Gen_Delegate_Imp342(p0, p1, p2) end

---@param p0 any
---@param p1 any
---@param p2 any
---@param p3 any
---@return System.Collections.Generic.IEnumerable_1_Jyx2_BattleBlockVector_
function m:__Gen_Delegate_Imp343(p0, p1, p2, p3) end

---@param p0 any
---@param p1 any
---@param p2 any
---@return UnityEngine.Vector3[]
function m:__Gen_Delegate_Imp344(p0, p1, p2) end

---@param p0 any
---@param p1 any
---@param p2 number
---@return Jyx2.BattleBlockVector[]
function m:__Gen_Delegate_Imp345(p0, p1, p2) end

---@param p0 any
---@param p1 any
---@param p2 any
---@return Jyx2.BattleBlockVector[]
function m:__Gen_Delegate_Imp346(p0, p1, p2) end

---@param p0 any
---@param p1 any
---@param p2 any
---@param p3 number
---@return Jyx2.RoleInstance[]
function m:__Gen_Delegate_Imp347(p0, p1, p2, p3) end

---@param p0 any
---@return Jyx2.BattleboxBlock[]
function m:__Gen_Delegate_Imp348(p0) end

---@param p0 any
---@param p1 number
---@param p2 number
---@return Jyx2.BattleboxBlock
function m:__Gen_Delegate_Imp349(p0, p1, p2) end

---@param p0 any
---@param p1 number
---@param p2 number
---@return System.Numerics.Vector2
function m:__Gen_Delegate_Imp350(p0, p1, p2) end

---@param p0 any
---@param p1 any
---@param p2 any
---@param p3 number
---@param p4 number
---@param p5 number
---@param p6 number
function m:__Gen_Delegate_Imp351(p0, p1, p2, p3, p4, p5, p6) end

---@param p0 any
---@return Animancer.HybridAnimancerComponent
function m:__Gen_Delegate_Imp352(p0) end

---@param p0 any
---@param p1 any
---@param p2 number
---@return Cysharp.Threading.Tasks.UniTask
function m:__Gen_Delegate_Imp353(p0, p1, p2) end

---@param p0 any
---@param p1 any
---@param p2 any
---@param p3 number
function m:__Gen_Delegate_Imp354(p0, p1, p2, p3) end

---@param p0 number
---@param p1 number
---@return Jyx2.BattleBlockVector[]
function m:__Gen_Delegate_Imp355(p0, p1) end

---@param p0 number
---@param p1 number
---@param p2 number
---@return Jyx2.BattleBlockVector[]
function m:__Gen_Delegate_Imp356(p0, p1, p2) end

---@param p0 number
---@param p1 number
---@param p2 number
---@param p3 number
---@return Jyx2.MoveDirection
function m:__Gen_Delegate_Imp357(p0, p1, p2, p3) end

---@param p0 any
---@param p1 number
---@param p2 number
---@param p3 Jyx2.MoveDirection
---@return Jyx2.BattleBlockVector
function m:__Gen_Delegate_Imp358(p0, p1, p2, p3) end

---@param p0 any
---@param p1 number
---@param p2 number
---@param p3 Jyx2.MoveDirection
---@param p4 Jyx2.MoveDirection
---@return Jyx2.BattleBlockVector
function m:__Gen_Delegate_Imp359(p0, p1, p2, p3, p4) end

---@param p0 any
---@param p1 number
---@param p2 number
---@param p3 number
---@return string
function m:__Gen_Delegate_Imp360(p0, p1, p2, p3) end

---@param p0 any
---@param p1 number
---@param p2 number
---@param p3 number
---@return System.Collections.Generic.IEnumerable_1_Jyx2_BattleBlockVector_
function m:__Gen_Delegate_Imp361(p0, p1, p2, p3) end

---@param p0 any
---@param p1 number
---@param p2 number
---@param p3 number
function m:__Gen_Delegate_Imp362(p0, p1, p2, p3) end

---@param p0 any
---@param p1 number
---@param p2 number
---@param p3 number
---@param p4 number
---@param p5 boolean
---@return Jyx2.MoveSearchHelper[]
function m:__Gen_Delegate_Imp363(p0, p1, p2, p3, p4, p5) end

---@param p0 any
---@param p1 number
---@param p2 number
---@param p3 number
---@param p4 boolean
---@return Jyx2.BattleBlockVector[]
function m:__Gen_Delegate_Imp364(p0, p1, p2, p3, p4) end

---@param p0 any
---@param p1 any
---@param p2 any
---@return number
function m:__Gen_Delegate_Imp365(p0, p1, p2) end

---@param p0 number
---@param p1 any
---@return number
function m:__Gen_Delegate_Imp366(p0, p1) end

---@param p0 any
---@param p1 number
---@param p2 number
---@param p3 any
---@param p4 any
---@return System.Collections.Generic.IEnumerable_1_Jyx2_BattleBlockVector_
function m:__Gen_Delegate_Imp367(p0, p1, p2, p3, p4) end

---@param p0 any
---@param p1 Jyx2.SkillCoverType
---@param p2 number
---@param p3 number
---@param p4 number
---@param p5 number
---@param p6 number
---@return Jyx2.BattleBlockVector[]
function m:__Gen_Delegate_Imp368(p0, p1, p2, p3, p4, p5, p6) end

---@param p0 any
---@param p1 any
---@param p2 number
---@param p3 any
---@param p4 UnityEngine.Vector3
---@param p5 number
---@param p6 any
function m:__Gen_Delegate_Imp369(p0, p1, p2, p3, p4, p5, p6) end

---@param p0 any
---@return Jyx2.SkillInstance
function m:__Gen_Delegate_Imp370(p0) end

---@param p0 any
---@return Jyx2.SkillCastInstance.SkillCastStatus
function m:__Gen_Delegate_Imp371(p0) end

---@param p0 any
---@return Jyx2.SkillCoverType
function m:__Gen_Delegate_Imp372(p0) end

---@return MODRootConfig
function m:__Gen_Delegate_Imp373() end

---@return Jyx2.MOD.ModV2.GameModBase
function m:__Gen_Delegate_Imp374() end

---@return Cysharp.Threading.Tasks.UniTask_1_System_Boolean_
function m:__Gen_Delegate_Imp375() end

---@return UnityEngine.UI.Button
function m:__Gen_Delegate_Imp376() end

---@param p0 any
---@param p1 UnityEngine.Vector3
---@param p2 UnityEngine.Vector3
---@param p3 any
function m:__Gen_Delegate_Imp377(p0, p1, p2, p3) end

---@param p0 any
---@param p1 UnityEngine.Vector3
---@param p2 UnityEngine.Vector3
---@param p3 UnityEngine.Vector3
---@param p4 number
---@return UnityEngine.Vector3
function m:__Gen_Delegate_Imp378(p0, p1, p2, p3, p4) end

---@param p0 Jyx2.GameSaveSummary
---@return boolean
function m:__Gen_Delegate_Imp379(p0) end

---@param p0 number
---@return Jyx2.GameSaveSummary
function m:__Gen_Delegate_Imp380(p0) end

---@param p0 number
---@param p1 Jyx2.GameSaveSummary
function m:__Gen_Delegate_Imp381(p0, p1) end

---@param p0 Jyx2.GameSaveSummary
---@return string
function m:__Gen_Delegate_Imp382(p0) end

---@param p0 number
---@return System.Nullable_1_System_DateTime_
function m:__Gen_Delegate_Imp383(p0) end

---@param p0 number
---@return Jyx2.GameRuntimeData
function m:__Gen_Delegate_Imp384(p0) end

---@param p0 any
---@return System.Collections.Generic.IEnumerable_1_Jyx2_RoleInstance_
function m:__Gen_Delegate_Imp385(p0) end

---@param p0 any
---@param p1 number
---@param p2 boolean
---@return boolean
function m:__Gen_Delegate_Imp386(p0, p1, p2) end

---@param p0 any
---@param p1 number
---@return Jyx2.RoleInstance
function m:__Gen_Delegate_Imp387(p0, p1) end

---@param p0 any
---@param p1 number
---@param p2 any
---@return string
function m:__Gen_Delegate_Imp388(p0, p1, p2) end

---@param p0 any
---@param p1 number
---@param p2 number
---@param p3 number
---@param p4 number
function m:__Gen_Delegate_Imp389(p0, p1, p2, p3, p4) end

---@param p0 any
---@param p1 any
---@return System.Collections.Generic.Dictionary_2_System_String_System_String_
function m:__Gen_Delegate_Imp390(p0, p1) end

---@param p0 any
---@return System.DateTime
function m:__Gen_Delegate_Imp391(p0) end

---@param p0 any
---@param p1 System.DateTime
function m:__Gen_Delegate_Imp392(p0, p1) end

---@param p0 any
---@return Jyx2.LSkillConfig
function m:__Gen_Delegate_Imp393(p0) end

---@param p0 any
---@return Jyx2.LSkillLevel[]
function m:__Gen_Delegate_Imp394(p0) end

---@param p0 any
---@param p1 number
---@return Jyx2.LSkillLevel
function m:__Gen_Delegate_Imp395(p0, p1) end

---@param p0 any
---@param p1 any
---@return Jyx2.LSkillConfig
function m:__Gen_Delegate_Imp396(p0, p1) end

---@return XLua.LuaEnv
function m:__Gen_Delegate_Imp397() end

---@return Cysharp.Threading.Tasks.UniTaskVoid
function m:__Gen_Delegate_Imp398() end

---@param p0 any
---@param p1 any[]
---@return any[]
function m:__Gen_Delegate_Imp399(p0, p1) end

---@param p0 any
---@param p1 any[]
---@return any
function m:__Gen_Delegate_Imp400(p0, p1) end

---@param p0 any
---@param p1 any[]
---@return number
function m:__Gen_Delegate_Imp401(p0, p1) end

---@param p0 any
---@param p1 any[]
---@return number
function m:__Gen_Delegate_Imp402(p0, p1) end

---@param p0 any
---@return XLua.LuaFunction
function m:__Gen_Delegate_Imp403(p0) end

---@param p0 any
---@return Cysharp.Threading.Tasks.UniTask_1_UnityEngine_Sprite_
function m:__Gen_Delegate_Imp404(p0) end

---@param p0 any
---@param p1 Cysharp.Threading.Tasks.UniTask_1_UnityEngine_Sprite_
---@return Cysharp.Threading.Tasks.UniTask
function m:__Gen_Delegate_Imp405(p0, p1) end

---@param p0 any
---@return Cysharp.Threading.Tasks.UniTask_1_UnityEngine_GameObject_
function m:__Gen_Delegate_Imp406(p0) end

---@param p0 any
---@param p1 Jyx2.ModelAsset.WeaponPartType
---@return Jyx2.WeaponPart
function m:__Gen_Delegate_Imp407(p0, p1) end

---@param p0 any
---@param p1 any
---@return Jyx2.WeaponPart
function m:__Gen_Delegate_Imp408(p0, p1) end

---@param p0 any
---@return Jyx2.ReleaseNoteType
function m:__Gen_Delegate_Imp409(p0) end

---@param p0 any
---@param p1 Jyx2.ReleaseNoteType
function m:__Gen_Delegate_Imp410(p0, p1) end

---@param p0 Jyx2.ReleaseNoteType
function m:__Gen_Delegate_Imp411(p0) end

---@param p0 any
---@return System.Collections.Generic.Dictionary_2_System_String_System_Int32_
function m:__Gen_Delegate_Imp412(p0) end

---@param p0 any
---@return System.Collections.Generic.Dictionary_2_System_String_System_Single_
function m:__Gen_Delegate_Imp413(p0) end

---@param p0 any
---@return System.Collections.Generic.Dictionary_2_System_String_System_String_
function m:__Gen_Delegate_Imp414(p0) end

---@param p0 UnityEngine.Vector3
---@param p1 number
---@return string
function m:__Gen_Delegate_Imp415(p0, p1) end

---@param p0 any
---@param p1 number
---@return UnityEngine.Vector3
function m:__Gen_Delegate_Imp416(p0, p1) end

---@param p0 UnityEngine.Quaternion
---@return string
function m:__Gen_Delegate_Imp417(p0) end

---@param p0 any
---@param p1 any
---@return UnityEngine.Transform
function m:__Gen_Delegate_Imp418(p0, p1) end

---@param p0 any
---@return System.Data.DataRowCollection, System.Int32, System.Int32
function m:__Gen_Delegate_Imp419(p0) end

---@param p0 any
---@param p1 number
---@return Jyx2.Middleware.ColDesc[]
function m:__Gen_Delegate_Imp420(p0, p1) end

---@param p0 any
---@param p1 number
---@param p2 number
---@return string
function m:__Gen_Delegate_Imp421(p0, p1, p2) end

---@param p0 any
---@return Cysharp.Threading.Tasks.UniTask_1_System_Byte___
function m:__Gen_Delegate_Imp422(p0) end

---@param p0 any
---@param p1 any
---@param p2 any
---@param p3 System.Threading.CancellationToken
---@param p4 any
---@param p5 number
---@return Cysharp.Threading.Tasks.UniTask
function m:__Gen_Delegate_Imp423(p0, p1, p2, p3, p4, p5) end

---@param p0 any
---@return number
function m:__Gen_Delegate_Imp424(p0) end

---@param p0 number
---@return string
function m:__Gen_Delegate_Imp425(p0) end

---@param p0 number
---@param p1 number
---@param p2 number
---@return number[]
function m:__Gen_Delegate_Imp426(p0, p1, p2) end

---@param p0 number
---@return boolean
function m:__Gen_Delegate_Imp427(p0) end

---@return System.DateTime
function m:__Gen_Delegate_Imp428() end

---@param p0 System.DateTime
---@return System.DateTime
function m:__Gen_Delegate_Imp429(p0) end

---@param p0 System.DateTime
---@return string
function m:__Gen_Delegate_Imp430(p0) end

---@param p0 System.DateTime
---@param p1 number
---@return boolean
function m:__Gen_Delegate_Imp431(p0, p1) end

---@param p0 UnityEngine.Vector2
---@return number
function m:__Gen_Delegate_Imp432(p0) end

---@param p0 UnityEngine.Vector3
---@param p1 UnityEngine.Vector3
---@param p2 UnityEngine.Vector3
---@param p3 number
---@return boolean
function m:__Gen_Delegate_Imp433(p0, p1, p2, p3) end

---@param p0 UnityEngine.Vector2
---@param p1 number
---@param p2 number
---@param p3 number
---@return boolean
function m:__Gen_Delegate_Imp434(p0, p1, p2, p3) end

---@param p0 any
---@param p1 any
---@param p2 any
---@param p3 any
---@return System.Collections.IEnumerator
function m:__Gen_Delegate_Imp435(p0, p1, p2, p3) end

---@param p0 any
---@return Cysharp.Threading.Tasks.UniTask_1_UnityEngine_AssetBundle_
function m:__Gen_Delegate_Imp436(p0) end

---@param p0 any
---@return System.Collections.Generic.IEnumerable_1_System_String_
function m:__Gen_Delegate_Imp437(p0) end

---@param p0 any
---@param p1 any
---@return Cysharp.Threading.Tasks.UniTask_1_UnityEngine_Sprite_
function m:__Gen_Delegate_Imp438(p0, p1) end

---@param p0 any
---@param p1 any
---@param p2 any
---@param p3 boolean
---@return Cysharp.Threading.Tasks.UniTask
function m:__Gen_Delegate_Imp439(p0, p1, p2, p3) end

---@param p0 any
---@return Jyx2.MOD.ModV2.GameModBuildPlatform
function m:__Gen_Delegate_Imp440(p0) end

---@param p0 any
---@param p1 Jyx2.MOD.ModV2.GameModBuildPlatform
function m:__Gen_Delegate_Imp441(p0, p1) end

---@param p0 Jyx2.MOD.ModV2.GameModBuildPlatform
---@return boolean
function m:__Gen_Delegate_Imp442(p0) end

---@param p0 any
---@return Cysharp.Threading.Tasks.UniTask_1_System_Collections_Generic_List_1_Jyx2_MOD_ModV2_GameModBase__
function m:__Gen_Delegate_Imp443(p0) end

---@param p0 any
---@return Jyx2.MOD.ModV2.GameModBase[]
function m:__Gen_Delegate_Imp444(p0) end

---@param p0 any
---@return string[]
function m:__Gen_Delegate_Imp445(p0) end

---@param p0 any
---@return Cysharp.Threading.Tasks.UniTask_1_Jyx2_MOD_ModV2_GameModNative_
function m:__Gen_Delegate_Imp446(p0) end

---@param p0 any
---@return Cysharp.Threading.Tasks.UniTask_1_System_String_
function m:__Gen_Delegate_Imp447(p0) end

---@param p0 number
---@param p1 number
---@param p2 number
---@return System.ValueTuple_4_System_Int32_System_Int32_System_Int32_System_Int32_
function m:__Gen_Delegate_Imp448(p0, p1, p2) end

---@param p0 number
---@param p1 number
---@param p2 number
---@param p3 Jyx2.UINavigation.NavigationDirection
---@return boolean
function m:__Gen_Delegate_Imp449(p0, p1, p2, p3) end

---@param p0 any
---@param p1 any
---@return UnityEngine.Bounds
function m:__Gen_Delegate_Imp450(p0, p1) end

---@param p0 any
---@param p1 number
---@param p2 number
---@return number
function m:__Gen_Delegate_Imp451(p0, p1, p2) end

---@param p0 any
---@return Jyx2.InputCore.IJyx2_InputContext
function m:__Gen_Delegate_Imp452(p0) end

---@return UnityEngine.GameObject
function m:__Gen_Delegate_Imp453() end

---@return Rewired.Player
function m:__Gen_Delegate_Imp454() end

---@param p0 number
---@return number
function m:__Gen_Delegate_Imp455(p0) end

---@param p0 number
---@param p1 number
---@return UnityEngine.Vector2
function m:__Gen_Delegate_Imp456(p0, p1) end

---@param p0 Jyx2.InputCore.Jyx2PlayerAction
---@return boolean
function m:__Gen_Delegate_Imp457(p0) end

---@param p0 Jyx2.InputCore.Jyx2PlayerAction
---@return number
function m:__Gen_Delegate_Imp458(p0) end

---@param p0 Jyx2.InputCore.Jyx2PlayerAction
---@param p1 Jyx2.InputCore.Jyx2PlayerAction
---@return UnityEngine.Vector2
function m:__Gen_Delegate_Imp459(p0, p1) end

---@return Rewired.Controller
function m:__Gen_Delegate_Imp460() end

---@param p0 Jyx2.InputCore.Jyx2PlayerAction
---@param p1 Rewired.AxisRange
---@return string
function m:__Gen_Delegate_Imp461(p0, p1) end

---@param p0 Rewired.AxisRange
---@return Rewired.Pole
function m:__Gen_Delegate_Imp462(p0) end

---@param p0 any
---@param p1 number
---@param p2 number
---@return Rewired.ControllerMap
function m:__Gen_Delegate_Imp463(p0, p1, p2) end

---@param p0 any
---@param p1 Jyx2.InputCore.Jyx2PlayerAction
---@param p2 Rewired.AxisRange
---@return Rewired.ActionElementMap
function m:__Gen_Delegate_Imp464(p0, p1, p2) end

---@param p0 any
---@param p1 Jyx2.InputCore.Jyx2PlayerAction
---@param p2 Rewired.AxisRange
---@return string
function m:__Gen_Delegate_Imp465(p0, p1, p2) end

---@param p0 any
---@param p1 any
---@param p2 number
---@param p3 number
---@return Rewired.ControllerMap
function m:__Gen_Delegate_Imp466(p0, p1, p2, p3) end

---@param p0 any
---@param p1 any
---@return System.IObservable_1_UnityEngine_KeyCode_
function m:__Gen_Delegate_Imp467(p0, p1) end

---@param p0 any
---@param p1 any
---@return TMPro.TMP_SpriteAsset
function m:__Gen_Delegate_Imp468(p0, p1) end

---@param p0 any
---@return Jyx2.InputCore.Jyx2PlayerAction
function m:__Gen_Delegate_Imp469(p0) end

---@param p0 any
---@param p1 Jyx2.InputCore.Jyx2PlayerAction
function m:__Gen_Delegate_Imp470(p0, p1) end

---@param p0 any
---@return Rewired.AxisRange
function m:__Gen_Delegate_Imp471(p0) end

---@param p0 any
---@param p1 Rewired.AxisRange
function m:__Gen_Delegate_Imp472(p0, p1) end

---@param p0 any
---@param p1 Jyx2.InputCore.Jyx2PlayerAction
---@param p2 Rewired.AxisRange
---@param p3 any
function m:__Gen_Delegate_Imp473(p0, p1, p2, p3) end

---@param p0 any
---@param p1 number
---@param p2 number
---@param p3 number
---@param p4 number
---@param p5 number
---@param p6 number
function m:__Gen_Delegate_Imp474(p0, p1, p2, p3, p4, p5, p6) end

---@param p0 any
---@param p1 number
---@param p2 number
---@param p3 number
---@param p4 number
function m:__Gen_Delegate_Imp475(p0, p1, p2, p3, p4) end

---@param p0 any
---@param p1 number
---@param p2 number
---@return Jyx2.Battle.BattleGridsCell
function m:__Gen_Delegate_Imp476(p0, p1, p2) end

---@param p0 any
---@param p1 any
---@param p2 any
---@return boolean
function m:__Gen_Delegate_Imp477(p0, p1, p2) end

---@param p0 any
---@param p1 any
---@param p2 any
---@param p3 boolean
---@return Cysharp.Threading.Tasks.UniTask_1_Jyx2_Battle_BattleLoop_ManualResult_
function m:__Gen_Delegate_Imp478(p0, p1, p2, p3) end

---@param p0 number
---@param p1 number
---@param p2 number
---@param p3 number
---@param p4 number
---@return boolean
function m:__Gen_Delegate_Imp479(p0, p1, p2, p3, p4) end

---@param p0 any
---@param p1 boolean
---@return TileWorld.TileWorldConfiguration
function m:__Gen_Delegate_Imp480(p0, p1) end

---@param p0 any
---@param p1 boolean
---@param p2 boolean
---@param p3 boolean
function m:__Gen_Delegate_Imp481(p0, p1, p2, p3) end

---@param p0 any
---@param p1 boolean
---@param p2 boolean
---@return System.Collections.IEnumerator
function m:__Gen_Delegate_Imp482(p0, p1, p2) end

---@param p0 any
---@param p1 any
---@param p2 number
---@param p3 number
---@param p4 boolean
---@return System.Collections.IEnumerator
function m:__Gen_Delegate_Imp483(p0, p1, p2, p3, p4) end

---@param p0 any
---@param p1 any
---@param p2 number
---@param p3 number
---@param p4 boolean
function m:__Gen_Delegate_Imp484(p0, p1, p2, p3, p4) end

---@param p0 any
---@param p1 any
---@param p2 number
---@param p3 number
---@param p4 number
function m:__Gen_Delegate_Imp485(p0, p1, p2, p3, p4) end

---@param p0 any
---@param p1 any
---@param p2 number
---@param p3 number
---@param p4 number
---@param p5 number
---@param p6 number
---@param p7 boolean
function m:__Gen_Delegate_Imp486(p0, p1, p2, p3, p4, p5, p6, p7) end

---@param p0 any
---@param p1 any
---@param p2 number
---@param p3 number
---@param p4 number
---@param p5 number
---@param p6 boolean
---@param p7 boolean
---@param p8 any
---@param p9 number
function m:__Gen_Delegate_Imp487(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9) end

---@param p0 any
---@param p1 number
---@param p2 any
---@param p3 number
---@param p4 number
function m:__Gen_Delegate_Imp488(p0, p1, p2, p3, p4) end

---@param p0 any
---@param p1 boolean
---@param p2 boolean
---@param p3 number
---@param p4 boolean
---@param p5 number
function m:__Gen_Delegate_Imp489(p0, p1, p2, p3, p4, p5) end

---@param p0 any
---@param p1 boolean
---@param p2 number
function m:__Gen_Delegate_Imp490(p0, p1, p2) end

---@param p0 any
---@param p1 UnityEngine.Vector3
---@return UnityEngine.Vector2
function m:__Gen_Delegate_Imp491(p0, p1) end

---@param p0 any
---@param p1 UnityEngine.Vector3
---@param p2 number
---@param p3 boolean
---@param p4 boolean
---@param p5 boolean
function m:__Gen_Delegate_Imp492(p0, p1, p2, p3, p4, p5) end

---@param p0 any
---@return UnityEngine.Random.State
function m:__Gen_Delegate_Imp493(p0) end

---@param p0 any
---@param p1 number
---@param p2 number
---@param p3 any
---@param p4 any
---@return UnityEngine.GameObject
function m:__Gen_Delegate_Imp494(p0, p1, p2, p3, p4) end

---@param p0 any
---@param p1 number
---@param p2 number
---@param p3 number
---@param p4 number
---@return UnityEngine.Rect
function m:__Gen_Delegate_Imp495(p0, p1, p2, p3, p4) end

---@param p0 any
---@param p1 TileWorld.TileWorldObjectScatterConfiguration.PositionObjectConfiguration.BlockType
---@param p2 number
function m:__Gen_Delegate_Imp496(p0, p1, p2) end

---@param p0 any
---@param p1 UnityEngine.Vector2
---@param p2 number
---@param p3 number
---@param p4 number
---@param p5 boolean
---@param p6 TileWorld.TileWorldObjectScatterConfiguration.PositionObjectConfiguration.BlockType
function m:__Gen_Delegate_Imp497(p0, p1, p2, p3, p4, p5, p6) end

---@param p0 any
---@param p1 TileWorld.TileWorldConfiguration.TileInformation.TileTypes
---@param p2 number
function m:__Gen_Delegate_Imp498(p0, p1, p2) end

---@param p0 any
---@param p1 boolean
---@return TileWorld.TileWorldObjectScatterConfiguration
function m:__Gen_Delegate_Imp499(p0, p1) end

---@param p0 any
---@return UnityEngine.Mesh
function m:__Gen_Delegate_Imp500(p0) end

---@param p0 number
---@param p1 any
---@param p2 any
---@param p3 System.Int32
---@param p4 UnityEngine.Matrix4x4
---@return System.Int32
function m:__Gen_Delegate_Imp501(p0, p1, p2, p3, p4) end

---@param p0 number
---@param p1 any
---@param p2 any
---@param p3 System.Int32
---@return System.Int32
function m:__Gen_Delegate_Imp502(p0, p1, p2, p3) end

---@return TileWorld.IAlgorithms__, System.String__
function m:__Gen_Delegate_Imp503() end

---@return System.String__
function m:__Gen_Delegate_Imp504() end

---@return TileWorld.IMaskBehaviour__, System.String__
function m:__Gen_Delegate_Imp505() end

---@param p0 any
---@param p1 number
---@param p2 number
---@param p3 number
---@param p4 boolean
---@param p5 boolean
---@return number
function m:__Gen_Delegate_Imp506(p0, p1, p2, p3, p4, p5) end

---@param p0 any
---@param p1 number
---@param p2 number
---@param p3 number
---@param p4 boolean
---@return number
function m:__Gen_Delegate_Imp507(p0, p1, p2, p3, p4) end

---@param p0 any
---@param p1 UnityEngine.Playables.PlayableGraph
---@param p2 any
---@return UnityEngine.Playables.Playable
function m:__Gen_Delegate_Imp508(p0, p1, p2) end

---@param p0 any
---@param p1 UnityEngine.Playables.PlayableGraph
---@param p2 any
---@param p3 number
---@return UnityEngine.Playables.Playable
function m:__Gen_Delegate_Imp509(p0, p1, p2, p3) end

---@param p0 any
---@param p1 UnityEngine.Playables.Playable
function m:__Gen_Delegate_Imp510(p0, p1) end

---@param p0 any
---@param p1 UnityEngine.Playables.Playable
---@param p2 UnityEngine.Playables.FrameData
---@param p3 any
function m:__Gen_Delegate_Imp511(p0, p1, p2, p3) end

---@param p0 any
---@param p1 any
---@return any
function m:__Gen_Delegate_Imp512(p0, p1) end

---@param p0 any
---@param p1 any
---@param p2 any
---@return string
function m:__Gen_Delegate_Imp513(p0, p1, p2) end

---@return Sirenix.OdinInspector.ValueDropdownList_1_i18n_TranslatorDef_TranslationUtility_LangFlag_
function m:__Gen_Delegate_Imp514() end

---@return System.Collections.IEnumerable
function m:__Gen_Delegate_Imp515() end

---@param p0 any
---@return UnityEngine.UI.Dropdown.OptionData[]
function m:__Gen_Delegate_Imp516(p0) end

---@param p0 any
---@return UnityEngine.UI.Text
function m:__Gen_Delegate_Imp517(p0) end

---@param p0 any
---@return UnityEngine.AI.NavMeshAgent
function m:__Gen_Delegate_Imp518(p0) end

---@return AClockworkBerry.ScreenLogger
function m:__Gen_Delegate_Imp519() end

---@param p0 any
---@param p1 UnityEngine.SceneManagement.Scene
---@param p2 UnityEngine.SceneManagement.LoadSceneMode
function m:__Gen_Delegate_Imp520(p0, p1, p2) end

---@param p0 UnityEngine.Vector3
---@param p1 ProGrids.Axis
---@return UnityEngine.Vector3
function m:__Gen_Delegate_Imp521(p0, p1) end

---@param p0 ProGrids.SnapUnit
---@return number
function m:__Gen_Delegate_Imp522(p0) end

---@param p0 any
---@return UnityEngine.Texture2D
function m:__Gen_Delegate_Imp523(p0) end

---@param p0 UnityEngine.Vector3
---@return ProGrids.Axis
function m:__Gen_Delegate_Imp524(p0) end

---@param p0 UnityEngine.Vector3
---@param p1 any
---@return ProGrids.Axis
function m:__Gen_Delegate_Imp525(p0, p1) end

---@param p0 UnityEngine.Vector3
---@param p1 UnityEngine.Vector3
---@return number
function m:__Gen_Delegate_Imp526(p0, p1) end

---@param p0 UnityEngine.Vector3
---@param p1 number
---@return UnityEngine.Vector3
function m:__Gen_Delegate_Imp527(p0, p1) end

---@param p0 any
---@param p1 any
---@return System.Type
function m:__Gen_Delegate_Imp528(p0, p1) end

---@param p0 UnityEngine.Vector3
---@param p1 UnityEngine.Vector3
---@param p2 number
---@return UnityEngine.Vector3
function m:__Gen_Delegate_Imp529(p0, p1, p2) end

---@param p0 number
---@param p1 number
---@return number
function m:__Gen_Delegate_Imp530(p0, p1) end

---@param p0 UnityEngine.Vector3
---@return number
function m:__Gen_Delegate_Imp531(p0) end

---@param p0 any
---@param p1 HedgehogTeam.EasyTouch.EasyTouch.EvtType
function m:__Gen_Delegate_Imp532(p0, p1) end

---@param p0 any
---@param p1 any
---@param p2 boolean
---@return boolean
function m:__Gen_Delegate_Imp533(p0, p1, p2) end

---@param p0 any
---@param p1 HedgehogTeam.EasyTouch.EasyTouch.EvtType
---@param p2 any
function m:__Gen_Delegate_Imp534(p0, p1, p2) end

---@param p0 any
---@param p1 HedgehogTeam.EasyTouch.EasyTouch.EvtType
---@return boolean
function m:__Gen_Delegate_Imp535(p0, p1) end

---@param p0 any
---@param p1 any
---@return HedgehogTeam.EasyTouch.EasyTouchTrigger.EasyTouchReceiver
function m:__Gen_Delegate_Imp536(p0, p1) end

---@param p0 any
---@return HedgehogTeam.EasyTouch.Gesture
function m:__Gen_Delegate_Imp537(p0) end

---@return HedgehogTeam.EasyTouch.EasyTouch
function m:__Gen_Delegate_Imp538() end

---@return HedgehogTeam.EasyTouch.Gesture
function m:__Gen_Delegate_Imp539() end

---@param p0 any
---@param p1 number
---@param p2 HedgehogTeam.EasyTouch.EasyTouch.EvtType
---@param p3 any
---@param p4 HedgehogTeam.EasyTouch.EasyTouch.SwipeDirection
---@param p5 number
---@param p6 UnityEngine.Vector2
function m:__Gen_Delegate_Imp540(p0, p1, p2, p3, p4, p5, p6) end

---@param p0 any
---@param p1 UnityEngine.Vector2
---@param p2 UnityEngine.Vector2
---@param p3 number
function m:__Gen_Delegate_Imp541(p0, p1, p2, p3) end

---@param p0 any
---@param p1 HedgehogTeam.EasyTouch.EasyTouch.GestureType
---@param p2 UnityEngine.Vector2
---@param p3 UnityEngine.Vector2
---@param p4 UnityEngine.Vector2
---@param p5 number
---@param p6 boolean
---@param p7 number
---@param p8 number
---@param p9 number
function m:__Gen_Delegate_Imp542(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9) end

---@param p0 any
---@param p1 HedgehogTeam.EasyTouch.EasyTouch.EvtType
---@param p2 UnityEngine.Vector2
---@param p3 UnityEngine.Vector2
---@param p4 UnityEngine.Vector2
---@param p5 number
---@param p6 HedgehogTeam.EasyTouch.EasyTouch.SwipeDirection
---@param p7 number
---@param p8 UnityEngine.Vector2
---@param p9 number
---@param p10 number
---@param p11 number
function m:__Gen_Delegate_Imp543(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11) end

---@param p0 any
---@param p1 UnityEngine.Vector2
---@param p2 any
---@param p3 boolean
---@return boolean
function m:__Gen_Delegate_Imp544(p0, p1, p2, p3) end

---@param p0 any
---@param p1 UnityEngine.Vector2
---@param p2 UnityEngine.Vector2
---@return HedgehogTeam.EasyTouch.EasyTouch.SwipeDirection
function m:__Gen_Delegate_Imp545(p0, p1, p2) end

---@param p0 any
---@param p1 UnityEngine.Vector2
---@param p2 boolean
---@return boolean
function m:__Gen_Delegate_Imp546(p0, p1, p2) end

---@param p0 any
---@param p1 number
---@return HedgehogTeam.EasyTouch.Finger
function m:__Gen_Delegate_Imp547(p0, p1) end

---@param p0 any
---@param p1 UnityEngine.Vector2
---@return boolean
function m:__Gen_Delegate_Imp548(p0, p1) end

---@param p0 number
---@param p1 boolean
---@return UnityEngine.GameObject
function m:__Gen_Delegate_Imp549(p0, p1) end

---@param p0 UnityEngine.Vector2
---@param p1 boolean
---@return UnityEngine.GameObject
function m:__Gen_Delegate_Imp550(p0, p1) end

---@param p0 UnityEngine.LayerMask
function m:__Gen_Delegate_Imp551(p0) end

---@return UnityEngine.LayerMask
function m:__Gen_Delegate_Imp552() end

---@param p0 number
---@return UnityEngine.Camera
function m:__Gen_Delegate_Imp553(p0) end

---@param p0 HedgehogTeam.EasyTouch.EasyTouch.GesturePriority
function m:__Gen_Delegate_Imp554(p0) end

---@return HedgehogTeam.EasyTouch.EasyTouch.GesturePriority
function m:__Gen_Delegate_Imp555() end

---@param p0 HedgehogTeam.EasyTouch.EasyTouch.DoubleTapDetection
function m:__Gen_Delegate_Imp556(p0) end

---@return HedgehogTeam.EasyTouch.EasyTouch.DoubleTapDetection
function m:__Gen_Delegate_Imp557() end

---@param p0 HedgehogTeam.EasyTouch.EasyTouch.TwoFingerPickMethod
function m:__Gen_Delegate_Imp558(p0) end

---@return HedgehogTeam.EasyTouch.EasyTouch.TwoFingerPickMethod
function m:__Gen_Delegate_Imp559() end

---@param p0 any
---@param p1 boolean
---@return number
function m:__Gen_Delegate_Imp560(p0, p1) end

---@param p0 any
---@param p1 number
---@param p2 any
---@return HedgehogTeam.EasyTouch.Finger
function m:__Gen_Delegate_Imp561(p0, p1, p2) end

---@param p0 any
---@param p1 number
---@return UnityEngine.Vector2
function m:__Gen_Delegate_Imp562(p0, p1) end

---@param p0 any
---@param p1 boolean
---@return UnityEngine.Vector2
function m:__Gen_Delegate_Imp563(p0, p1) end

---@param p0 any
---@param p1 number
---@return UnityEngine.Vector3
function m:__Gen_Delegate_Imp564(p0, p1) end

---@param p0 any
---@return BeautifyEffect.BEAUTIFY_PRESET
function m:__Gen_Delegate_Imp565(p0) end

---@param p0 any
---@param p1 BeautifyEffect.BEAUTIFY_PRESET
function m:__Gen_Delegate_Imp566(p0, p1) end

---@param p0 any
---@return BeautifyEffect.BEAUTIFY_QUALITY
function m:__Gen_Delegate_Imp567(p0) end

---@param p0 any
---@param p1 BeautifyEffect.BEAUTIFY_QUALITY
function m:__Gen_Delegate_Imp568(p0, p1) end

---@param p0 any
---@return BeautifyEffect.BeautifyProfile
function m:__Gen_Delegate_Imp569(p0) end

---@param p0 any
---@return UnityEngine.LayerMask
function m:__Gen_Delegate_Imp570(p0) end

---@param p0 any
---@param p1 UnityEngine.LayerMask
function m:__Gen_Delegate_Imp571(p0, p1) end

---@param p0 any
---@return UnityEngine.FilterMode
function m:__Gen_Delegate_Imp572(p0) end

---@param p0 any
---@param p1 UnityEngine.FilterMode
function m:__Gen_Delegate_Imp573(p0, p1) end

---@param p0 any
---@return BeautifyEffect.BEAUTIFY_TMO
function m:__Gen_Delegate_Imp574(p0) end

---@param p0 any
---@param p1 BeautifyEffect.BEAUTIFY_TMO
function m:__Gen_Delegate_Imp575(p0, p1) end

---@return BeautifyEffect.Beautify
function m:__Gen_Delegate_Imp576() end

---@param p0 any
---@param p1 any
---@param p2 boolean
---@param p3 number
---@return UnityEngine.RenderTexture
function m:__Gen_Delegate_Imp577(p0, p1, p2, p3) end

---@param p0 any
---@param p1 number
---@param p2 number
---@return System.Collections.IEnumerator
function m:__Gen_Delegate_Imp578(p0, p1, p2) end

---@param p0 any
---@param p1 any
---@param p2 any
---@param p3 number
function m:__Gen_Delegate_Imp579(p0, p1, p2, p3) end

---@param p0 any
---@param p1 any
---@param p2 any
---@return UnityEngine.Material
function m:__Gen_Delegate_Imp580(p0, p1, p2) end

---@param p0 any
---@param p1 boolean
---@param p2 boolean
---@return boolean
function m:__Gen_Delegate_Imp581(p0, p1, p2) end

---@virtual
---@param type System.Type
---@return fun(...:any|any[]):
function m:GetDelegateByType(type) end

---@param L System.IntPtr
---@param nArgs number
---@param nResults number
---@param errFunc number
function m:PCall(L, nArgs, nResults, errFunc) end

function m:InvokeSessionStart() end

---@param nRet number
function m:Invoke(nRet) end

function m:InvokeSessionEnd() end

---@return any
function m:InvokeSessionEndWithResult() end

---@param p any
function m:InParam(p) end

---@param ps any[]
function m:InParams(ps) end

---@param pos number
---@return any
function m:OutParam(pos) end

---@overload fun(p1:any)
---@overload fun(p1:any, p2:any)
---@overload fun(p1:any, p2:any, p3:any)
---@overload fun(p1:any, p2:any, p3:any, p4:any)
function m:Action() end

---@overload fun(p1:any):
---@overload fun(p1:any, p2:any):
---@overload fun(p1:any, p2:any, p3:any):
---@overload fun(p1:any, p2:any, p3:any, p4:any):
---@return any
function m:Func() end

XLua.DelegateBridge = m
return m
