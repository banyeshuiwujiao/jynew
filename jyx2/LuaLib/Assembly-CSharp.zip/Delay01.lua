---@class Delay01 : UnityEngine.MonoBehaviour
---@field public delayTime number
local m = {}

Delay01 = m
return m
