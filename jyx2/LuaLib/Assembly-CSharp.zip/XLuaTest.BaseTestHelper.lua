---@class XLuaTest.BaseTestHelper : System.Object
local m = {}

XLuaTest.BaseTestHelper = m
return m
