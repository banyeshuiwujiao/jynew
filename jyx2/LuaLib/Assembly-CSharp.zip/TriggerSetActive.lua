---@class TriggerSetActive : UnityEngine.MonoBehaviour
---@field public target UnityEngine.GameObject[]
---@field public actived boolean
local m = {}

TriggerSetActive = m
return m
