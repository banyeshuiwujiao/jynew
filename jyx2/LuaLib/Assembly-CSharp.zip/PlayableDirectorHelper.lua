---@class PlayableDirectorHelper : UnityEngine.MonoBehaviour
---@field public m_PreviewRole UnityEngine.Animator
---@field public m_BindObject UnityEngine.GameObject
---@field public m_BindBoneName string
---@field public m_IsLocalTransform boolean
local m = {}

---@param player UnityEngine.GameObject
function m:BindPlayer(player) end

function m:ClearTempObjects() end

PlayableDirectorHelper = m
return m
