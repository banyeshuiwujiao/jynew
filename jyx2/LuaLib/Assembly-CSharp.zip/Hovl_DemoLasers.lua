---@class Hovl_DemoLasers : UnityEngine.MonoBehaviour
---@field public FirePoint UnityEngine.GameObject
---@field public Cam UnityEngine.Camera
---@field public MaxLength number
---@field public Prefabs UnityEngine.GameObject[]
local m = {}

Hovl_DemoLasers = m
return m
