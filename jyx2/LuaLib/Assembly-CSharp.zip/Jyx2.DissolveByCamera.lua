---@class Jyx2.DissolveByCamera : UnityEngine.MonoBehaviour
local m = {}

Jyx2.DissolveByCamera = m
return m
