---@class CameraFilterPack_3D_Distortion : UnityEngine.MonoBehaviour
---@field public ChangeColorRGB UnityEngine.Color @static
---@field public SCShader UnityEngine.Shader
---@field public _Visualize boolean
---@field public _FixDistance number
---@field public _Distance number
---@field public _Size number
---@field public DistortionLevel number
---@field public DistortionSize number
---@field public LightIntensity number
---@field public AutoAnimatedNear boolean
---@field public AutoAnimatedNearSpeed number
local m = {}

CameraFilterPack_3D_Distortion = m
return m
