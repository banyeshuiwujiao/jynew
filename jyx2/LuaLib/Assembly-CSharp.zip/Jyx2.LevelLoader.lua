---@class Jyx2.LevelLoader : System.Object
local m = {}

---@overload fun(map:Jyx2.LMapConfig, para:LevelMaster.LevelLoadPara) @static
---@overload fun(map:Jyx2.LMapConfig) @static
---@static
---@param map Jyx2.LMapConfig
---@param para LevelMaster.LevelLoadPara
---@param callback fun()
function m.LoadGameMap(map, para, callback) end

---@overload fun(battle:Jyx2.LBattleConfig, callback:fun(obj:Jyx2.BattleResult)) @static
---@static
---@param battleId number
---@param callback fun(obj:Jyx2.BattleResult)
function m.LoadBattle(battleId, callback) end

Jyx2.LevelLoader = m
return m
