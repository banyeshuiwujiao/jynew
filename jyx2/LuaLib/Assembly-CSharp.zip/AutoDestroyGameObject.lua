---@class AutoDestroyGameObject : UnityEngine.MonoBehaviour
---@field public m_DestroyInSeconds number
local m = {}

AutoDestroyGameObject = m
return m
