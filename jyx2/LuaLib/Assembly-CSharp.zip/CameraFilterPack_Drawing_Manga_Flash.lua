---@class CameraFilterPack_Drawing_Manga_Flash : UnityEngine.MonoBehaviour
---@field public SCShader UnityEngine.Shader
---@field public Size number
---@field public Speed number
---@field public PosX number
---@field public PosY number
---@field public Intensity number
local m = {}

CameraFilterPack_Drawing_Manga_Flash = m
return m
