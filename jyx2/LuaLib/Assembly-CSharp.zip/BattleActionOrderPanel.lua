---@class BattleActionOrderPanel : Jyx2_UIBase
local m = {}

function m:InitTrans() end

BattleActionOrderPanel = m
return m
