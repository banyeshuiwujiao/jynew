---@class CameraFilterPack_Distortion_ShockWave : UnityEngine.MonoBehaviour
---@field public SCShader UnityEngine.Shader
---@field public PosX number
---@field public PosY number
---@field public Speed number
local m = {}

CameraFilterPack_Distortion_ShockWave = m
return m
