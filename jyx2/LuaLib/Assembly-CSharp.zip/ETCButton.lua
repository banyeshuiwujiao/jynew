---@class ETCButton : ETCBase
---@field public onDown ETCButton.OnDownHandler
---@field public onPressed ETCButton.OnPressedHandler
---@field public onPressedValue ETCButton.OnPressedValueandler
---@field public onUp ETCButton.OnUPHandler
---@field public axis ETCAxis
---@field public normalSprite UnityEngine.Sprite
---@field public normalColor UnityEngine.Color
---@field public pressedSprite UnityEngine.Sprite
---@field public pressedColor UnityEngine.Color
local m = {}

---@virtual
function m:Start() end

---@virtual
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnPointerEnter(eventData) end

---@virtual
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnPointerDown(eventData) end

---@virtual
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnPointerUp(eventData) end

---@virtual
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnPointerExit(eventData) end

ETCButton = m
return m
