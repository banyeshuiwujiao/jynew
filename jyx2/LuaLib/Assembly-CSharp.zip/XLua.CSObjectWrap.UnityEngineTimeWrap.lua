---@class XLua.CSObjectWrap.UnityEngineTimeWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.UnityEngineTimeWrap = m
return m
