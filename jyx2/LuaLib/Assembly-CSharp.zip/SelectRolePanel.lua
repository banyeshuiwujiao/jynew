---@class SelectRolePanel : Jyx2_UIBase
---@field public IsCancelBtnEnable boolean
---@field public IsAllSelectBtnEnable boolean
local m = {}

---@static
---@param paras SelectRoleParams
---@return Cysharp.Threading.Tasks.UniTask_1_System_Collections_Generic_List_1_Jyx2_RoleInstance__
function m.WaitForSelectConfirm(paras) end

function m:OnConfirmClick() end

function m:OnCancelClick() end

function m:OnAllClick() end

function m:InitTrans() end

SelectRolePanel = m
return m
