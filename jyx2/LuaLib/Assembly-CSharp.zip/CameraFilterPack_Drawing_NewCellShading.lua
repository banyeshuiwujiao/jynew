---@class CameraFilterPack_Drawing_NewCellShading : UnityEngine.MonoBehaviour
---@field public SCShader UnityEngine.Shader
---@field public Threshold number
local m = {}

CameraFilterPack_Drawing_NewCellShading = m
return m
