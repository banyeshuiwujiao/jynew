---@class MOD.UI.ModPanelNew : Jyx2_UIBase
---@field public Layer UILayer
local m = {}

function m:OnCloseBtnClick() end

function m:OnOpenSteamWorkshop() end

function m:DoReset() end

---@static
function m.SwitchSceneTo() end

MOD.UI.ModPanelNew = m
return m
