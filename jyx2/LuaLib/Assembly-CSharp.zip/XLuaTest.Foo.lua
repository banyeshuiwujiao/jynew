---@class XLuaTest.Foo : System.Object
local m = {}

---@param a XLuaTest.Foo1Parent
function m:Test1(a) end

---@param a XLuaTest.Foo1Parent
---@param b XLuaTest.Foo2Parent
---@param c UnityEngine.GameObject
---@return XLuaTest.Foo1Parent
function m:Test2(a, b, c) end

---@param a any
function m:UnsupportedMethod1(a) end

function m:UnsupportedMethod2() end

---@param a any
function m:UnsupportedMethod3(a) end

XLuaTest.Foo = m
return m
