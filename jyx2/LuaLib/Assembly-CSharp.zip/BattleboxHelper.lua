---@class BattleboxHelper : UnityEngine.MonoBehaviour
---@field public Instance BattleboxHelper @static
---@field public m_MoveZoneDrawRange number
---@field public AnalogMoved boolean
---@field public CanUpdate boolean
local m = {}

---@param pos UnityEngine.Vector3
---@return boolean
function m:CanEnterBattle(pos) end

---@param pos UnityEngine.Vector3
---@return boolean
function m:EnterBattle(pos) end

---@param pos UnityEngine.Vector3
function m:OnTestControl(pos) end

---@param xindex number
---@param yindex number
---@return Jyx2.BattleBlockData
function m:GetBlockData(xindex, yindex) end

---@return Jyx2.BattleBlockData[]
function m:GetBattleBlocks() end

---@param pos UnityEngine.Vector3
---@return Jyx2.BattleBlockData
function m:GetLocationBattleBlock(pos) end

---@param xindex number
---@param yindex number
---@return boolean
function m:IsBlockExists(xindex, yindex) end

---@virtual
function m:OnUpdate() end

---@param x number
---@param y number
---@return boolean
function m:IsMoveSelectAndBlocked(x, y) end

---@param x number
---@param y number
---@return boolean
function m:IsRoleStandingInBlock(x, y) end

function m:TryCancelBoxSelection() end

---@param value fun(obj:Jyx2.BattleBlockData)
function m:add_OnBlockSelectMoved(value) end

---@param value fun(obj:Jyx2.BattleBlockData)
function m:remove_OnBlockSelectMoved(value) end

---@param value fun(obj:Jyx2.BattleBlockData)
function m:add_OnBlockConfirmed(value) end

---@param value fun(obj:Jyx2.BattleBlockData)
function m:remove_OnBlockConfirmed(value) end

---@overload fun(role:Jyx2.RoleInstance, list:System.Collections.Generic.IEnumerable_1_Jyx2_BattleBlockVector_, type:Jyx2.BattleBlockType)
---@overload fun(role:Jyx2.RoleInstance, list:System.Collections.Generic.IEnumerable_1_Jyx2_BattleBlockVector_)
---@param role Jyx2.RoleInstance
---@param list System.Collections.Generic.IEnumerable_1_Jyx2_BattleBlockVector_
---@param type Jyx2.BattleBlockType
---@param selectMiddlePos boolean
function m:ShowBlocks(role, list, type, selectMiddlePos) end

---@param list System.Collections.Generic.IEnumerable_1_Jyx2_BattleBlockVector_
function m:ShowRangeBlocks(list) end

---@overload fun()
---@param hideRangeBlock boolean
function m:HideAllBlocks(hideRangeBlock) end

function m:ShowAllBlocks() end

BattleboxHelper = m
return m
