---@class UnityEngine.UI.SelectButton : UnityEngine.UI.Selectable
---@field public onClick UnityEngine.UI.ButtonClickEvent
local m = {}

---@virtual
function m:OnClickSelect() end

---@virtual
function m:OnClickDeselect() end

---@virtual
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnPointerClick(eventData) end

UnityEngine.UI.SelectButton = m
return m
