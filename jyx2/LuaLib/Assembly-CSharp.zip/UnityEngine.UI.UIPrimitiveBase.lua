---@class UnityEngine.UI.UIPrimitiveBase : UnityEngine.UI.MaskableGraphic
---@field public sprite UnityEngine.Sprite
---@field public overrideSprite UnityEngine.Sprite
---@field public eventAlphaThreshold number
---@field public mainTexture UnityEngine.Texture
---@field public pixelsPerUnit number
---@field public minWidth number
---@field public preferredWidth number
---@field public flexibleWidth number
---@field public minHeight number
---@field public preferredHeight number
---@field public flexibleHeight number
---@field public layoutPriority number
local m = {}

---@virtual
function m:CalculateLayoutInputHorizontal() end

---@virtual
function m:CalculateLayoutInputVertical() end

---@virtual
---@param screenPoint UnityEngine.Vector2
---@param eventCamera UnityEngine.Camera
---@return boolean
function m:IsRaycastLocationValid(screenPoint, eventCamera) end

UnityEngine.UI.UIPrimitiveBase = m
return m
