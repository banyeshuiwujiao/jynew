---@class Jyx2.GameSettings : System.Object
local m = {}

---@static
function m.Refresh() end

---@overload fun(key:string): @static
---@static
---@param key string
---@param defaultVal number
---@return number
function m.GetInt(key, defaultVal) end

---@overload fun(key:string): @static
---@static
---@param key string
---@param defaultVal number
---@return number
function m.GetFloat(key, defaultVal) end

---@static
---@param key string
---@return string
function m.Get(key) end

Jyx2.GameSettings = m
return m
