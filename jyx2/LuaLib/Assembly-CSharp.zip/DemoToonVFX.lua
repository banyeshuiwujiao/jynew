---@class DemoToonVFX : UnityEngine.MonoBehaviour
---@field public Holder UnityEngine.Transform
---@field public currDistance number
---@field public xRotate number
---@field public yRotate number
---@field public yMinLimit number
---@field public yMaxLimit number
---@field public prevDistance number
---@field public Prefabs UnityEngine.GameObject[]
---@field public HueTexture UnityEngine.Texture
---@field public activationTime number[]
---@field public animObject UnityEngine.Animator
---@field public useAnimation boolean
local m = {}

DemoToonVFX = m
return m
