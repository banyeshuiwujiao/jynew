---@class Jyx2.SkillCastResult : System.Object
---@field public skilltarget_x number
---@field public skilltarget_y number
---@field public skillCast Jyx2.SkillCastInstance
---@field public r1 Jyx2.RoleInstance
---@field public r2 Jyx2.RoleInstance
---@field public damage number
---@field public damageMp number
---@field public addMp number
---@field public addMaxMp number
---@field public poison number
---@field public depoison number
---@field public heal number
---@field public hurt number
local m = {}

---@return number
function m:GetTotalScore() end

---@return boolean
function m:IsDamage() end

function m:Run() end

Jyx2.SkillCastResult = m
return m
