---@class CameraFilterPack_Atmosphere_Rain_Pro : UnityEngine.MonoBehaviour
---@field public SCShader UnityEngine.Shader
---@field public Fade number
---@field public Intensity number
---@field public DirectionX number
---@field public Size number
---@field public Speed number
---@field public Distortion number
---@field public StormFlashOnOff number
---@field public DropOnOff number
local m = {}

CameraFilterPack_Atmosphere_Rain_Pro = m
return m
