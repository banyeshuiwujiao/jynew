---@class CameraFilterPack_Lut_2_Lut : UnityEngine.MonoBehaviour
---@field public SCShader UnityEngine.Shader
---@field public LutTexture UnityEngine.Texture2D
---@field public LutTexture2 UnityEngine.Texture2D
---@field public Blend number
---@field public Fade number
local m = {}

function m:SetIdentityLut() end

---@param tex2d UnityEngine.Texture2D
---@return boolean
function m:ValidDimensions(tex2d) end

---@param temp2DTex UnityEngine.Texture2D
---@param cv3D UnityEngine.Texture3D
---@return UnityEngine.Texture3D
function m:Convert(temp2DTex, cv3D) end

CameraFilterPack_Lut_2_Lut = m
return m
