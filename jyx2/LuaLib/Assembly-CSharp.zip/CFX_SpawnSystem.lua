---@class CFX_SpawnSystem : UnityEngine.MonoBehaviour
---@field public AllObjectsLoaded boolean @static
---@field public objectsToPreload UnityEngine.GameObject[]
---@field public objectsToPreloadTimes number[]
---@field public hideObjectsInHierarchy boolean
local m = {}

---@overload fun(sourceObj:UnityEngine.GameObject): @static
---@static
---@param sourceObj UnityEngine.GameObject
---@param activateObject boolean
---@return UnityEngine.GameObject
function m.GetNextObject(sourceObj, activateObject) end

---@overload fun(sourceObj:UnityEngine.GameObject) @static
---@static
---@param sourceObj UnityEngine.GameObject
---@param poolSize number
function m.PreloadObject(sourceObj, poolSize) end

---@static
---@param sourceObj UnityEngine.GameObject
function m.UnloadObjects(sourceObj) end

CFX_SpawnSystem = m
return m
