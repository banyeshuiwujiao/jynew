---@class XLuaTest.Foo1Child : XLuaTest.Foo1Parent
local m = {}

XLuaTest.Foo1Child = m
return m
