---@class XLuaTest.GenericStruct_1_T_ : System.ValueType
local m = {}

---@param p number
---@return any
function m:GetA(p) end

XLuaTest.GenericStruct_1_T_ = m
return m
