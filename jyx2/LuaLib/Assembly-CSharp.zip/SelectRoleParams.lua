---@class SelectRoleParams : System.Object
---@field public roleList Jyx2.RoleInstance[]
---@field public selectList Jyx2.RoleInstance[]
---@field public mustSelect fun(arg:Jyx2.RoleInstance):
---@field public callback fun(obj:SelectRoleParams)
---@field public maxCount number
---@field public title string
---@field public canCancel boolean
---@field public needCloseAfterClickOK boolean
---@field public isDefaultSelect boolean
---@field public isCancelClick boolean
---@field public IsFull boolean
local m = {}

function m:SetDefaultRole() end

---@param role Jyx2.RoleInstance
---@return boolean
function m:IsRoleMustSelect(role) end

SelectRoleParams = m
return m
