---@class DebugPanel : UnityEngine.MonoBehaviour
---@field public m_ChangeScene UnityEngine.UI.Dropdown
---@field public m_TransportDropdown UnityEngine.UI.Dropdown
---@field public CanUpdate boolean
local m = {}

function m:DebugPanelSwitch() end

---@param value number
function m:OnChangeScene(value) end

---@param value number
function m:OnTransport(value) end

---@virtual
function m:OnUpdate() end

DebugPanel = m
return m
