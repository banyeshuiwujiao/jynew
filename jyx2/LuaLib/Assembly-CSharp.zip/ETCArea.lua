---@class ETCArea : UnityEngine.MonoBehaviour
---@field public show boolean
local m = {}

function m:Awake() end

---@param preset ETCArea.AreaPreset
function m:ApplyPreset(preset) end

ETCArea = m
return m
