---@class Jyx2.MoveSearchHelper : System.Object
---@field public X number
---@field public Y number
---@field public Cost number
---@field public front Jyx2.MoveSearchHelper
---@field public Inaccessible boolean
local m = {}

Jyx2.MoveSearchHelper = m
return m
