---@class BagUIPanel : Jyx2_UIBase
---@field public Layer UILayer
---@field public IsUseButtonActive boolean
local m = {}

function m:OnCloseBtnClick() end

function m:OnUseBtnClick() end

function m:TabLeft() end

function m:TabRight() end

function m:InitTrans() end

BagUIPanel = m
return m
