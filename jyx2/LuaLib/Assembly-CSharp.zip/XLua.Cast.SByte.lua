---@class XLua.Cast.SByte : XLua.Cast.Any_1_System_SByte_
local m = {}

XLua.Cast.SByte = m
return m
