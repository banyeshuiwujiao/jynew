---@class Jyx2.Jyx2InteractiveButton : System.Object
local m = {}

---@static
---@param text string
---@param callback fun()
function m.Show(text, callback) end

---@static
function m.Hide() end

---@static
---@return UnityEngine.UI.Button
function m.GetInteractiveButton() end

Jyx2.Jyx2InteractiveButton = m
return m
