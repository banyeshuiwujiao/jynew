---@class Jyx2.Jyx2_PlayerAutoWalk : UnityEngine.MonoBehaviour
---@field public IsAutoWalking boolean
local m = {}

---@param fromVector UnityEngine.Vector3
---@param toVector UnityEngine.Vector3
---@param callback fun()
function m:PlayerWarkFromTo(fromVector, toVector, callback) end

Jyx2.Jyx2_PlayerAutoWalk = m
return m
