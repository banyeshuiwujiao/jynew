---@class XLua.CSObjectWrap.XLuaTestFoo2ChildWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.XLuaTestFoo2ChildWrap = m
return m
