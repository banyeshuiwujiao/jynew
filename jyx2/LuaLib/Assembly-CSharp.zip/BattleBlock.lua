---@class BattleBlock : UnityEngine.MonoBehaviour
---@field public CurrentX number @static
---@field public CurrentY number @static
---@field public ShowAll boolean @static
---@field public currentBlock BattleBlock @static
---@field public X number
---@field public Y number
---@field public Image UnityEngine.UI.Image
---@field public Animator UnityEngine.GameObject
---@field public Enemy UnityEngine.GameObject
---@field public attackRangeSp UnityEngine.Sprite
---@field public attackDistanceSp UnityEngine.Sprite
---@field public attackTargetSp UnityEngine.Sprite
---@field public currentAttackRangeSp UnityEngine.Sprite
---@field public moveTargetSp UnityEngine.Sprite
---@field public moveRangeSp UnityEngine.Sprite
---@field public moveRangeEnemySp UnityEngine.Sprite
---@field public noneSp UnityEngine.Sprite
---@field public callback fun(arg1:number, arg2:number)
---@field public IsActive boolean
---@field public Status BattleBlockStatus
local m = {}

---@virtual
---@param data UnityEngine.EventSystems.PointerEventData
function m:OnPointerDown(data) end

---@virtual
---@param data UnityEngine.EventSystems.PointerEventData
function m:OnPointerUp(data) end

---@virtual
---@param data UnityEngine.EventSystems.PointerEventData
function m:OnDrag(data) end

---@virtual
---@param data UnityEngine.EventSystems.PointerEventData
function m:OnPointerEnter(data) end

---@virtual
---@param data UnityEngine.EventSystems.PointerEventData
function m:OnPointerExit(data) end

function m:Reset() end

function m:MarkEnemy() end

function m:Hightlight() end

BattleBlock = m
return m
