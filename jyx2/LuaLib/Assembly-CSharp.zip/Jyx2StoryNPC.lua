---@class Jyx2StoryNPC : UnityEngine.MonoBehaviour
---@field public startAnimationTrigger string
local m = {}

Jyx2StoryNPC = m
return m
