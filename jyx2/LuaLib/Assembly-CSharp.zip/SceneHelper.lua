---@class SceneHelper : System.Object
local m = {}

---@static
---@param scene string
function m.StartScene(scene) end

SceneHelper = m
return m
