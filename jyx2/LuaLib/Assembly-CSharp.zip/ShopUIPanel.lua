---@class ShopUIPanel : Jyx2_UIBase
---@field public CurSelectItem ShopUIItem
local m = {}

function m:OnCloseClick() end

function m:OnConfirmClick() end

function m:InitTrans() end

ShopUIPanel = m
return m
