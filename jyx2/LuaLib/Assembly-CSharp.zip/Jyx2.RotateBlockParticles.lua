---@class Jyx2.RotateBlockParticles : UnityEngine.MonoBehaviour
local m = {}

---@param from UnityEngine.Transform
---@param to UnityEngine.Transform
function m:AdjustRotation(from, to) end

Jyx2.RotateBlockParticles = m
return m
