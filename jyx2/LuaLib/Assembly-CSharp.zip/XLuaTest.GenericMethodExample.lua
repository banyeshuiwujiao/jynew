---@class XLuaTest.GenericMethodExample : UnityEngine.MonoBehaviour
local m = {}

XLuaTest.GenericMethodExample = m
return m
