---@class XLua.LuaTypes : System.Enum
---@field public LUA_TNONE XLua.LuaTypes @static
---@field public LUA_TNIL XLua.LuaTypes @static
---@field public LUA_TNUMBER XLua.LuaTypes @static
---@field public LUA_TSTRING XLua.LuaTypes @static
---@field public LUA_TBOOLEAN XLua.LuaTypes @static
---@field public LUA_TTABLE XLua.LuaTypes @static
---@field public LUA_TFUNCTION XLua.LuaTypes @static
---@field public LUA_TUSERDATA XLua.LuaTypes @static
---@field public LUA_TTHREAD XLua.LuaTypes @static
---@field public LUA_TLIGHTUSERDATA XLua.LuaTypes @static
---@field public value__ number
local m = {}

XLua.LuaTypes = m
return m
