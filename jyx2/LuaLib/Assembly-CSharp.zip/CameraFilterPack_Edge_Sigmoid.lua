---@class CameraFilterPack_Edge_Sigmoid : UnityEngine.MonoBehaviour
---@field public SCShader UnityEngine.Shader
---@field public Gain number
local m = {}

CameraFilterPack_Edge_Sigmoid = m
return m
