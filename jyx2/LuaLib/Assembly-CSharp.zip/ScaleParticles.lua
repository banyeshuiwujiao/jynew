---@class ScaleParticles : UnityEngine.MonoBehaviour
---@field public ScaleSize number
local m = {}

ScaleParticles = m
return m
