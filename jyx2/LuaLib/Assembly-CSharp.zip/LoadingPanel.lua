---@class LoadingPanel : UnityEngine.MonoBehaviour
---@field public m_LoadingText UnityEngine.UI.Text
local m = {}

---@static
---@param scenePath string
---@return Cysharp.Threading.Tasks.UniTask
function m.Create(scenePath) end

LoadingPanel = m
return m
