---@class LoadingPanel : UnityEngine.MonoBehaviour
---@field public m_LoadingText UnityEngine.UI.Text
local m = {}

---@static
---@param task Cysharp.Threading.Tasks.UniTask
function m.Show(task) end

---@static
function m.Hide() end

---@static
---@param scenePath string
---@return Cysharp.Threading.Tasks.UniTask
function m.Create(scenePath) end

---@param scenePath string
---@return Cysharp.Threading.Tasks.UniTask
function m:LoadLevel(scenePath) end

LoadingPanel = m
return m
