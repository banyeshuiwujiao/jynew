---@class CameraOrbitNavigation : UnityEngine.MonoBehaviour
---@field public target UnityEngine.Transform
---@field public targetOffset UnityEngine.Vector3
---@field public distance number
---@field public maxDistance number
---@field public minDistance number
---@field public xSpeed number
---@field public ySpeed number
---@field public yMinLimit number
---@field public yMaxLimit number
---@field public zoomRate number
---@field public panSpeed number
---@field public zoomDampening number
local m = {}

CameraOrbitNavigation = m
return m
