---@class GeneralSettingsPanel : Jyx2_UIBase
---@field public resolutionDropdown UnityEngine.UI.Dropdown
---@field public windowDropdown UnityEngine.UI.Dropdown
---@field public difficultyDropdown UnityEngine.UI.Dropdown
---@field public viewportDropdown UnityEngine.UI.Dropdown
---@field public languageDropdown UnityEngine.UI.Dropdown
---@field public debugModeDropdown UnityEngine.UI.Dropdown
---@field public mobileMoveModeDropdown UnityEngine.UI.Dropdown
---@field public volumeSlider UnityEngine.UI.Slider
---@field public soundEffectSlider UnityEngine.UI.Slider
---@field public JoyStickTestButton UnityEngine.UI.Button
local m = {}

---@virtual
function m:ApplySetting() end

---@virtual
---@param isVisible boolean
function m:SetVisibility(isVisible) end

function m:InitResolutionDropdown() end

function m:InitDifficultyDropdown() end

function m:InitSoundEffectSlider() end

GeneralSettingsPanel = m
return m
