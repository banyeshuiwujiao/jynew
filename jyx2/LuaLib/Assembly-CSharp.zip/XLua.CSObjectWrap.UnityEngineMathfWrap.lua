---@class XLua.CSObjectWrap.UnityEngineMathfWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.UnityEngineMathfWrap = m
return m
