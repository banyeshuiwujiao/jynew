---@class CFX3_AutoStopLoopedEffect : UnityEngine.MonoBehaviour
---@field public effectDuration number
local m = {}

CFX3_AutoStopLoopedEffect = m
return m
