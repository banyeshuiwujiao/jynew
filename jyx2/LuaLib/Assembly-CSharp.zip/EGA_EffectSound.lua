---@class EGA_EffectSound : UnityEngine.MonoBehaviour
---@field public Repeating boolean
---@field public RepeatTime number
---@field public StartTime number
---@field public RandomVolume boolean
---@field public minVolume number
---@field public maxVolume number
local m = {}

EGA_EffectSound = m
return m
