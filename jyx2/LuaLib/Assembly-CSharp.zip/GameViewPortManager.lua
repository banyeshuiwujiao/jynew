---@class GameViewPortManager : UnityEngine.MonoBehaviour
---@field public Instance GameViewPortManager @static
local m = {}

---@param value any
function m:SetViewport(value) end

---@return GameViewPortManager.ViewportType
function m:GetViewportType() end

---@return Cinemachine.CinemachineVirtualCamera
function m:GetFollowVCam() end

---@param player UnityEngine.Transform
function m:InitForLevel(player) end

GameViewPortManager = m
return m
