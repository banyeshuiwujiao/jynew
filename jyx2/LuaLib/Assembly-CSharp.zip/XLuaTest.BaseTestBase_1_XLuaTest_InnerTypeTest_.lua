---@class XLuaTest.BaseTestBase_1_XLuaTest_InnerTypeTest_ : XLuaTest.BaseTestHelper
local m = {}

---@virtual
---@param p number
function m:Foo(p) end

XLuaTest.BaseTestBase_1_XLuaTest_InnerTypeTest_ = m
return m
