---@class CameraHolder : UnityEngine.MonoBehaviour
---@field public Holder UnityEngine.Transform
---@field public currDistance number
---@field public xRotate number
---@field public yRotate number
---@field public yMinLimit number
---@field public yMaxLimit number
---@field public prevDistance number
---@field public Prefabs UnityEngine.GameObject[]
---@field public HueTexture UnityEngine.Texture
local m = {}

CameraHolder = m
return m
