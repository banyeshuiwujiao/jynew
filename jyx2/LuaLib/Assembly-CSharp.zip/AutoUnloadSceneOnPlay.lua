---@class AutoUnloadSceneOnPlay : UnityEngine.MonoBehaviour
local m = {}

---@param sceneName string
---@return System.Collections.IEnumerator
function m:UnloadSceneAsync(sceneName) end

AutoUnloadSceneOnPlay = m
return m
