---@class Jyx2.RuntimeEnvSetup : System.Object
---@field public CurrentModConfig MODRootConfig @static
---@field public CurrentModId string @static
---@field public IsLoading boolean @static
local m = {}

---@static
---@param mod Jyx2.MOD.ModV2.GameModBase
function m.SetCurrentMod(mod) end

---@static
---@return Jyx2.MOD.ModV2.GameModBase
function m.GetCurrentMod() end

---@static
function m.ForceClear() end

---@static
---@return Cysharp.Threading.Tasks.UniTask_1_System_Boolean_
function m.Setup() end

Jyx2.RuntimeEnvSetup = m
return m
