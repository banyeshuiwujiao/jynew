---@class UIHelper : System.Object
local m = {}

---@static
---@param item Jyx2.LItemConfig
---@return table<number, number>
function m.GetItemEffect(item) end

---@static
---@param item Jyx2.LItemConfig
---@return table<number, number>
function m.GetUseItemRequire(item) end

---@static
---@param item Jyx2.LItemConfig
---@return string
function m.GetItemDesText(item) end

UIHelper = m
return m
