---@class BattleActionUIPanel : Jyx2_UIBase
---@field public RightActionBtns UnityEngine.UI.Button[]
---@field public IsFocusOnSkillsItems boolean
local m = {}

---@return Jyx2.RoleInstance
function m:GetCurrentRole() end

---@virtual
function m:Update() end

function m:OnAutoClicked() end

function m:OnCancelClick() end

function m:OnMoveClick() end

function m:OnUsePoisonClick() end

function m:OnDepoisonClick() end

function m:OnSurrenderClick() end

function m:OnCancelBoxSelection() end

function m:TryFocusOnCurrentSkill() end

function m:TryFocusOnRightAction() end

function m:InitTrans() end

BattleActionUIPanel = m
return m
