---@class CameraFilterPack_Drawing_Manga_Flash_Color : UnityEngine.MonoBehaviour
---@field public SCShader UnityEngine.Shader
---@field public Size number
---@field public Color UnityEngine.Color
---@field public Speed number
---@field public PosX number
---@field public PosY number
---@field public Intensity number
local m = {}

CameraFilterPack_Drawing_Manga_Flash_Color = m
return m
