---@class XLuaTest.PushAsTableStruct : System.ValueType
---@field public x number
---@field public y number
local m = {}

XLuaTest.PushAsTableStruct = m
return m
