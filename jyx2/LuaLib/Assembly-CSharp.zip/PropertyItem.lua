---@class PropertyItem : System.ValueType
---@field public ID number
---@field public Name string
---@field public PropertyName string
---@field public DefaulMax number
---@field public DefaulMin number
local m = {}

PropertyItem = m
return m
