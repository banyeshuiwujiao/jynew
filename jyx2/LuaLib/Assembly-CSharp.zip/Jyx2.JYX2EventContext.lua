---@class Jyx2.JYX2EventContext : System.Object
---@field public current Jyx2.JYX2EventContext @static
---@field public currentItemId number
local m = {}

Jyx2.JYX2EventContext = m
return m
