---@class Jyx2.RoleInstance : System.Object
---@field public Key number
---@field public Name string
---@field public Sex number
---@field public Level number
---@field public Exp number
---@field public Attack number
---@field public Qinggong number
---@field public Defence number
---@field public Heal number
---@field public UsePoison number
---@field public DePoison number
---@field public AntiPoison number
---@field public Quanzhang number
---@field public Yujian number
---@field public Shuadao number
---@field public Qimen number
---@field public Anqi number
---@field public Wuxuechangshi number
---@field public Pinde number
---@field public AttackPoison number
---@field public Zuoyouhubo number
---@field public Shengwang number
---@field public IQ number
---@field public HpInc number
---@field public ExpForItem number
---@field public Wugongs Jyx2.SkillInstance[]
---@field public Items Jyx2.CsRoleItem[]
---@field public Mp number
---@field public MaxMp number
---@field public MpType number
---@field public Hp number
---@field public MaxHp number
---@field public Hurt number
---@field public Poison number
---@field public Tili number
---@field public ExpForMakeItem number
---@field public Weapon number
---@field public Armor number
---@field public Xiulianwupin number
---@field public CurrentSkill number
---@field public ExpGot number
---@field public PreviousRoundHp number
---@field public BattleModel Jyx2.BattleFieldModel
---@field public team number
---@field public sp number
---@field public isAI boolean
---@field public movedStep number
---@field public isActed boolean
---@field public isWaiting boolean
---@field public Model Jyx2.ModelAsset
---@field public Data Jyx2.LRoleConfig
---@field public View BattleRole
---@field public Pos Jyx2.BattleBlockVector
---@field public IsPlayerRole boolean
local m = {}

function m:BindKey() end

function m:ResetForBattle() end

function m:Recover() end

---@return number
function m:GetJyx2RoleId() end

---@return string
function m:GetPic() end

---@return boolean
function m:CanLevelUp() end

---@return number
function m:GetLevelUpExp() end

function m:LevelUp() end

---@param attrName string
---@param delta number
---@return number
function m:AddAttr(attrName, delta) end

---@return Jyx2.LItemConfig
function m:GetWeapon() end

---@return Jyx2.LItemConfig
function m:GetArmor() end

---@return Jyx2.LItemConfig
function m:GetXiulianItem() end

---@param forceAttackSkill boolean
---@return Jyx2.SkillCastInstance[]
function m:GetSkillsList(forceAttackSkill) end

function m:ResetSkillCasts() end

function m:ResetItems() end

---@param itemId number
---@return boolean
function m:HaveItemBool(itemId) end

---@param itemId number
---@param count number
function m:AddItem(itemId, count) end

---@overload fun(item:Jyx2.LItemConfig):
---@param itemId number
---@return boolean
function m:CanUseItem(itemId) end

---@param practiseItem Jyx2.LItemConfig
---@return string
function m:LianZhiItem(practiseItem) end

---@param item Jyx2.LItemConfig
function m:UseItem(item) end

---@param item Jyx2.LItemConfig
function m:UnequipItem(item) end

---@return boolean
function m:CanFinishedItem() end

---@overload fun(item:Jyx2.LItemConfig):
---@return number
function m:GetFinishedExpForItem() end

---@param wugongId number
---@return number
function m:GetWugongLevel(wugongId) end

function m:UpdateViewPostion() end

function m:EnterBattle() end

---@param hp number
function m:SetHPAndRefreshHudBar(hp) end

---@overload fun(skill:Jyx2.SkillInstance)
---@param skill Jyx2.SkillInstance
---@param force boolean
function m:SwitchAnimationToSkill(skill, force) end

function m:LeaveBattle() end

function m:TimeRun() end

function m:IncSp() end

---@return number
function m:GetMoveAbility() end

---@virtual
---@param other Jyx2.RoleInstance
---@return number
function m:CompareTo(other) end

---@return boolean
function m:IsDead() end

function m:Resurrect() end

---@overload fun()
---@param duration number
function m:Stun(duration) end

function m:StopStun() end

---@return boolean
function m:IsStun() end

function m:OnRest() end

---@param magicId number
---@return number
function m:LearnMagic(magicId) end

---@return string
function m:GetMPColor() end

---@return string
function m:GetHPColor1() end

---@return string
function m:GetHPColor2() end

---@param propertyName string
---@return number
function m:GetWeaponProperty(propertyName) end

---@param propertyName string
---@return number
function m:GetArmorProperty(propertyName) end

---@param wugongId number
---@return number
function m:GetExtraAttack(wugongId) end

---@return Jyx2.RoleInstance
function m:Clone() end

---@overload fun(): @extension
---@extension
---@param tag string
---@return BattleRole
function m.CreateRoleView(tag) end

Jyx2.RoleInstance = m
return m
