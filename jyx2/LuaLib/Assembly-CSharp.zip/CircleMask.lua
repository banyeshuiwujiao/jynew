---@class CircleMask : TileWorld.TileWorldCreator
local m = {}

---@virtual
---@param _map boolean[]
---@param _creator TileWorld.TileWorldCreator
---@param _config TileWorld.TileWorldConfiguration
---@return boolean[]
function m:ApplyMask(_map, _creator, _config) end

CircleMask = m
return m
