---@class Jyx2.GameSaveSummary : System.ValueType
---@field public Summary string
---@field public ModId string
---@field public ModName string
local m = {}

---@return boolean
function m:IsEmpty() end

---@static
---@param index number
---@return Jyx2.GameSaveSummary
function m.Load(index) end

---@static
---@param index number
---@param summary Jyx2.GameSaveSummary
function m.Save(index, summary) end

---@return string
function m:GetBrief() end

---@static
---@param index number
---@return string
function m.GetSummaryFilePath(index) end

Jyx2.GameSaveSummary = m
return m
