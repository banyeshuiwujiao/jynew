---@class BattleboxManager : UnityEngine.MonoBehaviour
---@field public BATTLEBLOCK_DECAL_ALPHA number @static
---@field public m_DetechRadius number
---@field public m_blockTexMultiplier number
---@field public m_InvalidColor UnityEngine.Color
---@field public m_Dataset Jyx2.BattleboxDataset
local m = {}

function m:Init() end

---@param pos UnityEngine.Vector3
---@return boolean
function m:ColliderContain(pos) end

---@return boolean
function m:InitFromData() end

function m:SaveToData() end

---@return boolean
function m:CheckSize() end

function m:CreateDataset() end

---@return Jyx2.BattleBlockData[]
function m:GetBattleBlocks() end

---@param x number
---@param z number
---@return System.Numerics.Vector2
function m:GetXYIndex(x, z) end

---@param top UnityEngine.Vector3
---@param height number
---@return boolean, UnityEngine.Vector3, UnityEngine.Vector3
function m:JudgeCoord(top, height) end

function m:ShowAllValidBlocks() end

function m:ShowAllBlocks() end

function m:HideAllBlocks() end

function m:HideAllRangeBlocks() end

---@param xindex number
---@param yindex number
---@return Jyx2.BattleBlockData
function m:GetBlockData(xindex, yindex) end

---@param xindex number
---@param yindex number
---@return Jyx2.BattleBlockData
function m:GetRangelockData(xindex, yindex) end

---@param xindex number
---@param yindex number
---@return boolean
function m:Exist(xindex, yindex) end

---@param xindex number
---@param yindex number
---@return boolean
function m:IsValid(xindex, yindex) end

function m:ClearAllBlocks() end

---@param xindex number
---@param yindex number
function m:ChangeValid(xindex, yindex) end

---@overload fun()
---@param showAll boolean
function m:DrawAllBlocks(showAll) end

---@overload fun(center:UnityEngine.Vector3, range:number)
---@param center UnityEngine.Vector3
---@param range number
---@param show boolean
function m:DrawAreaBlocks(center, range, show) end

---@param center UnityEngine.Vector3
---@param range number
function m:ShowBlocksCenterDist(center, range) end

---@overload fun(color:UnityEngine.Color)
---@param color UnityEngine.Color
---@param isRangeBlocks boolean
function m:SetAllBlockColor(color, isRangeBlocks) end

---@param block Jyx2.BattleBlockData
function m:SetBlockInaccessible(block) end

---@param x number
---@param y number
---@param ox number
---@param oy number
---@param range number
function m:CreateBlockMap(x, y, ox, oy, range) end

---@param x number
---@param y number
---@param ox number
---@param oy number
---@param range number
function m:AddToBlockMap(x, y, ox, oy, range) end

---@param x number
---@param y number
---@return System.Collections.Generic.IEnumerable_1_Jyx2_BattleBlockVector_
function m:GetNearBlocks(x, y) end

BattleboxManager = m
return m
