---@class TipsType : System.Enum
---@field public Common TipsType @static
---@field public MiddleTop TipsType @static
---@field public value__ number
local m = {}

TipsType = m
return m
