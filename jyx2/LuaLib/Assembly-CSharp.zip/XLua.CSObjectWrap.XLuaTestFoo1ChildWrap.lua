---@class XLua.CSObjectWrap.XLuaTestFoo1ChildWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.XLuaTestFoo1ChildWrap = m
return m
