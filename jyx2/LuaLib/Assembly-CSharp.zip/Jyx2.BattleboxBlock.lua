---@class Jyx2.BattleboxBlock : System.Object
---@field public XIndex number
---@field public YIndex number
---@field public WorldPosX number
---@field public WorldPosY number
---@field public WorldPosZ number
---@field public NormalX number
---@field public NormalY number
---@field public NormalZ number
---@field public IsValid boolean
local m = {}

Jyx2.BattleboxBlock = m
return m
