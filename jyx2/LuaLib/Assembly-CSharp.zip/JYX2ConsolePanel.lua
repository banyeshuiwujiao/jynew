---@class JYX2ConsolePanel : UnityEngine.MonoBehaviour
---@field public inputField UnityEngine.UI.InputField
---@field public confirmButton UnityEngine.UI.Button
---@field public helpButton UnityEngine.UI.Button
---@field public cmdListButton UnityEngine.UI.Button
---@field public consoleButton UnityEngine.UI.Button
---@field public copyButton UnityEngine.UI.Button
---@field public reporterButton UnityEngine.UI.Button
local m = {}

JYX2ConsolePanel = m
return m
