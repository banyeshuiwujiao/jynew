---@class ChatType : System.Enum
---@field public None ChatType @static
---@field public RoleId ChatType @static
---@field public Selection ChatType @static
---@field public value__ number
local m = {}

ChatType = m
return m
