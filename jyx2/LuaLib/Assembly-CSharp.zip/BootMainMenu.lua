---@class BootMainMenu : UnityEngine.MonoBehaviour
local m = {}

BootMainMenu = m
return m
