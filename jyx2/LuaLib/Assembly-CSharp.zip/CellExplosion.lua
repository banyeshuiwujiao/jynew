---@class CellExplosion : UnityEngine.MonoBehaviour
---@field public minForce number
---@field public maxForce number
---@field public radious number
---@field public timer number
local m = {}

function m:Explode() end

---@param tr UnityEngine.Transform
---@return System.Collections.IEnumerator
function m:ChangeSize(tr) end

CellExplosion = m
return m
