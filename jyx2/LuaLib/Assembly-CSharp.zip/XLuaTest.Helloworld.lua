---@class XLuaTest.Helloworld : UnityEngine.MonoBehaviour
local m = {}

XLuaTest.Helloworld = m
return m
