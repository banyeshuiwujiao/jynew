---@class XLua.CSObjectWrap.Jyx2LuaMonoBehaviorWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.Jyx2LuaMonoBehaviorWrap = m
return m
