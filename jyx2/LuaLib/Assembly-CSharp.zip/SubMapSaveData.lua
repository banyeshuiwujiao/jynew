---@class SubMapSaveData : System.Object
---@field public MapId number
---@field public CurrentPos UnityEngine.Vector3
---@field public CurrentOri UnityEngine.Quaternion
local m = {}

SubMapSaveData = m
return m
