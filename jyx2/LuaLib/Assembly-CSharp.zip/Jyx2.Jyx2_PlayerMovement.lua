---@class Jyx2.Jyx2_PlayerMovement : UnityEngine.MonoBehaviour
---@field public IsRunning boolean
---@field public m_Animancer Animancer.AnimancerComponent
---@field public _Idle UnityEngine.AnimationClip
---@field public _Move UnityEngine.AnimationClip
---@field public IsLockingDirection boolean
---@field public IsNavAgentUpdateRotation boolean
---@field public IsNavAgentAvailable boolean
local m = {}

---@param ro number
function m:SetRotation(ro) end

---@param speed number
function m:SetManualMoveSpeed(speed) end

---@overload fun(h:number, v:number)
---@param input UnityEngine.Vector2
function m:UpdateMovement(input) end

function m:StopMovement() end

---@param target UnityEngine.Vector3
function m:MoveToDestination(target) end

---@param updateRotation boolean
function m:SetNavAgentUpdateRotation(updateRotation) end

Jyx2.Jyx2_PlayerMovement = m
return m
