---@class AudioManager : System.Object
local m = {}

---@overload fun(audioClip:UnityEngine.AudioClip) @static
---@static
---@param id number
function m.PlayMusic(id) end

---@static
function m.StopMusic() end

---@static
---@param path string
---@return Cysharp.Threading.Tasks.UniTask
function m.PlayMusicAtPath(path) end

---@static
---@return UnityEngine.AudioClip
function m.GetCurrentMusic() end

---@overload fun(path:string, position:UnityEngine.Vector3): @static
---@static
---@param clip UnityEngine.AudioClip
---@param position UnityEngine.Vector3
function m.PlayClipAtPoint(clip, position) end

AudioManager = m
return m
