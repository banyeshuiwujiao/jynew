---@class Jyx2_GameDifficulty : System.Enum
---@field public Simple Jyx2_GameDifficulty @static
---@field public Normal Jyx2_GameDifficulty @static
---@field public Hard Jyx2_GameDifficulty @static
---@field public value__ number
local m = {}

Jyx2_GameDifficulty = m
return m
