---@class CurrentBattleRolePanel : UnityEngine.MonoBehaviour
---@field public m_NameText UnityEngine.UI.Text
---@field public m_DetailText UnityEngine.UI.Text
---@field public m_Head UnityEngine.UI.Image
local m = {}

---@param role Jyx2.RoleInstance
function m:ShowRole(role) end

function m:Hide() end

CurrentBattleRolePanel = m
return m
