---@class Serialization_2_TKey_TValue_ : System.Object
local m = {}

---@return table<any, any>
function m:ToDictionary() end

---@virtual
function m:OnBeforeSerialize() end

---@virtual
function m:OnAfterDeserialize() end

Serialization_2_TKey_TValue_ = m
return m
