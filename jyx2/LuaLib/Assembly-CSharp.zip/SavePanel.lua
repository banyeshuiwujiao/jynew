---@class SavePanel : Jyx2_UIBase
---@field public Layer UILayer
local m = {}

function m:OnBackClick() end

function m:InitTrans() end

SavePanel = m
return m
