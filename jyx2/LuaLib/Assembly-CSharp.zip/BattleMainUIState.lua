---@class BattleMainUIState : System.Enum
---@field public None BattleMainUIState @static
---@field public ShowRole BattleMainUIState @static
---@field public ShowHUD BattleMainUIState @static
---@field public value__ number
local m = {}

BattleMainUIState = m
return m
