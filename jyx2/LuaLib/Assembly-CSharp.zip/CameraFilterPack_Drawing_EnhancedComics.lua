---@class CameraFilterPack_Drawing_EnhancedComics : UnityEngine.MonoBehaviour
---@field public SCShader UnityEngine.Shader
---@field public DotSize number
---@field public _ColorR number
---@field public _ColorG number
---@field public _ColorB number
---@field public _Blood number
---@field public _SmoothStart number
---@field public _SmoothEnd number
---@field public ColorRGB UnityEngine.Color
local m = {}

CameraFilterPack_Drawing_EnhancedComics = m
return m
