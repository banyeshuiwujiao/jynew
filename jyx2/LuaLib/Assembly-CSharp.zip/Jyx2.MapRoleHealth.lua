---@class Jyx2.MapRoleHealth : System.Enum
---@field public Normal Jyx2.MapRoleHealth @static
---@field public Stun Jyx2.MapRoleHealth @static
---@field public Death Jyx2.MapRoleHealth @static
---@field public value__ number
local m = {}

Jyx2.MapRoleHealth = m
return m
