---@class Jyx2.GameRuntimeData : System.Object
---@field public ARCHIVE_FILE_NAME string @static
---@field public Instance Jyx2.GameRuntimeData @static
---@field public RuntimeVersion number
---@field public AllRoles table<number, Jyx2.RoleInstance>
---@field public SubMapData SubMapSaveData
---@field public WorldData WorldMapSaveData
---@field public KeyValues System.Collections.Generic.Dictionary_2_System_String_System_String_
---@field public Items System.Collections.Generic.Dictionary_2_System_String_System_ValueTuple_2_System_Int32_System_Int32__
---@field public ItemUser System.Collections.Generic.Dictionary_2_System_String_System_Int32_
---@field public ShopItems System.Collections.Generic.Dictionary_2_System_String_System_Int32_
---@field public EventCounter System.Collections.Generic.Dictionary_2_System_String_System_Int32_
---@field public MapPic System.Collections.Generic.Dictionary_2_System_String_System_Int32_
---@field public Player Jyx2.RoleInstance
---@field public startDate System.DateTime
local m = {}

---@static
---@return Jyx2.GameRuntimeData
function m.CreateNew() end

---@static
---@param index number
---@return string
function m.GetArchiveFile(index) end

---@overload fun()
---@param index number
function m:GameSave(index) end

---@static
---@param index number
---@return System.Nullable_1_System_DateTime_
function m.GetSaveDate(index) end

---@static
---@param fileIndex number
---@return Jyx2.GameRuntimeData
function m.LoadArchive(fileIndex) end

---@return number[]
function m:GetTeamId() end

---@return System.Collections.Generic.IEnumerable_1_Jyx2_RoleInstance_
function m:GetTeam() end

---@return number
function m:GetTeamMembersCount() end

---@overload fun(roleId:number):
---@param roleId number
---@param showGetItem boolean
---@return boolean
function m:JoinRoleToTeam(roleId, showGetItem) end

---@param roleId number
---@return boolean
function m:LeaveTeam(roleId) end

---@param roleId number
---@return Jyx2.RoleInstance
function m:GetRoleInTeam(roleId) end

---@param roleId number
---@return boolean
function m:IsRoleInTeam(roleId) end

---@param roleId number
---@return Jyx2.RoleInstance
function m:GetRole(roleId) end

---@param k string
---@return string
function m:GetKeyValues(k) end

---@param k string
---@param v string
function m:SetKeyValues(k, v) end

---@param k string
function m:RemoveKey(k) end

---@param key string
---@return boolean
function m:KeyExist(key) end

---@return number
function m:GetMoney() end

---@param itemId number
---@return boolean
function m:HaveItemBool(itemId) end

---@overload fun(id:number, count:number)
---@param id string
---@param count number
function m:AddItem(id, count) end

---@param id number
---@return number
function m:GetItemCount(id) end

---@param roleId number
---@param itemId number
---@param count number
function m:RoleGetItem(roleId, itemId, count) end

---@param itemId number
---@param roleId number
function m:SetItemUser(itemId, roleId) end

---@param id number
---@return number
function m:GetItemUser(id) end

---@param scene number
---@param eventId number
---@param interactiveEventId number
---@param useItemEventId number
---@param enterEventId number
function m:ModifyEvent(scene, eventId, interactiveEventId, useItemEventId, enterEventId) end

---@param scene number
---@param eventId string
---@return string
function m:GetModifiedEvent(scene, eventId) end

---@param scene number
---@param eventId number
---@param eventName number
---@param num number
function m:AddEventCount(scene, eventId, eventName, num) end

---@param scene number
---@param eventId number
---@param eventName number
---@return number
function m:GetEventCount(scene, eventId, eventName) end

---@param scene number
---@param eventId number
---@param pic number
function m:SetMapPic(scene, eventId, pic) end

---@param scene number
---@param eventId number
---@return number
function m:GetMapPic(scene, eventId) end

---@param scene string
---@return System.Collections.Generic.Dictionary_2_System_String_System_String_
function m:GetSceneInfo(scene) end

---@param scene string
---@param info System.Collections.Generic.Dictionary_2_System_String_System_String_
function m:SetSceneInfo(scene, info) end

---@param mapId number
---@return number
function m:GetSceneEntranceCondition(mapId) end

---@param mapId number
---@param value number
function m:SetSceneEntraceCondition(mapId, value) end

Jyx2.GameRuntimeData = m
return m
