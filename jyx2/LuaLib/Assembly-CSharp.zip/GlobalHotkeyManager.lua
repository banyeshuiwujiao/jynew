---@class GlobalHotkeyManager : UnityEngine.MonoBehaviour
---@field public Instance GlobalHotkeyManager @static
---@field public isLock boolean
local m = {}

---@param mono UnityEngine.MonoBehaviour
---@param key UnityEngine.KeyCode
---@param callback fun()
---@return boolean
function m:RegistHotkey(mono, key, callback) end

---@param mono UnityEngine.MonoBehaviour
---@param key UnityEngine.KeyCode
function m:UnRegistHotkey(mono, key) end

GlobalHotkeyManager = m
return m
