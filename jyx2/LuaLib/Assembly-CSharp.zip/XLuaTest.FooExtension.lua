---@class XLuaTest.FooExtension : System.Object
local m = {}

---@static
---@param a XLuaTest.Foo1Parent
function m.PlainExtension(a) end

---@static
---@param a XLuaTest.Foo1Parent
---@return XLuaTest.Foo1Parent
function m.Extension1(a) end

---@overload fun(a:XLuaTest.Foo1Parent, b:XLuaTest.Foo2Parent) @static
---@static
---@param a XLuaTest.Foo1Parent
---@param b UnityEngine.GameObject
---@return XLuaTest.Foo1Parent
function m.Extension2(a, b) end

---@static
---@param obj UnityEngine.GameObject
---@return UnityEngine.Component
function m.UnsupportedExtension(obj) end

XLuaTest.FooExtension = m
return m
