---@class InputManager : System.Object
---@field public Instance InputManager @static
local m = {}

---@return Jyx2.BattleBlockData
function m:GetMouseUpBattleBlock() end

---@return Jyx2.BattleBlockData
function m:GetMouseOverBattleBlock() end

---@return Jyx2.BattleBlockData
function m:GetMouseDownBattleBlock() end

InputManager = m
return m
