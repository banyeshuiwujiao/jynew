---@class CameraFilterPack_Distortion_Dream : UnityEngine.MonoBehaviour
---@field public SCShader UnityEngine.Shader
---@field public Distortion number
local m = {}

CameraFilterPack_Distortion_Dream = m
return m
