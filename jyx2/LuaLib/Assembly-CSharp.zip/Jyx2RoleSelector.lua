---@class Jyx2RoleSelector : UnityEngine.MonoBehaviour
---@field public info UnityEngine.UI.Text
---@field public confirmButton UnityEngine.UI.Button
---@field public cancelButton UnityEngine.UI.Button
---@field public m_Container UnityEngine.Transform
local m = {}

---@static
---@param roles System.Collections.Generic.IEnumerable_1_Jyx2_RoleInstance_
---@param mustRoles fun(arg:Jyx2.RoleInstance):
---@param callback fun(obj:Jyx2.RoleInstance[])
---@return Jyx2RoleSelector
function m.Create(roles, mustRoles, callback) end

---@param roles System.Collections.Generic.IEnumerable_1_Jyx2_RoleInstance_
---@param mustRoles fun(arg:Jyx2.RoleInstance):
---@param callback fun(obj:Jyx2.RoleInstance[])
function m:Show(roles, mustRoles, callback) end

Jyx2RoleSelector = m
return m
