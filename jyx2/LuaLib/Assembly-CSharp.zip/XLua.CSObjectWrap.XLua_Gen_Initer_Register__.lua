---@class XLua.CSObjectWrap.XLua_Gen_Initer_Register__ : System.Object
local m = {}

XLua.CSObjectWrap.XLua_Gen_Initer_Register__ = m
return m
