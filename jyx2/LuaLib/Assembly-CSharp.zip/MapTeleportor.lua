---@class MapTeleportor : UnityEngine.MonoBehaviour
---@field public TransportTriggerName string
---@field public ExtraCommand string
---@field public ButtonText string
---@field public m_EventTargets UnityEngine.GameObject[]
local m = {}

function m:DoTransport() end

MapTeleportor = m
return m
