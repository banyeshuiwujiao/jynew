---@class Jyx2.Jyx2AnimationBattleRole : UnityEngine.MonoBehaviour
---@field public CurDisplay Jyx2SkillDisplayAsset
local m = {}

---@abstract
---@return UnityEngine.Animator
function m:GetAnimator() end

---@return Animancer.HybridAnimancerComponent
function m:GetAnimancer() end

---@virtual
function m:Idle() end

---@virtual
function m:DeadOrIdle() end

---@virtual
function m:BeHit() end

---@virtual
function m:Attack() end

---@virtual
function m:Run() end

---@virtual
function m:ShowDamage() end

---@virtual
function m:MarkHpBarIsDirty() end

---@virtual
function m:UnmarkHpBarIsDirty() end

---@overload fun(clip:UnityEngine.AnimationClip):
---@param clip UnityEngine.AnimationClip
---@param fadeDuration number
---@return Cysharp.Threading.Tasks.UniTask
function m:PlayAnimationAsync(clip, fadeDuration) end

---@overload fun(clip:UnityEngine.AnimationClip, callback:fun())
---@overload fun(clip:UnityEngine.AnimationClip)
---@param clip UnityEngine.AnimationClip
---@param callback fun()
---@param fadeDuration number
function m:PlayAnimation(clip, callback, fadeDuration) end

Jyx2.Jyx2AnimationBattleRole = m
return m
