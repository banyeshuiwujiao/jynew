---@class Tutorial.CSCallLua : UnityEngine.MonoBehaviour
local m = {}

Tutorial.CSCallLua = m
return m
