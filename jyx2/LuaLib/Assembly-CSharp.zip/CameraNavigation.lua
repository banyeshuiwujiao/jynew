---@class CameraNavigation : UnityEngine.MonoBehaviour
---@field public target UnityEngine.GameObject
---@field public mouseSensitivity number
---@field public maxDistance number
---@field public scrollSpeed number
---@field public defaultScroll number
---@field public minScroll number
---@field public maxScroll number
local m = {}

CameraNavigation = m
return m
