---@class MirrorReflection : UnityEngine.MonoBehaviour
---@field public m_DisablePixelLights boolean
---@field public m_TextureSize number
---@field public m_ClipPlaneOffset number
---@field public m_ReflectLayers UnityEngine.LayerMask
---@field public refTexName string
local m = {}

function m:OnWillRenderObject() end

MirrorReflection = m
return m
