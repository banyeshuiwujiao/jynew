---@class DoNotDestroy : UnityEngine.MonoBehaviour
local m = {}

DoNotDestroy = m
return m
