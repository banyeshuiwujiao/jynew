---@class CFX_Demo_RandomDir : UnityEngine.MonoBehaviour
---@field public min UnityEngine.Vector3
---@field public max UnityEngine.Vector3
local m = {}

CFX_Demo_RandomDir = m
return m
