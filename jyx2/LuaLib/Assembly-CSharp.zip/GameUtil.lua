---@class GameUtil : System.Object
local m = {}

---@static
---@param roles System.Collections.Generic.IEnumerable_1_Jyx2_RoleInstance_
---@param callback fun(obj:Jyx2.RoleInstance)
---@return Cysharp.Threading.Tasks.UniTask
function m.SelectRole(roles, callback) end

---@overload fun(msg:string) @static
---@static
---@param msg string
---@param duration number
function m.DisplayPopinfo(msg, duration) end

---@overload fun(content:string, title:string) @static
---@overload fun(content:string) @static
---@static
---@param content string
---@param title string
---@param cb fun()
function m.ShowFullSuggest(content, title, cb) end

---@static
---@param pause boolean
function m.GamePause(pause) end

---@static
---@param go UnityEngine.GameObject
---@param isActive boolean
function m.BetterSetActive(go, isActive) end

---@overload fun(trans:UnityEngine.Transform): @static
---@overload fun(go:UnityEngine.GameObject): @static
---@static
---@param trans UnityEngine.Transform
---@param type string
---@return UnityEngine.Component
function m.GetOrAddComponent(trans, type) end

---@static
---@param str string
function m.LogError(str) end

---@overload fun(time:number, action:fun()) @static
---@static
---@param time number
---@param action fun()
---@param attachedComponent UnityEngine.Component
function m.CallWithDelay(time, action, attachedComponent) end

---@static
---@param role Jyx2.RoleInstance
---@param action fun()
---@return Cysharp.Threading.Tasks.UniTask
function m.ShowYesOrNoCastrate(role, action) end

---@static
---@param item Jyx2.LItemConfig
---@param action fun()
---@return Cysharp.Threading.Tasks.UniTask
function m.ShowYesOrNoUseItem(item, action) end

GameUtil = m
return m
