---@class Jyx2.ISkillCastTarget : table
---@field public gameObject UnityEngine.GameObject
local m = {}

---@abstract
---@return UnityEngine.Animator
function m:GetAnimator() end

---@abstract
---@return Animancer.HybridAnimancerComponent
function m:GetAnimancer() end

---@abstract
function m:Idle() end

---@abstract
function m:BeHit() end

---@abstract
function m:ShowDamage() end

Jyx2.ISkillCastTarget = m
return m
