---@class CustomHeaderAttribute : UnityEngine.HeaderAttribute
---@field public TypeId any
local m = {}

---@virtual
---@param obj any
---@return boolean
function m:Equals(obj) end

---@virtual
---@return number
function m:GetHashCode() end

---@virtual
---@return boolean
function m:IsDefaultAttribute() end

---@virtual
---@param obj any
---@return boolean
function m:Match(obj) end

---@virtual
---@return string
function m:ToString() end

CustomHeaderAttribute = m
return m
