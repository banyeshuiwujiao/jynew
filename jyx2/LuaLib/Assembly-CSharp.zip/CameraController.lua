---@class CameraController : UnityEngine.MonoBehaviour
---@field public Holder UnityEngine.Transform
---@field public cameraPos UnityEngine.Vector3
---@field public currDistance number
---@field public xRotate number
---@field public yRotate number
---@field public yMinLimit number
---@field public yMaxLimit number
---@field public prevDistance number
---@field public collidingLayers UnityEngine.LayerMask
local m = {}

CameraController = m
return m
