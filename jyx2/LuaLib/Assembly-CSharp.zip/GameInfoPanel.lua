---@class GameInfoPanel : Jyx2_UIBase
---@field public Layer UILayer
---@field public AlwaysDisplay boolean
local m = {}

function m:InitTrans() end

GameInfoPanel = m
return m
