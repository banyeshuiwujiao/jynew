---@class GraphicSetting : UnityEngine.MonoBehaviour
---@field public GlobalSetting GraphicSetting @static
---@field public HasFog number
---@field public HasPost number
---@field public HasWaterNormal number
---@field public HasAntiAliasing number
---@field public Vsync number
---@field public ShadowQuality UnityEngine.ShadowQuality
---@field public MaxFps MaxFpsEnum
---@field public QualityLevel QualityLevelEnum
---@field public ShaderLodLevel ShaderLodLevelEnum
---@field public ShadowShowLevel ShadowShowLevelEnum
local m = {}

function m:Save() end

function m:Load() end

function m:Execute() end

function m:ExecuteShadowShowLevel() end

function m:ExecuteWaterNormal() end

function m:ExecuteAntiAliasing() end

GraphicSetting = m
return m
