---@class ColorStringDefine : System.Object
---@field public Red string @static
---@field public Yellow string @static
---@field public Default string @static
---@field public Mp_type1 string @static
---@field public Mp_type0 string @static
---@field public Hp_posion string @static
---@field public Hp_hurt_light string @static
---@field public Hp_hurt_heavy string @static
---@field public main_menu_selected UnityEngine.Color @static
---@field public main_menu_normal UnityEngine.Color @static
---@field public save_selected UnityEngine.Color @static
---@field public save_normal UnityEngine.Color @static
---@field public system_item_selected UnityEngine.Color @static
---@field public system_item_normal UnityEngine.Color @static
local m = {}

ColorStringDefine = m
return m
