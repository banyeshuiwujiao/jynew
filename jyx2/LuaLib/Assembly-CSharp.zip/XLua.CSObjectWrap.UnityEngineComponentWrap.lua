---@class XLua.CSObjectWrap.UnityEngineComponentWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.UnityEngineComponentWrap = m
return m
