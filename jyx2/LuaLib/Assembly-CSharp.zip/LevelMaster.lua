---@class LevelMaster : UnityEngine.MonoBehaviour
---@field public loadPara LevelMaster.LevelLoadPara @static
---@field public LastGameMap Jyx2.LMapConfig @static
---@field public IsInBattle boolean @static
---@field public Instance LevelMaster @static
---@field public IsInWorldMap boolean @static
---@field public MobileSimulate boolean
---@field public m_MobileRotateSlider UnityEngine.GameObject
---@field public HUDRoot bl_HUDText
---@field public m_TouchPad ETCTouchPad
---@field public m_Joystick ETCJoystick
---@field public IsInited boolean
---@field public BlackCover UnityEngine.UI.Image
---@field public IsFadingScene boolean
local m = {}

---@static
---@param map Jyx2.LMapConfig
function m.SetCurrentMap(map) end

---@return boolean
function m:IsMobilePlatform() end

---@static
---@return Jyx2.LMapConfig
function m.GetCurrentGameMap() end

function m:UpdateCameraParams() end

---@param musicPath string
function m:PlayMusicAtPath(musicPath) end

function m:UpdateMobileControllerUI() end

---@return Cysharp.Threading.Tasks.UniTask
function m:TryBindPlayer() end

---@param isOn boolean
function m:SwitchToBattleUI(isOn) end

---@static
---@param position UnityEngine.Vector3
---@param center UnityEngine.Vector3
---@param axis UnityEngine.Vector3
---@param angle number
---@return UnityEngine.Vector3
function m.RotateRound(position, center, axis, angle) end

---@overload fun(position:UnityEngine.Vector3)
---@param transportName string
function m:Transport(transportName) end

---@param path string
---@param name string
---@param target string
function m:TransportToTransform(path, name, target) end

---@overload fun()
---@param index number
function m:OnManuelSave(index) end

---@return UnityEngine.Vector3
function m:GetPlayerPosition() end

---@return UnityEngine.Quaternion
function m:GetPlayerOrientation() end

---@return Jyx2Player
function m:GetPlayer() end

function m:RefreshGameEvents() end

LevelMaster = m
return m
