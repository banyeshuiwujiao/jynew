---@class RPGRotator : UnityEngine.MonoBehaviour
---@field public x number
---@field public y number
---@field public z number
local m = {}

RPGRotator = m
return m
