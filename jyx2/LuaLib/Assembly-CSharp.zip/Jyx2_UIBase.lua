---@class Jyx2_UIBase : UnityEngine.MonoBehaviour
---@field public Layer UILayer
---@field public IsOnly boolean
---@field public IsBlockControl boolean
---@field public AlwaysDisplay boolean
local m = {}

function m:Init() end

---@overload fun()
---@param ... any|any[]
function m:Show(...) end

function m:Hide() end

---@overload fun(button:UnityEngine.UI.Button, callback:fun()) @virtual
---@virtual
---@param button UnityEngine.UI.Button
---@param callback fun()
---@param supportGamepadButtonsNav boolean
function m:BindListener(button, callback, supportGamepadButtonsNav) end

---@virtual
function m:Update() end

Jyx2_UIBase = m
return m
