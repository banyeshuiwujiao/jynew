---@class AutoDestroyPS : UnityEngine.MonoBehaviour
local m = {}

AutoDestroyPS = m
return m
