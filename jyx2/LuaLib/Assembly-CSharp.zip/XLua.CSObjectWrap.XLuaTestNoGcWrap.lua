---@class XLua.CSObjectWrap.XLuaTestNoGcWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.XLuaTestNoGcWrap = m
return m
