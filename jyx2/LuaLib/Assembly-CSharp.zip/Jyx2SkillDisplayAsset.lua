---@class Jyx2SkillDisplayAsset : UnityEngine.ScriptableObject
---@field public All Jyx2SkillDisplayAsset[] @static
---@field public weaponCode Jyx2.ModelAsset.WeaponPartType
---@field public behitClip UnityEngine.AnimationClip
---@field public moveClip UnityEngine.AnimationClip
---@field public idleClip UnityEngine.AnimationClip
---@field public attackClip UnityEngine.AnimationClip
---@field public stunClip UnityEngine.AnimationClip
---@field public animationDelay number
---@field public duration number
---@field public behitDelay number
---@field public partilePrefab UnityEngine.GameObject
---@field public particleDelay number
---@field public partileOffset UnityEngine.Vector3
---@field public particleScale number
---@field public blockPartilePrefab UnityEngine.GameObject
---@field public blockParticleDelay number
---@field public blockPartileOffset UnityEngine.Vector3
---@field public blockParticleScale number
---@field public blockPartilePrefabAdd UnityEngine.GameObject
---@field public blockParticleDelayAdd number
---@field public bloackParticleAddDuration number
---@field public blockPartileOffsetAdd UnityEngine.Vector3
---@field public blockParticleScaleAdd number
---@field public audio UnityEngine.AudioClip
---@field public audioDelay number
---@field public audio2 UnityEngine.AudioClip
---@field public audioDelay2 number
---@field public controller UnityEngine.RuntimeAnimatorController
---@field public isGhostShadowOn boolean
---@field public ghostShadowColor UnityEngine.Color
local m = {}

---@static
---@param skillName string
---@return Jyx2SkillDisplayAsset
function m.Get(skillName) end

---@return UnityEngine.RuntimeAnimatorController
function m:GetAnimationController() end

---@param type Jyx2SkillDisplayAsset.Jyx2RoleAnimationType
---@return UnityEngine.AnimationClip
function m:LoadAnimation(type) end

Jyx2SkillDisplayAsset = m
return m
