---@class QuickOutline : UnityEngine.MonoBehaviour
---@field public OutlineMode QuickOutline.Mode
---@field public OutlineColor UnityEngine.Color
---@field public OutlineWidth number
local m = {}

QuickOutline = m
return m
