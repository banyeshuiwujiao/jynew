---@class Jyx2.BattleBlockData : System.Object
---@field public BattlePos Jyx2.BattleBlockVector
---@field public WorldPos UnityEngine.Vector3
---@field public gameObject UnityEngine.GameObject
---@field public BoxBlock Jyx2.BattleboxBlock
---@field public IsActive boolean
---@field public Inaccessible boolean
local m = {}

function m:Show() end

function m:Hide() end

Jyx2.BattleBlockData = m
return m
