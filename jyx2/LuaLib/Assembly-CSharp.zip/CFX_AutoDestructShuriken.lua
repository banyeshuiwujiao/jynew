---@class CFX_AutoDestructShuriken : UnityEngine.MonoBehaviour
---@field public OnlyDeactivate boolean
local m = {}

CFX_AutoDestructShuriken = m
return m
