---@class bl_Guidance : System.Enum
---@field public Up bl_Guidance @static
---@field public Down bl_Guidance @static
---@field public Left bl_Guidance @static
---@field public Right bl_Guidance @static
---@field public LeftUp bl_Guidance @static
---@field public RightUp bl_Guidance @static
---@field public LeftDown bl_Guidance @static
---@field public RightDown bl_Guidance @static
---@field public value__ number
local m = {}

bl_Guidance = m
return m
