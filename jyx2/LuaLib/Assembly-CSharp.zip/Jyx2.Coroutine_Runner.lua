---@class Jyx2.Coroutine_Runner : UnityEngine.MonoBehaviour
local m = {}

Jyx2.Coroutine_Runner = m
return m
