---@class bl_HUDText : UnityEngine.MonoBehaviour
---@field public CanvasParent UnityEngine.Transform
---@field public m_Type bl_HUDText.GameType
---@field public TextPrefab UnityEngine.GameObject
---@field public FadeSpeed number
---@field public FadeCurve UnityEngine.AnimationCurve
---@field public m_TextAnimationType bl_HUDText.TextAnimationType
---@field public FloatingSpeed number
---@field public HideDistance number
---@field public FactorMultiplier number
---@field public DelayStay number
---@field public CanReuse boolean
---@field public MaxUses number
---@field public MaxViewAngle number
---@field public DestroyTextOnDeath boolean
local m = {}

---@overload fun(text:string, trans:UnityEngine.Transform, color:UnityEngine.Color)
---@overload fun(text:string, trans:UnityEngine.Transform, place:bl_Guidance)
---@overload fun(text:string, trans:UnityEngine.Transform, color:UnityEngine.Color, size:number, speed:number, yAcceleration:number, yAccelerationScaleFactor:number, movement:bl_Guidance)
---@overload fun(info:HUDTextInfo)
---@param text string
---@param trans UnityEngine.Transform
function m:NewText(text, trans) end

bl_HUDText = m
return m
