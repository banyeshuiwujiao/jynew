---@class MainUIPanel : Jyx2_UIBase
---@field public Layer UILayer
local m = {}

---@virtual
function m:Update() end

---@param flag boolean
function m:ShowCompass(flag) end

function m:OnXiakeBtnClick() end

function m:OnBagBtnClick() end

function m:OnSystemBtnClick() end

function m:InitTrans() end

MainUIPanel = m
return m
