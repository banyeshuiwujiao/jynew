---@class Jyx2.BattleboxDataset : System.Object
---@field public BlockLength number @static
---@field public RowXDiff number @static
---@field public BlockLengthY number @static
---@field public SceneName string
---@field public BattleboxName string
---@field public MinX number
---@field public MinY number
---@field public BoxLength number
---@field public BoxWidth number
---@field public CountX number
---@field public CountY number
---@field public Blocks Jyx2.BattleboxBlock[]
local m = {}

---@param xindex number
---@param yindex number
---@return Jyx2.BattleboxBlock
function m:GetBLock(xindex, yindex) end

---@return Jyx2.BattleboxBlock[]
function m:GetVaildBLock() end

---@param xindex number
---@param yindex number
---@return boolean
function m:Exist(xindex, yindex) end

---@param xindex number
---@param yindex number
---@return boolean
function m:IsValid(xindex, yindex) end

---@param xindex number
---@param yindex number
---@param isValid boolean
function m:SetValid(xindex, yindex, isValid) end

---@return number
function m:GetValidCount() end

---@return number
function m:GetCount() end

---@return number
function m:GetSizeCount() end

---@param xindex number
---@param yindex number
---@return System.Numerics.Vector2
function m:CalcPos(xindex, yindex) end

---@param x number
---@param z number
---@return System.Numerics.Vector2
function m:GetXYIndex(x, z) end

Jyx2.BattleboxDataset = m
return m
