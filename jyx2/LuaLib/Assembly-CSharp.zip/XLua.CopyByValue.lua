---@class XLua.CopyByValue : System.Object
local m = {}

---@overload fun(buff:System.IntPtr, offset:number):(, UnityEngine.Vector2) @static
---@overload fun(translator:XLua.ObjectTranslator, L:System.IntPtr, idx:number): @static
---@overload fun(buff:System.IntPtr, offset:number):(, UnityEngine.Vector3) @static
---@overload fun(translator:XLua.ObjectTranslator, L:System.IntPtr, idx:number): @static
---@overload fun(buff:System.IntPtr, offset:number):(, UnityEngine.Vector4) @static
---@overload fun(translator:XLua.ObjectTranslator, L:System.IntPtr, idx:number): @static
---@overload fun(buff:System.IntPtr, offset:number):(, UnityEngine.Color) @static
---@overload fun(translator:XLua.ObjectTranslator, L:System.IntPtr, idx:number): @static
---@overload fun(buff:System.IntPtr, offset:number):(, UnityEngine.Quaternion) @static
---@overload fun(translator:XLua.ObjectTranslator, L:System.IntPtr, idx:number): @static
---@overload fun(buff:System.IntPtr, offset:number):(, UnityEngine.Ray) @static
---@overload fun(translator:XLua.ObjectTranslator, L:System.IntPtr, idx:number): @static
---@overload fun(buff:System.IntPtr, offset:number):(, UnityEngine.Bounds) @static
---@overload fun(translator:XLua.ObjectTranslator, L:System.IntPtr, idx:number): @static
---@overload fun(buff:System.IntPtr, offset:number):(, UnityEngine.Ray2D) @static
---@overload fun(translator:XLua.ObjectTranslator, L:System.IntPtr, idx:number): @static
---@overload fun(buff:System.IntPtr, offset:number):(, XLuaTest.Pedding) @static
---@overload fun(translator:XLua.ObjectTranslator, L:System.IntPtr, idx:number): @static
---@overload fun(buff:System.IntPtr, offset:number):(, XLuaTest.MyStruct) @static
---@overload fun(translator:XLua.ObjectTranslator, L:System.IntPtr, idx:number): @static
---@overload fun(buff:System.IntPtr, offset:number):(, XLuaTest.PushAsTableStruct) @static
---@overload fun(buff:System.IntPtr, offset:number):(, System.Byte) @static
---@overload fun(buff:System.IntPtr, offset:number):(, System.SByte) @static
---@overload fun(buff:System.IntPtr, offset:number):(, System.Int16) @static
---@overload fun(buff:System.IntPtr, offset:number):(, System.UInt16) @static
---@overload fun(buff:System.IntPtr, offset:number):(, System.Int32) @static
---@overload fun(buff:System.IntPtr, offset:number):(, System.UInt32) @static
---@overload fun(buff:System.IntPtr, offset:number):(, System.Int64) @static
---@overload fun(buff:System.IntPtr, offset:number):(, System.UInt64) @static
---@overload fun(buff:System.IntPtr, offset:number):(, System.Single) @static
---@overload fun(buff:System.IntPtr, offset:number):(, System.Double) @static
---@overload fun(buff:System.IntPtr, offset:number):(, System.Decimal) @static
---@static
---@param translator XLua.ObjectTranslator
---@param L System.IntPtr
---@param idx number
---@return UnityEngine.Vector2
function m.UnPack(translator, L, idx) end

---@overload fun(buff:System.IntPtr, offset:number, field:UnityEngine.Vector3): @static
---@overload fun(buff:System.IntPtr, offset:number, field:UnityEngine.Vector4): @static
---@overload fun(buff:System.IntPtr, offset:number, field:UnityEngine.Color): @static
---@overload fun(buff:System.IntPtr, offset:number, field:UnityEngine.Quaternion): @static
---@overload fun(buff:System.IntPtr, offset:number, field:UnityEngine.Ray): @static
---@overload fun(buff:System.IntPtr, offset:number, field:UnityEngine.Bounds): @static
---@overload fun(buff:System.IntPtr, offset:number, field:UnityEngine.Ray2D): @static
---@overload fun(buff:System.IntPtr, offset:number, field:XLuaTest.Pedding): @static
---@overload fun(buff:System.IntPtr, offset:number, field:XLuaTest.MyStruct): @static
---@overload fun(buff:System.IntPtr, offset:number, field:XLuaTest.PushAsTableStruct): @static
---@overload fun(buff:System.IntPtr, offset:number, field:number): @static
---@overload fun(buff:System.IntPtr, offset:number, field:number): @static
---@overload fun(buff:System.IntPtr, offset:number, field:number): @static
---@overload fun(buff:System.IntPtr, offset:number, field:number): @static
---@overload fun(buff:System.IntPtr, offset:number, field:number): @static
---@overload fun(buff:System.IntPtr, offset:number, field:number): @static
---@overload fun(buff:System.IntPtr, offset:number, field:number): @static
---@overload fun(buff:System.IntPtr, offset:number, field:number): @static
---@overload fun(buff:System.IntPtr, offset:number, field:number): @static
---@overload fun(buff:System.IntPtr, offset:number, field:number): @static
---@overload fun(buff:System.IntPtr, offset:number, field:System.Decimal): @static
---@static
---@param buff System.IntPtr
---@param offset number
---@param field UnityEngine.Vector2
---@return boolean
function m.Pack(buff, offset, field) end

---@static
---@param type System.Type
---@return boolean
function m.IsStruct(type) end

XLua.CopyByValue = m
return m
