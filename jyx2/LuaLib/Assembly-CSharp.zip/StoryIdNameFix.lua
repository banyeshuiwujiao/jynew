---@class StoryIdNameFix : System.Object
---@field public Id number
---@field public Name string
local m = {}

StoryIdNameFix = m
return m
