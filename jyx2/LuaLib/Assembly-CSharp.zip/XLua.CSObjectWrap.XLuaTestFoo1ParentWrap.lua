---@class XLua.CSObjectWrap.XLuaTestFoo1ParentWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.XLuaTestFoo1ParentWrap = m
return m
