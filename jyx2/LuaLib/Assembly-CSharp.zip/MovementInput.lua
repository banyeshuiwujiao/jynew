---@class MovementInput : UnityEngine.MonoBehaviour
---@field public velocity number
---@field public InputX number
---@field public InputZ number
---@field public desiredMoveDirection UnityEngine.Vector3
---@field public blockRotationPlayer boolean
---@field public desiredRotationSpeed number
---@field public anim UnityEngine.Animator
---@field public Speed number
---@field public allowPlayerRotation number
---@field public cam UnityEngine.Camera
---@field public controller UnityEngine.CharacterController
---@field public isGrounded boolean
---@field public HorizontalAnimSmoothTime number
---@field public VerticalAnimTime number
---@field public StartAnimTime number
---@field public StopAnimTime number
---@field public canMove boolean
---@field public TargetMarker UnityEngine.GameObject
---@field public TargetMarker2 UnityEngine.GameObject
---@field public Prefabs UnityEngine.GameObject[]
---@field public PrefabsCast UnityEngine.GameObject[]
---@field public UltimatePrefab UnityEngine.GameObject[]
---@field public castingTime number[]
---@field public collidingLayer UnityEngine.LayerMask
---@field public ultIcons UnityEngine.GameObject[]
---@field public aim UnityEngine.UI.Image
---@field public uiOffset UnityEngine.Vector2
---@field public screenTargets UnityEngine.Transform[]
---@field public FirePoint UnityEngine.Transform
---@field public fireRate number
---@field public cameraShaker CameraShaker
local m = {}

---@param EffectNumber number
---@return System.Collections.IEnumerator
function m:FastPlay(EffectNumber) end

---@param EffectNumber number
---@param enableTime number
---@param dissableTime number
---@param pivotPosition UnityEngine.Vector3
---@param pivotRotation UnityEngine.Quaternion
---@param ChangePos boolean
---@return System.Collections.IEnumerator
function m:Ult(EffectNumber, enableTime, dissableTime, pivotPosition, pivotRotation, ChangePos) end

function m:MainSoundPlay() end

function m:CastSoundPlay() end

---@param rotatingTime number
---@param targetPoint UnityEngine.Vector3
---@return System.Collections.IEnumerator
function m:RotateToTarget(rotatingTime, targetPoint) end

---@param EffectNumber number
---@return System.Collections.IEnumerator
function m:FrontAttack(EffectNumber) end

---@param EffectNumber number
---@return System.Collections.IEnumerator
function m:PreCast(EffectNumber) end

---@param EffectNumber number
---@return System.Collections.IEnumerator
function m:Attack(EffectNumber) end

---@param EffectNumber number
function m:StopCasting(EffectNumber) end

---@return number
function m:targetIndex() end

MovementInput = m
return m
