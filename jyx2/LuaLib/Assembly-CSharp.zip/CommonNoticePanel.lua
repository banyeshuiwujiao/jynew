---@class CommonNoticePanel : Jyx2_UIBase
---@field public Content string
local m = {}

---@overload fun(title:string, content:string, OnBtn1Action:fun(), OnBtn2Action:fun(), btn1Text:string)
---@overload fun(title:string, content:string, OnBtn1Action:fun(), OnBtn2Action:fun())
---@overload fun(title:string, content:string, OnBtn1Action:fun())
---@overload fun(title:string, content:string)
---@param title string
---@param content string
---@param OnBtn1Action fun()
---@param OnBtn2Action fun()
---@param btn1Text string
---@param btn2Text string
function m:SetData(title, content, OnBtn1Action, OnBtn2Action, btn1Text, btn2Text) end

function m:OnCloseBtnClick() end

---@overload fun(title:string, content:string, btn1Action:fun(), btn2Action:fun(), btn1Text:string) @static
---@overload fun(title:string, content:string, btn1Action:fun(), btn2Action:fun()) @static
---@overload fun(title:string, content:string, btn1Action:fun()) @static
---@overload fun(title:string, content:string) @static
---@static
---@param title string
---@param content string
---@param btn1Action fun()
---@param btn2Action fun()
---@param btn1Text string
---@param btn2Text string
function m.ShowNotice(title, content, btn1Action, btn2Action, btn1Text, btn2Text) end

function m:InitTrans() end

CommonNoticePanel = m
return m
