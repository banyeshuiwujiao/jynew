---@class bl_UHTCamera : UnityEngine.MonoBehaviour
---@field public minPanSpeed number
---@field public maxPanSpeed number
---@field public panTimeConstant number
---@field public rotateSpeed number
---@field public zoomSpeed number
local m = {}

bl_UHTCamera = m
return m
