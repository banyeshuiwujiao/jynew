---@class QualityLevelEnum : System.Enum
---@field public Low QualityLevelEnum @static
---@field public Mid QualityLevelEnum @static
---@field public High QualityLevelEnum @static
---@field public Extreme QualityLevelEnum @static
---@field public value__ number
local m = {}

QualityLevelEnum = m
return m
