---@class XLua.OptimizeFlag : System.Enum
---@field public Default XLua.OptimizeFlag @static
---@field public PackAsTable XLua.OptimizeFlag @static
---@field public value__ number
local m = {}

XLua.OptimizeFlag = m
return m
