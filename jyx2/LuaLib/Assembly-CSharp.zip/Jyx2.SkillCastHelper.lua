---@class Jyx2.SkillCastHelper : System.Object
---@field public Source Jyx2.Jyx2AnimationBattleRole
---@field public Targets System.Collections.Generic.IEnumerable_1_Jyx2_Jyx2AnimationBattleRole_
---@field public CoverBlocks System.Collections.Generic.IEnumerable_1_UnityEngine_Transform_
---@field public Skill Jyx2.SkillCastInstance
---@field public SkillDisplay Jyx2SkillDisplayAsset
local m = {}

---@return Cysharp.Threading.Tasks.UniTask
function m:Play() end

Jyx2.SkillCastHelper = m
return m
