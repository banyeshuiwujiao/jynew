---@class CameraFilterPack_Glow_Glow_Color : UnityEngine.MonoBehaviour
---@field public SCShader UnityEngine.Shader
---@field public Amount number
---@field public FastFilter number
---@field public Threshold number
---@field public Intensity number
---@field public Precision number
---@field public GlowColor UnityEngine.Color
local m = {}

CameraFilterPack_Glow_Glow_Color = m
return m
