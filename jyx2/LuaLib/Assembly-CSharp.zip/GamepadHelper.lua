---@class GamepadHelper : System.Object
---@field public CONFIRM_BUTTON string @static
---@field public CANCEL_BUTTON string @static
---@field public ACTION_BUTTON string @static
---@field public JUMP_BUTTON string @static
---@field public DPAD_X_AXIS string @static
---@field public DPAD_Y_AXIS string @static
---@field public ANALOG_LEFT_X_AXIS string @static
---@field public ANALOG_LEFT_Y_AXIS string @static
---@field public ANALOG_RIGHT_X_AXIS string @static
---@field public ANALOG_RIGHT_Y_AXIS string @static
---@field public TAB_L1 string @static
---@field public TAB_R1 string @static
---@field public START_BUTTON string @static
---@field public PAD_BUTTON string @static
---@field public GamepadConnected boolean @static
local m = {}

---@static
---@param buttonName string
---@return boolean
function m.IsButtonPressed(buttonName) end

---@static
---@return boolean
function m.IsConfirm() end

---@static
---@return boolean
function m.IsCancel() end

---@static
---@return boolean
function m.IsAction() end

---@static
---@return boolean
function m.IsJump() end

---@static
---@return boolean
function m.IsStart() end

---@static
---@return boolean
function m.IsPadPress() end

---@static
---@return boolean
function m.IsTabLeft() end

---@static
---@return boolean
function m.IsTabRight() end

---@static
---@param right boolean
---@return boolean
function m.IsDadXMove(right) end

---@static
---@param down boolean
---@return boolean
function m.IsDadYMove(down) end

---@static
---@return AnalogAxisMove
function m.GetLeftAnalogMove() end

---@static
---@return AnalogAxisMove
function m.GetRightAnalogMove() end

GamepadHelper = m
return m
