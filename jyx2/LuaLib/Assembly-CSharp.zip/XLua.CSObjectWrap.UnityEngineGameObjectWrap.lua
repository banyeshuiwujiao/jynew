---@class XLua.CSObjectWrap.UnityEngineGameObjectWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.UnityEngineGameObjectWrap = m
return m
