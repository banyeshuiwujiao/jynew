---@class JetBrains.Annotations.AssertionConditionType : System.Enum
---@field public IS_TRUE JetBrains.Annotations.AssertionConditionType @static
---@field public IS_FALSE JetBrains.Annotations.AssertionConditionType @static
---@field public IS_NULL JetBrains.Annotations.AssertionConditionType @static
---@field public IS_NOT_NULL JetBrains.Annotations.AssertionConditionType @static
---@field public value__ number
local m = {}

JetBrains.Annotations.AssertionConditionType = m
return m
