---@class Unity.Profiling.LowLevel.Unsafe.ProfilerUnsafeUtility.TimestampConversionRatio : System.ValueType
---@field public Numerator number
---@field public Denominator number
local m = {}

Unity.Profiling.LowLevel.Unsafe.ProfilerUnsafeUtility.TimestampConversionRatio = m
return m
