---@class Unity.Baselib.BaselibNativeLibrary : System.Object
local m = {}

Unity.Baselib.BaselibNativeLibrary = m
return m
