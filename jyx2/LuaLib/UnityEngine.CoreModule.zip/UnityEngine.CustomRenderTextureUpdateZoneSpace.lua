---@class UnityEngine.CustomRenderTextureUpdateZoneSpace : System.Enum
---@field public Normalized UnityEngine.CustomRenderTextureUpdateZoneSpace @static
---@field public Pixel UnityEngine.CustomRenderTextureUpdateZoneSpace @static
---@field public value__ number
local m = {}

UnityEngine.CustomRenderTextureUpdateZoneSpace = m
return m
