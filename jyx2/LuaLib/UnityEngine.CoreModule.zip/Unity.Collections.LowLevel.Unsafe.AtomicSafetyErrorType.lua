---@class Unity.Collections.LowLevel.Unsafe.AtomicSafetyErrorType : System.Enum
---@field public Deallocated Unity.Collections.LowLevel.Unsafe.AtomicSafetyErrorType @static
---@field public DeallocatedFromJob Unity.Collections.LowLevel.Unsafe.AtomicSafetyErrorType @static
---@field public NotAllocatedFromJob Unity.Collections.LowLevel.Unsafe.AtomicSafetyErrorType @static
---@field public value__ number
local m = {}

Unity.Collections.LowLevel.Unsafe.AtomicSafetyErrorType = m
return m
