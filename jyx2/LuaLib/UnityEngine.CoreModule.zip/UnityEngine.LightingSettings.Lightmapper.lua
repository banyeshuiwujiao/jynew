---@class UnityEngine.LightingSettings.Lightmapper : System.Enum
---@field public Enlighten UnityEngine.LightingSettings.Lightmapper @static
---@field public ProgressiveCPU UnityEngine.LightingSettings.Lightmapper @static
---@field public ProgressiveGPU UnityEngine.LightingSettings.Lightmapper @static
---@field public value__ number
local m = {}

UnityEngine.LightingSettings.Lightmapper = m
return m
