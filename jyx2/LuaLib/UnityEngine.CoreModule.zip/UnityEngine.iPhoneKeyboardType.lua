---@class UnityEngine.iPhoneKeyboardType : System.Enum
---@field public Default UnityEngine.iPhoneKeyboardType @static
---@field public ASCIICapable UnityEngine.iPhoneKeyboardType @static
---@field public NumbersAndPunctuation UnityEngine.iPhoneKeyboardType @static
---@field public URL UnityEngine.iPhoneKeyboardType @static
---@field public NumberPad UnityEngine.iPhoneKeyboardType @static
---@field public PhonePad UnityEngine.iPhoneKeyboardType @static
---@field public NamePhonePad UnityEngine.iPhoneKeyboardType @static
---@field public EmailAddress UnityEngine.iPhoneKeyboardType @static
---@field public value__ number
local m = {}

UnityEngine.iPhoneKeyboardType = m
return m
