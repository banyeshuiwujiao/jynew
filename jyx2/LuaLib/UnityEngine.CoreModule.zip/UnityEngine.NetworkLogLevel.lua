---@class UnityEngine.NetworkLogLevel : System.Enum
---@field public value__ number
local m = {}

UnityEngine.NetworkLogLevel = m
return m
