---@class Unity.Baselib.LowLevel.Binding.Baselib_Memory_PageState : System.Enum
---@field public Reserved Unity.Baselib.LowLevel.Binding.Baselib_Memory_PageState @static
---@field public NoAccess Unity.Baselib.LowLevel.Binding.Baselib_Memory_PageState @static
---@field public ReadOnly Unity.Baselib.LowLevel.Binding.Baselib_Memory_PageState @static
---@field public ReadWrite Unity.Baselib.LowLevel.Binding.Baselib_Memory_PageState @static
---@field public ReadOnly_Executable Unity.Baselib.LowLevel.Binding.Baselib_Memory_PageState @static
---@field public ReadWrite_Executable Unity.Baselib.LowLevel.Binding.Baselib_Memory_PageState @static
---@field public value__ number
local m = {}

Unity.Baselib.LowLevel.Binding.Baselib_Memory_PageState = m
return m
