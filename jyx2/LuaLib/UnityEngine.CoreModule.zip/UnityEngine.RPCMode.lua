---@class UnityEngine.RPCMode : System.Enum
---@field public value__ number
local m = {}

UnityEngine.RPCMode = m
return m
