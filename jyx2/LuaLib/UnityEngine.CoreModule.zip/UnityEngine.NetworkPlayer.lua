---@class UnityEngine.NetworkPlayer : System.ValueType
---@field public ipAddress string
---@field public port number
---@field public guid string
---@field public externalIP string
---@field public externalPort number
local m = {}

UnityEngine.NetworkPlayer = m
return m
