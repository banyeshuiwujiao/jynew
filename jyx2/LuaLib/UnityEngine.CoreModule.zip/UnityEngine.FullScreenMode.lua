---@class UnityEngine.FullScreenMode : System.Enum
---@field public ExclusiveFullScreen UnityEngine.FullScreenMode @static
---@field public FullScreenWindow UnityEngine.FullScreenMode @static
---@field public MaximizedWindow UnityEngine.FullScreenMode @static
---@field public Windowed UnityEngine.FullScreenMode @static
---@field public value__ number
local m = {}

UnityEngine.FullScreenMode = m
return m
