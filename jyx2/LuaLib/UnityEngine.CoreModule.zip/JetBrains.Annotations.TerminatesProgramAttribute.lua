---@class JetBrains.Annotations.TerminatesProgramAttribute : System.Attribute
local m = {}

JetBrains.Annotations.TerminatesProgramAttribute = m
return m
