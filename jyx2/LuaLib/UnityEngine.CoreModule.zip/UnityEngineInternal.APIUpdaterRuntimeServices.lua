---@class UnityEngineInternal.APIUpdaterRuntimeServices : System.Object
local m = {}

---@static
---@param go UnityEngine.GameObject
---@param sourceInfo string
---@param name string
---@return UnityEngine.Component
function m.AddComponent(go, sourceInfo, name) end

UnityEngineInternal.APIUpdaterRuntimeServices = m
return m
