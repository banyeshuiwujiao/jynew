---@class JetBrains.Annotations.CollectionAccessType : System.Enum
---@field public None JetBrains.Annotations.CollectionAccessType @static
---@field public Read JetBrains.Annotations.CollectionAccessType @static
---@field public ModifyExistingContent JetBrains.Annotations.CollectionAccessType @static
---@field public UpdatedContent JetBrains.Annotations.CollectionAccessType @static
---@field public value__ number
local m = {}

JetBrains.Annotations.CollectionAccessType = m
return m
