---@class Unity.IO.LowLevel.Unsafe.FileState : System.Enum
---@field public Absent Unity.IO.LowLevel.Unsafe.FileState @static
---@field public Exists Unity.IO.LowLevel.Unsafe.FileState @static
---@field public value__ number
local m = {}

Unity.IO.LowLevel.Unsafe.FileState = m
return m
