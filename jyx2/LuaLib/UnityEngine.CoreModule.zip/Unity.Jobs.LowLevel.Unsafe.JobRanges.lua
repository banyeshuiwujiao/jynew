---@class Unity.Jobs.LowLevel.Unsafe.JobRanges : System.ValueType
---@field public TotalIterationCount number
local m = {}

Unity.Jobs.LowLevel.Unsafe.JobRanges = m
return m
