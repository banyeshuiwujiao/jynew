---@class UnityEngine.Mesh.SafetyHandleIndex : System.Enum
---@field public BonesPerVertexArray UnityEngine.Mesh.SafetyHandleIndex @static
---@field public BonesWeightsArray UnityEngine.Mesh.SafetyHandleIndex @static
---@field public value__ number
local m = {}

UnityEngine.Mesh.SafetyHandleIndex = m
return m
