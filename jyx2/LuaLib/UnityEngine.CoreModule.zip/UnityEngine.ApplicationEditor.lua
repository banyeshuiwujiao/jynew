---@class UnityEngine.ApplicationEditor : System.Object
---@field public platform UnityEngine.RuntimePlatform @static
---@field public isMobilePlatform boolean @static
---@field public isConsolePlatform boolean @static
---@field public systemLanguage UnityEngine.SystemLanguage @static
---@field public internetReachability UnityEngine.NetworkReachability @static
---@field public isEditor boolean @static
local m = {}

UnityEngine.ApplicationEditor = m
return m
