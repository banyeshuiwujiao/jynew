---@class UnityEngine.Flare : UnityEngine.Object
local m = {}

UnityEngine.Flare = m
return m
