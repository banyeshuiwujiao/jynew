---@class Unity.Collections.NativeFixedLengthAttribute : System.Attribute
---@field public FixedLength number
local m = {}

Unity.Collections.NativeFixedLengthAttribute = m
return m
