---@class UnityEngine.Camera.ProjectionMatrixMode : System.Enum
---@field public Explicit UnityEngine.Camera.ProjectionMatrixMode @static
---@field public Implicit UnityEngine.Camera.ProjectionMatrixMode @static
---@field public PhysicalPropertiesBased UnityEngine.Camera.ProjectionMatrixMode @static
---@field public value__ number
local m = {}

UnityEngine.Camera.ProjectionMatrixMode = m
return m
