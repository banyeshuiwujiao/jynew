---@class UnityEngineInternal.MemorylessMode : System.Enum
---@field public Unused UnityEngineInternal.MemorylessMode @static
---@field public Forced UnityEngineInternal.MemorylessMode @static
---@field public Automatic UnityEngineInternal.MemorylessMode @static
---@field public value__ number
local m = {}

UnityEngineInternal.MemorylessMode = m
return m
