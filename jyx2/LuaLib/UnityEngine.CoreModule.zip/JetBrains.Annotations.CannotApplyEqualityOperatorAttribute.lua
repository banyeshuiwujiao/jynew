---@class JetBrains.Annotations.CannotApplyEqualityOperatorAttribute : System.Attribute
local m = {}

JetBrains.Annotations.CannotApplyEqualityOperatorAttribute = m
return m
