---@class Unity.Baselib.LowLevel.Binding.Baselib_ErrorState_ExtraInformationType : System.Enum
---@field public None Unity.Baselib.LowLevel.Binding.Baselib_ErrorState_ExtraInformationType @static
---@field public StaticString Unity.Baselib.LowLevel.Binding.Baselib_ErrorState_ExtraInformationType @static
---@field public GenerationCounter Unity.Baselib.LowLevel.Binding.Baselib_ErrorState_ExtraInformationType @static
---@field public value__ number
local m = {}

Unity.Baselib.LowLevel.Binding.Baselib_ErrorState_ExtraInformationType = m
return m
