---@class Unity.Baselib.LowLevel.Binding.Baselib_RegisteredNetwork_CompletionResult : System.ValueType
---@field public status Unity.Baselib.LowLevel.Binding.Baselib_RegisteredNetwork_CompletionStatus
---@field public bytesTransferred number
---@field public requestUserdata System.IntPtr
local m = {}

Unity.Baselib.LowLevel.Binding.Baselib_RegisteredNetwork_CompletionResult = m
return m
