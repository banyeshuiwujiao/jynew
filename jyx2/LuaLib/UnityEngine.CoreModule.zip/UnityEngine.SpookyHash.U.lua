---@class UnityEngine.SpookyHash.U : System.ValueType
---@field public p8 System.Byte*
---@field public p32 System.UInt32*
---@field public p64 System.UInt64*
---@field public i number
local m = {}

UnityEngine.SpookyHash.U = m
return m
