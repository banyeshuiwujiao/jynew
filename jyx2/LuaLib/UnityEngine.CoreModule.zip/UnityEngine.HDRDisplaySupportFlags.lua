---@class UnityEngine.HDRDisplaySupportFlags : System.Enum
---@field public None UnityEngine.HDRDisplaySupportFlags @static
---@field public Supported UnityEngine.HDRDisplaySupportFlags @static
---@field public RuntimeSwitchable UnityEngine.HDRDisplaySupportFlags @static
---@field public AutomaticTonemapping UnityEngine.HDRDisplaySupportFlags @static
---@field public value__ number
local m = {}

UnityEngine.HDRDisplaySupportFlags = m
return m
