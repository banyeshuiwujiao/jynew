---@class UnityEngine.Camera.FieldOfViewAxis : System.Enum
---@field public Vertical UnityEngine.Camera.FieldOfViewAxis @static
---@field public Horizontal UnityEngine.Camera.FieldOfViewAxis @static
---@field public value__ number
local m = {}

UnityEngine.Camera.FieldOfViewAxis = m
return m
