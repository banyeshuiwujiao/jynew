---@class Unity.Collections.LowLevel.Unsafe.NativeContainerIsAtomicWriteOnlyAttribute : System.Attribute
local m = {}

Unity.Collections.LowLevel.Unsafe.NativeContainerIsAtomicWriteOnlyAttribute = m
return m
