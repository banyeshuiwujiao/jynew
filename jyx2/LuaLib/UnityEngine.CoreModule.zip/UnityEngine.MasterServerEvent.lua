---@class UnityEngine.MasterServerEvent : System.Enum
---@field public value__ number
local m = {}

UnityEngine.MasterServerEvent = m
return m
