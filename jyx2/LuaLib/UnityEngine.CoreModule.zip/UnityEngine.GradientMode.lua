---@class UnityEngine.GradientMode : System.Enum
---@field public Blend UnityEngine.GradientMode @static
---@field public Fixed UnityEngine.GradientMode @static
---@field public value__ number
local m = {}

UnityEngine.GradientMode = m
return m
