---@class Unity.Jobs.LowLevel.Unsafe.JobType : System.Enum
---@field public Single Unity.Jobs.LowLevel.Unsafe.JobType @static
---@field public ParallelFor Unity.Jobs.LowLevel.Unsafe.JobType @static
---@field public value__ number
local m = {}

Unity.Jobs.LowLevel.Unsafe.JobType = m
return m
