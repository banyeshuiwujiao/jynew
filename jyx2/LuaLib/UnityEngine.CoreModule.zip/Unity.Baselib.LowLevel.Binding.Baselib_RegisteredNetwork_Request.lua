---@class Unity.Baselib.LowLevel.Binding.Baselib_RegisteredNetwork_Request : System.ValueType
---@field public payload Unity.Baselib.LowLevel.Binding.Baselib_RegisteredNetwork_BufferSlice
---@field public remoteEndpoint Unity.Baselib.LowLevel.Binding.Baselib_RegisteredNetwork_Endpoint
---@field public requestUserdata System.IntPtr
local m = {}

Unity.Baselib.LowLevel.Binding.Baselib_RegisteredNetwork_Request = m
return m
