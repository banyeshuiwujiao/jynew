---@class UnityEngine.ADBannerView.Type : System.Enum
---@field public Banner UnityEngine.ADBannerView.Type @static
---@field public MediumRect UnityEngine.ADBannerView.Type @static
---@field public value__ number
local m = {}

UnityEngine.ADBannerView.Type = m
return m
