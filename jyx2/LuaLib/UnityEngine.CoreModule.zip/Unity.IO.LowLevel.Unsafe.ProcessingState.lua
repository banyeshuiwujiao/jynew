---@class Unity.IO.LowLevel.Unsafe.ProcessingState : System.Enum
---@field public Unknown Unity.IO.LowLevel.Unsafe.ProcessingState @static
---@field public InQueue Unity.IO.LowLevel.Unsafe.ProcessingState @static
---@field public Reading Unity.IO.LowLevel.Unsafe.ProcessingState @static
---@field public Completed Unity.IO.LowLevel.Unsafe.ProcessingState @static
---@field public Failed Unity.IO.LowLevel.Unsafe.ProcessingState @static
---@field public Canceled Unity.IO.LowLevel.Unsafe.ProcessingState @static
---@field public value__ number
local m = {}

Unity.IO.LowLevel.Unsafe.ProcessingState = m
return m
