---@class JetBrains.Annotations.LinqTunnelAttribute : System.Attribute
local m = {}

JetBrains.Annotations.LinqTunnelAttribute = m
return m
