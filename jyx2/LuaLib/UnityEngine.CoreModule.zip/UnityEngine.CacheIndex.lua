---@class UnityEngine.CacheIndex : System.ValueType
---@field public name string
---@field public bytesUsed number
---@field public expires number
local m = {}

UnityEngine.CacheIndex = m
return m
