---@class Unity.Collections.ReadOnlyAttribute : System.Attribute
local m = {}

Unity.Collections.ReadOnlyAttribute = m
return m
