---@class UnityEngine.LightmapSettings : UnityEngine.Object
---@field public lightmaps UnityEngine.LightmapData[] @static
---@field public lightmapsMode UnityEngine.LightmapsMode @static
---@field public lightProbes UnityEngine.LightProbes @static
---@field public lightmapsModeLegacy UnityEngine.LightmapsModeLegacy @static
---@field public bakedColorSpace UnityEngine.ColorSpace @static
local m = {}

UnityEngine.LightmapSettings = m
return m
