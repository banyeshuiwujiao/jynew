---@class Unity.Collections.LowLevel.Unsafe.NativeSetClassTypeToNullOnScheduleAttribute : System.Attribute
local m = {}

Unity.Collections.LowLevel.Unsafe.NativeSetClassTypeToNullOnScheduleAttribute = m
return m
