---@class UnityEngine.LightShape : System.Enum
---@field public Cone UnityEngine.LightShape @static
---@field public Pyramid UnityEngine.LightShape @static
---@field public Box UnityEngine.LightShape @static
---@field public value__ number
local m = {}

UnityEngine.LightShape = m
return m
