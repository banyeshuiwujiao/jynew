---@class Unity.Jobs.LowLevel.Unsafe.BatchQueryJob_2_CommandT_ResultT_ : System.ValueType
local m = {}

Unity.Jobs.LowLevel.Unsafe.BatchQueryJob_2_CommandT_ResultT_ = m
return m
