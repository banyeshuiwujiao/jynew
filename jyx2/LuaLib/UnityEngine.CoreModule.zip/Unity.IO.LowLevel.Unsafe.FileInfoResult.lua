---@class Unity.IO.LowLevel.Unsafe.FileInfoResult : System.ValueType
---@field public FileSize number
---@field public FileState Unity.IO.LowLevel.Unsafe.FileState
local m = {}

Unity.IO.LowLevel.Unsafe.FileInfoResult = m
return m
