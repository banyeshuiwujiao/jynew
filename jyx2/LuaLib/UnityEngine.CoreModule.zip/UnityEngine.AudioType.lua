---@class UnityEngine.AudioType : System.Enum
---@field public UNKNOWN UnityEngine.AudioType @static
---@field public ACC UnityEngine.AudioType @static
---@field public AIFF UnityEngine.AudioType @static
---@field public IT UnityEngine.AudioType @static
---@field public MOD UnityEngine.AudioType @static
---@field public MPEG UnityEngine.AudioType @static
---@field public OGGVORBIS UnityEngine.AudioType @static
---@field public S3M UnityEngine.AudioType @static
---@field public WAV UnityEngine.AudioType @static
---@field public XM UnityEngine.AudioType @static
---@field public XMA UnityEngine.AudioType @static
---@field public VAG UnityEngine.AudioType @static
---@field public AUDIOQUEUE UnityEngine.AudioType @static
---@field public value__ number
local m = {}

UnityEngine.AudioType = m
return m
