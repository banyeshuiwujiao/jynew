---@class Unity.IO.LowLevel.Unsafe.AssetLoadingSubsystem : System.Enum
---@field public Other Unity.IO.LowLevel.Unsafe.AssetLoadingSubsystem @static
---@field public Texture Unity.IO.LowLevel.Unsafe.AssetLoadingSubsystem @static
---@field public VirtualTexture Unity.IO.LowLevel.Unsafe.AssetLoadingSubsystem @static
---@field public Mesh Unity.IO.LowLevel.Unsafe.AssetLoadingSubsystem @static
---@field public Audio Unity.IO.LowLevel.Unsafe.AssetLoadingSubsystem @static
---@field public Scripts Unity.IO.LowLevel.Unsafe.AssetLoadingSubsystem @static
---@field public EntitiesScene Unity.IO.LowLevel.Unsafe.AssetLoadingSubsystem @static
---@field public EntitiesStreamBinaryReader Unity.IO.LowLevel.Unsafe.AssetLoadingSubsystem @static
---@field public FileInfo Unity.IO.LowLevel.Unsafe.AssetLoadingSubsystem @static
---@field public value__ number
local m = {}

Unity.IO.LowLevel.Unsafe.AssetLoadingSubsystem = m
return m
