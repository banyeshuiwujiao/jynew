---@class UnityEngine.LightmappingMode : System.Enum
---@field public Realtime UnityEngine.LightmappingMode @static
---@field public Baked UnityEngine.LightmappingMode @static
---@field public Mixed UnityEngine.LightmappingMode @static
---@field public value__ number
local m = {}

UnityEngine.LightmappingMode = m
return m
