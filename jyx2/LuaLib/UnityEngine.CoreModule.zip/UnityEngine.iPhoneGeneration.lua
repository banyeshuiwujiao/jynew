---@class UnityEngine.iPhoneGeneration : System.Enum
---@field public Unknown UnityEngine.iPhoneGeneration @static
---@field public iPhone UnityEngine.iPhoneGeneration @static
---@field public iPhone3G UnityEngine.iPhoneGeneration @static
---@field public iPhone3GS UnityEngine.iPhoneGeneration @static
---@field public iPodTouch1Gen UnityEngine.iPhoneGeneration @static
---@field public iPodTouch2Gen UnityEngine.iPhoneGeneration @static
---@field public iPodTouch3Gen UnityEngine.iPhoneGeneration @static
---@field public iPad1Gen UnityEngine.iPhoneGeneration @static
---@field public iPhone4 UnityEngine.iPhoneGeneration @static
---@field public iPodTouch4Gen UnityEngine.iPhoneGeneration @static
---@field public iPad2Gen UnityEngine.iPhoneGeneration @static
---@field public iPhone4S UnityEngine.iPhoneGeneration @static
---@field public iPad3Gen UnityEngine.iPhoneGeneration @static
---@field public iPhone5 UnityEngine.iPhoneGeneration @static
---@field public iPodTouch5Gen UnityEngine.iPhoneGeneration @static
---@field public iPadMini1Gen UnityEngine.iPhoneGeneration @static
---@field public iPad4Gen UnityEngine.iPhoneGeneration @static
---@field public iPhone5C UnityEngine.iPhoneGeneration @static
---@field public iPhone5S UnityEngine.iPhoneGeneration @static
---@field public iPhoneUnknown UnityEngine.iPhoneGeneration @static
---@field public iPadUnknown UnityEngine.iPhoneGeneration @static
---@field public iPodTouchUnknown UnityEngine.iPhoneGeneration @static
---@field public value__ number
local m = {}

UnityEngine.iPhoneGeneration = m
return m
