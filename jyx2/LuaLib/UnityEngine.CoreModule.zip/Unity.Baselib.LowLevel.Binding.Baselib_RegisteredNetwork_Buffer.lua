---@class Unity.Baselib.LowLevel.Binding.Baselib_RegisteredNetwork_Buffer : System.ValueType
---@field public id System.IntPtr
---@field public allocation Unity.Baselib.LowLevel.Binding.Baselib_Memory_PageAllocation
local m = {}

Unity.Baselib.LowLevel.Binding.Baselib_RegisteredNetwork_Buffer = m
return m
