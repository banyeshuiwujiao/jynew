---@class UnityEngine.StereoTargetEyeMask : System.Enum
---@field public None UnityEngine.StereoTargetEyeMask @static
---@field public Left UnityEngine.StereoTargetEyeMask @static
---@field public Right UnityEngine.StereoTargetEyeMask @static
---@field public Both UnityEngine.StereoTargetEyeMask @static
---@field public value__ number
local m = {}

UnityEngine.StereoTargetEyeMask = m
return m
