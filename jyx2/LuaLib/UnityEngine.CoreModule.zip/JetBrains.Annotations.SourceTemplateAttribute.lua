---@class JetBrains.Annotations.SourceTemplateAttribute : System.Attribute
local m = {}

JetBrains.Annotations.SourceTemplateAttribute = m
return m
