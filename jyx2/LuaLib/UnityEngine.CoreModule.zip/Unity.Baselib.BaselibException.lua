---@class Unity.Baselib.BaselibException : System.Exception
---@field public ErrorCode Unity.Baselib.LowLevel.Binding.Baselib_ErrorCode
local m = {}

Unity.Baselib.BaselibException = m
return m
