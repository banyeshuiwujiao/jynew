---@class Unity.Collections.Allocator : System.Enum
---@field public Invalid Unity.Collections.Allocator @static
---@field public None Unity.Collections.Allocator @static
---@field public Temp Unity.Collections.Allocator @static
---@field public TempJob Unity.Collections.Allocator @static
---@field public Persistent Unity.Collections.Allocator @static
---@field public AudioKernel Unity.Collections.Allocator @static
---@field public value__ number
local m = {}

Unity.Collections.Allocator = m
return m
