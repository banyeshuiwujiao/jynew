---@class UnityEngine.CalendarUnit : System.Enum
---@field public Era UnityEngine.CalendarUnit @static
---@field public Year UnityEngine.CalendarUnit @static
---@field public Month UnityEngine.CalendarUnit @static
---@field public Day UnityEngine.CalendarUnit @static
---@field public Hour UnityEngine.CalendarUnit @static
---@field public Minute UnityEngine.CalendarUnit @static
---@field public Second UnityEngine.CalendarUnit @static
---@field public Week UnityEngine.CalendarUnit @static
---@field public Weekday UnityEngine.CalendarUnit @static
---@field public WeekdayOrdinal UnityEngine.CalendarUnit @static
---@field public Quarter UnityEngine.CalendarUnit @static
---@field public value__ number
local m = {}

UnityEngine.CalendarUnit = m
return m
