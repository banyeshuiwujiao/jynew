---@class JetBrains.Annotations.MeansImplicitUseAttribute : System.Attribute
---@field public UseKindFlags JetBrains.Annotations.ImplicitUseKindFlags
---@field public TargetFlags JetBrains.Annotations.ImplicitUseTargetFlags
local m = {}

JetBrains.Annotations.MeansImplicitUseAttribute = m
return m
