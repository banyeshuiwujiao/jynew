---@class Unity.Collections.LowLevel.Unsafe.UnsafeUtility.AlignOfHelper_1_T_ : System.ValueType
---@field public dummy number
---@field public data System.ValueType
local m = {}

Unity.Collections.LowLevel.Unsafe.UnsafeUtility.AlignOfHelper_1_T_ = m
return m
