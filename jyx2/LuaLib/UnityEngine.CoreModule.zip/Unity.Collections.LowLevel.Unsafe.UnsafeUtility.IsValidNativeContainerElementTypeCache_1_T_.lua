---@class Unity.Collections.LowLevel.Unsafe.UnsafeUtility.IsValidNativeContainerElementTypeCache_1_T_ : System.ValueType
local m = {}

Unity.Collections.LowLevel.Unsafe.UnsafeUtility.IsValidNativeContainerElementTypeCache_1_T_ = m
return m
