---@class UnityEngine.MaterialGlobalIlluminationFlags : System.Enum
---@field public None UnityEngine.MaterialGlobalIlluminationFlags @static
---@field public RealtimeEmissive UnityEngine.MaterialGlobalIlluminationFlags @static
---@field public BakedEmissive UnityEngine.MaterialGlobalIlluminationFlags @static
---@field public EmissiveIsBlack UnityEngine.MaterialGlobalIlluminationFlags @static
---@field public AnyEmissive UnityEngine.MaterialGlobalIlluminationFlags @static
---@field public value__ number
local m = {}

UnityEngine.MaterialGlobalIlluminationFlags = m
return m
