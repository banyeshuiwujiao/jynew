---@class UnityEngine.LightProbeProxyVolume.QualityMode : System.Enum
---@field public Low UnityEngine.LightProbeProxyVolume.QualityMode @static
---@field public Normal UnityEngine.LightProbeProxyVolume.QualityMode @static
---@field public value__ number
local m = {}

UnityEngine.LightProbeProxyVolume.QualityMode = m
return m
