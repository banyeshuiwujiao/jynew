---@class Unity.Profiling.LowLevel.Unsafe.ProfilerCategoryDescription : System.ValueType
---@field public Id number
---@field public Color UnityEngine.Color32
---@field public NameUtf8Len number
---@field public NameUtf8 System.Byte*
---@field public Name string
local m = {}

Unity.Profiling.LowLevel.Unsafe.ProfilerCategoryDescription = m
return m
