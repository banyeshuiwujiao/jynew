---@class UnityEngineInternal.APIUpdaterRuntimeServices.__c__DisplayClass1_0 : System.Object
---@field public name string
local m = {}

UnityEngineInternal.APIUpdaterRuntimeServices.__c__DisplayClass1_0 = m
return m
