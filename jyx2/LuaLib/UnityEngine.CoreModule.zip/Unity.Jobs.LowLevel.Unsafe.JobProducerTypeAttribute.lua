---@class Unity.Jobs.LowLevel.Unsafe.JobProducerTypeAttribute : System.Attribute
---@field public ProducerType System.Type
local m = {}

Unity.Jobs.LowLevel.Unsafe.JobProducerTypeAttribute = m
return m
