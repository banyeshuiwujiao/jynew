---@class UnityEngine.LightingSettings.FilterType : System.Enum
---@field public Gaussian UnityEngine.LightingSettings.FilterType @static
---@field public ATrous UnityEngine.LightingSettings.FilterType @static
---@field public None UnityEngine.LightingSettings.FilterType @static
---@field public value__ number
local m = {}

UnityEngine.LightingSettings.FilterType = m
return m
