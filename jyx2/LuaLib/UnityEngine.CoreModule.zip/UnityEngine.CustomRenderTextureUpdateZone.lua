---@class UnityEngine.CustomRenderTextureUpdateZone : System.ValueType
---@field public updateZoneCenter UnityEngine.Vector3
---@field public updateZoneSize UnityEngine.Vector3
---@field public rotation number
---@field public passIndex number
---@field public needSwap boolean
local m = {}

UnityEngine.CustomRenderTextureUpdateZone = m
return m
