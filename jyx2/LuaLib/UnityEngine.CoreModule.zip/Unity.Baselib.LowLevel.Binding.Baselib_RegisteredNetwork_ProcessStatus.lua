---@class Unity.Baselib.LowLevel.Binding.Baselib_RegisteredNetwork_ProcessStatus : System.Enum
---@field public NonePendingImmediately Unity.Baselib.LowLevel.Binding.Baselib_RegisteredNetwork_ProcessStatus @static
---@field public Done Unity.Baselib.LowLevel.Binding.Baselib_RegisteredNetwork_ProcessStatus @static
---@field public Pending Unity.Baselib.LowLevel.Binding.Baselib_RegisteredNetwork_ProcessStatus @static
---@field public value__ number
local m = {}

Unity.Baselib.LowLevel.Binding.Baselib_RegisteredNetwork_ProcessStatus = m
return m
