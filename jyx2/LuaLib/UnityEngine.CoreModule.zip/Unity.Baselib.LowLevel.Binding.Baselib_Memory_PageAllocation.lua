---@class Unity.Baselib.LowLevel.Binding.Baselib_Memory_PageAllocation : System.ValueType
---@field public ptr System.IntPtr
---@field public pageSize number
---@field public pageCount number
local m = {}

Unity.Baselib.LowLevel.Binding.Baselib_Memory_PageAllocation = m
return m
