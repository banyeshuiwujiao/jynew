---@class Unity.Jobs.LowLevel.Unsafe.JobHandleUnsafeUtility : System.Object
local m = {}

---@static
---@param jobs Unity.Jobs.JobHandle*
---@param count number
---@return Unity.Jobs.JobHandle
function m.CombineDependencies(jobs, count) end

Unity.Jobs.LowLevel.Unsafe.JobHandleUnsafeUtility = m
return m
