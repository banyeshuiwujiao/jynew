---@class UnityEngine.CubemapFace : System.Enum
---@field public Unknown UnityEngine.CubemapFace @static
---@field public PositiveX UnityEngine.CubemapFace @static
---@field public NegativeX UnityEngine.CubemapFace @static
---@field public PositiveY UnityEngine.CubemapFace @static
---@field public NegativeY UnityEngine.CubemapFace @static
---@field public PositiveZ UnityEngine.CubemapFace @static
---@field public NegativeZ UnityEngine.CubemapFace @static
---@field public value__ number
local m = {}

UnityEngine.CubemapFace = m
return m
