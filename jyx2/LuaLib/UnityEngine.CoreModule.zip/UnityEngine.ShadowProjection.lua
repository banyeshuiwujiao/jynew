---@class UnityEngine.ShadowProjection : System.Enum
---@field public CloseFit UnityEngine.ShadowProjection @static
---@field public StableFit UnityEngine.ShadowProjection @static
---@field public value__ number
local m = {}

UnityEngine.ShadowProjection = m
return m
