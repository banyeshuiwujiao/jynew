---@class Unity.Collections.LowLevel.Unsafe.NativeContainerIsReadOnlyAttribute : System.Attribute
local m = {}

Unity.Collections.LowLevel.Unsafe.NativeContainerIsReadOnlyAttribute = m
return m
