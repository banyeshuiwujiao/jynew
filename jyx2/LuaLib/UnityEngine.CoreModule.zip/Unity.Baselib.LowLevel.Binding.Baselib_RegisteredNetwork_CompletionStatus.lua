---@class Unity.Baselib.LowLevel.Binding.Baselib_RegisteredNetwork_CompletionStatus : System.Enum
---@field public Failed Unity.Baselib.LowLevel.Binding.Baselib_RegisteredNetwork_CompletionStatus @static
---@field public Success Unity.Baselib.LowLevel.Binding.Baselib_RegisteredNetwork_CompletionStatus @static
---@field public value__ number
local m = {}

Unity.Baselib.LowLevel.Binding.Baselib_RegisteredNetwork_CompletionStatus = m
return m
